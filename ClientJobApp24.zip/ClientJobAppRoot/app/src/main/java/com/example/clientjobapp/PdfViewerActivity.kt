package com.example.clientjobapp

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.core.net.toUri
import com.example.clientjobapp.data.AppDatabase
import com.example.clientjobapp.data.DocumentoTrabajo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class PdfViewerActivity : ComponentActivity() {
    private lateinit var db: AppDatabase
    private var jobId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicializo la base de datos y obtengo el jobId pasado por Intent
        db = AppDatabase.getDatabase(this)
        jobId = intent.getIntExtra("JOB_ID", -1)

        if (jobId == -1) {
            Toast.makeText(this, "Trabajo inválido", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        setContent {
            MaterialTheme {
                PdfViewerScreen()
            }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun PdfViewerScreen() {
        val context = LocalContext.current
        val scope = rememberCoroutineScope()

        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Documentos asociados a éste trabajo") }
                )
            },
            content = { paddingValues ->
                // Estados de Compose
                var documents by remember { mutableStateOf(listOf<DocumentoItem>()) }
                var isLoading by remember { mutableStateOf(true) }
                var isPickingDocument by remember { mutableStateOf(false) }

                // 1) Carga todos los documentos asociados a este jobId
                val loadDocuments: () -> Unit = {
                    scope.launch {
                        isLoading = true
                        val docsFromDb = db.administracionDao().getAllDocumentsForJob(jobId)
                        documents = docsFromDb.map { registro ->
                            val uriString = registro.documentUri
                            DocumentoItem(
                                id = registro.id,
                                uri = uriString.toUri(),
                                name = File(uriString).name,
                                isPdf = uriString.endsWith(".pdf", ignoreCase = true)
                            )
                        }
                        isLoading = false
                    }
                }

                // 2) Launcher para seleccionar un PDF o JPG
                val documentPickerLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.OpenDocument()
                ) { uri ->
                    uri?.let {
                        scope.launch {
                            isPickingDocument = true
                            try {
                                // Pedimos permiso de lectura persistente
                                context.contentResolver.takePersistableUriPermission(
                                    uri,
                                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                                )

                                // Copiamos el contenido a filesDir y obtenemos el nuevo file:// URI
                                val internalUri = copyFileToInternalStorage(uri)
                                if (internalUri != null) {
                                    // Insertamos un nuevo registro en documento_trabajo
                                    val nuevoDoc = DocumentoTrabajo(
                                        jobId = jobId,
                                        documentUri = internalUri.toString()
                                    )
                                    db.administracionDao().insertDocumento(nuevoDoc)
                                    loadDocuments()
                                    Toast.makeText(
                                        context,
                                        "Documento cargado exitosamente",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                } else {
                                    Toast.makeText(
                                        context,
                                        "Error al copiar el archivo a almacenamiento interno",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            } catch (e: Exception) {
                                Toast.makeText(context, "Error al cargar documento", Toast.LENGTH_SHORT)
                                    .show()
                            } finally {
                                isPickingDocument = false
                            }
                        }
                    }
                }

                // 3) Al montar el Composable, cargo documentos
                LaunchedEffect(Unit) {
                    loadDocuments()
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                        .systemBarsPadding()
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Button(
                        onClick = {
                            documentPickerLauncher.launch(arrayOf("application/pdf", "image/jpeg"))
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isPickingDocument
                    ) {
                        Text("Cargar documentos")
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (isLoading) {
                        CircularProgressIndicator(modifier = Modifier.padding(16.dp))
                    } else {
                        if (documents.isEmpty()) {
                            Text("No hay documentos cargados.", modifier = Modifier.padding(16.dp))
                        } else {
                            documents.forEach { doc ->
                                DocumentListItem(
                                    document = doc,
                                    onOpen = {
                                        openDocument(context, doc.uri)
                                    },
                                    onDelete = {
                                        scope.launch {
                                            // Borramos el archivo físico
                                            val file = File(doc.uri.path ?: "")
                                            if (file.exists()) file.delete()

                                            // Borramos el registro de la DB por su id
                                            db.administracionDao().deleteByUri(doc.uri.toString())
                                            loadDocuments()
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        )
    }

    // Copia el archivo del URI original a filesDir y retorna un URI tipo file://
    private fun copyFileToInternalStorage(uri: Uri): Uri? {
        val context = applicationContext
        // Obtenemos nombre no nulo (si getFileName() da null, usamos "document.pdf")
        val originalName = getFileName(context, uri) ?: "document.pdf"
        var safeName = originalName
        var file = File(context.filesDir, safeName)
        var count = 0
        while (file.exists()) {
            count++
            val baseName = safeName.substringBeforeLast('.')
            val extension = safeName.substringAfterLast('.', "")
            safeName = if (extension.isNotEmpty()) {
                "${baseName}_$count.$extension"
            } else {
                "${baseName}_$count"
            }
            file = File(context.filesDir, safeName)
        }

        return try {
            context.contentResolver.openInputStream(uri).use { inputStream ->
                FileOutputStream(file).use { outputStream ->
                    inputStream?.copyTo(outputStream)
                }
            }
            Uri.fromFile(file)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    // Abre un Intent para ver PDF o imagen con FileProvider si hace falta
    private fun openDocument(context: Context, uri: Uri) {
        // Si la URI tiene scheme "file", envolvemos en FileProvider
        val contentUri: Uri = if (uri.scheme == "file") {
            FileProvider.getUriForFile(
                context,
                context.packageName + ".fileprovider",
                File(uri.path ?: "")
            )
        } else {
            uri
        }

        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(contentUri, getMimeType(contentUri))
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NO_HISTORY
        }

        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(
                context,
                "No hay aplicación para abrir este archivo.",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    // Determina MIME a partir de la extensión
    private fun getMimeType(uri: Uri): String {
        return when {
            uri.toString().endsWith(".pdf", ignoreCase = true) -> "application/pdf"
            uri.toString().endsWith(".jpg", ignoreCase = true)
                    || uri.toString().endsWith(".jpeg", ignoreCase = true) -> "image/jpeg"
            else -> "*/*"
        }
    }

    // Obtiene el nombre de fichero (DISPLAY_NAME) desde un URI content://
    private fun getFileName(context: Context, uri: Uri): String? {
        var name: String? = null
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && nameIndex != -1) {
                name = cursor.getString(nameIndex)
            }
        }
        return name
    }

    /**
     * Carga un bitmap en background para previsualizar:
     * - Si es PDF, renderiza la primera página mediante PdfRenderer.
     * - Si es JPEG, decodifica un bitmap reducido desde el URI.
     */
    suspend fun loadThumbnail(context: Context, uri: Uri, isPdf: Boolean): Bitmap? {
        return withContext(Dispatchers.IO) {
            try {
                if (isPdf) {
                    // --------- PDF: renderizamos la primera página  ---------
                    val pfd: ParcelFileDescriptor? =
                        context.contentResolver.openFileDescriptor(uri, "r")
                    if (pfd != null) {
                        PdfRenderer(pfd).use { renderer ->
                            if (renderer.pageCount > 0) {
                                renderer.openPage(0).use { page ->
                                    // Escalamos a 200x200 manteniendo proporción
                                    val width = page.width
                                    val height = page.height
                                    // Queremos un thumbnail cuadrado de 100px de alta aproximada
                                    val scale = 100f / height.toFloat()
                                    val thumbWidth = (width * scale).toInt()
                                    val thumbHeight = 100

                                    val bitmap = Bitmap.createBitmap(thumbWidth, thumbHeight, Bitmap.Config.ARGB_8888)
                                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                    pfd.close()
                                    return@withContext bitmap
                                }
                            }
                            pfd.close()
                        }
                    }
                    null
                } else {
                    // --------- Imagen JPEG: decodeamos un bitmap pequeño ---------
                    val input = context.contentResolver.openInputStream(uri)
                    input?.use { stream ->
                        // Al decodificar, podemos pedir un inSampleSize para reducir memoria,
                        // pero para simplicidad solo lo decodificamos a tamaño real y luego escalamos.
                        val original = BitmapFactory.decodeStream(stream)
                        original?.let {
                            val maxDimension = 100
                            val aspect =
                                it.width.toFloat() / it.height.toFloat()
                            val thumbWidth: Int
                            val thumbHeight: Int
                            if (it.width >= it.height) {
                                thumbWidth = maxDimension
                                thumbHeight = (maxDimension / aspect).toInt()
                            } else {
                                thumbHeight = maxDimension
                                thumbWidth = (maxDimension * aspect).toInt()
                            }
                            Bitmap.createScaledBitmap(it, thumbWidth, thumbHeight, true)
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }
    }
}

// Data class que representa cada ítem en la lista (incluye el id de la tabla DocumentoTrabajo)
data class DocumentoItem(
    val id: Int,
    val uri: Uri,
    val name: String,
    val isPdf: Boolean
)

@Composable
fun DocumentListItem(
    document: DocumentoItem,
    onOpen: () -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current

    // Estado que guardará el thumbnail; inicialmente null
    var thumbnail by remember { mutableStateOf<Bitmap?>(null) }
    var isLoadingThumb by remember { mutableStateOf(true) }

    // Lanzamos la carga del thumbnail cuando cambie la URI
    LaunchedEffect(document.uri) {
        isLoadingThumb = true
        thumbnail = (context as PdfViewerActivity).loadThumbnail(context, document.uri, document.isPdf)
        isLoadingThumb = false
    }

    var showDeleteDialog by remember { mutableStateOf(false) }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Eliminar archivo") },
            text = { Text("¿Está seguro que desea eliminar este archivo?") },
            confirmButton = {
                Button(onClick = {
                    showDeleteDialog = false
                    onDelete()
                }) {
                    Text("Eliminar")
                }
            },
            dismissButton = {
                Button(onClick = { showDeleteDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = onOpen,
                onLongClick = { showDeleteDialog = true }
            )
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // ---- Caja para el thumbnail o icono genérico ----
        Box(
            modifier = Modifier
                .size(60.dp)
                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f)),
            contentAlignment = Alignment.Center
        ) {
            if (isLoadingThumb) {
                CircularProgressIndicator(
                    modifier = Modifier
                        .size(24.dp)
                )
            } else {
                if (thumbnail != null) {
                    Image(
                        bitmap = thumbnail!!.asImageBitmap(),
                        contentDescription = "Thumbnail de ${document.name}",
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    // Si no se pudo generar preview, mostramos un icono PDF o Imagen
                    Icon(
                        imageVector = if (document.isPdf)
                            Icons.Default.PictureAsPdf
                        else
                            Icons.Default.Image,
                        contentDescription = if (document.isPdf) "Icono PDF" else "Icono Imagen",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Text(
            text = document.name,
            style = MaterialTheme.typography.bodyLarge
        )
    }
}