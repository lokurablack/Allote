package com.example.clientjobapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.clientjobapp.data.AppDatabase
import com.example.clientjobapp.data.Formulacion

class FormulacionesActivity : ComponentActivity() {

    private val viewModel: FormulacionesViewModel by viewModels {
        object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return FormulacionesViewModel(AppDatabase.getDatabase(this@FormulacionesActivity)) as T
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                FormulacionesScreen(
                    viewModel = viewModel,
                    onSaveChanges = {
                        viewModel.saveChanges {
                            runOnUiThread {
                                Toast.makeText(this, "Cambios guardados", Toast.LENGTH_SHORT).show()
                                finish()
                            }
                        }
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FormulacionesScreen(viewModel: FormulacionesViewModel, onSaveChanges: () -> Unit) {
    val formulaciones by viewModel.formulaciones.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var showEditDialog by remember { mutableStateOf<Formulacion?>(null) }
    var showDeleteDialog by remember { mutableStateOf<Formulacion?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Gestionar Formulaciones") },
                actions = {
                    Button(onClick = onSaveChanges) {
                        Text("Guardar")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Default.Add, contentDescription = "Agregar Formulación")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            items(formulaciones) { formulacion ->
                FormulacionItem(
                    formulacion = formulacion,
                    onMoveUp = { viewModel.moveUp(formulacion) },
                    onMoveDown = { viewModel.moveDown(formulacion) },
                    onEdit = { showEditDialog = formulacion },
                    onDelete = { showDeleteDialog = formulacion }
                )
            }
        }
    }

    if (showAddDialog) {
        AddEditFormulacionDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { nombre, tipo ->
                viewModel.addFormulacion(nombre, tipo)
                showAddDialog = false
            }
        )
    }

    showEditDialog?.let { formulacion ->
        AddEditFormulacionDialog(
            formulacion = formulacion,
            onDismiss = { showEditDialog = null },
            onConfirm = { nombre, tipo ->
                viewModel.updateFormulacion(formulacion.id, nombre, tipo)
                showEditDialog = null
            }
        )
    }

    showDeleteDialog?.let { formulacion ->
        DeleteFormulacionDialog(
            formulacion = formulacion,
            onDismiss = { showDeleteDialog = null },
            onConfirm = {
                // Implementar la lógica de comprobación antes de eliminar
                viewModel.deleteFormulacion(formulacion)
                showDeleteDialog = null
            },
            viewModel = viewModel
        )
    }
}

@Composable
fun FormulacionItem(
    formulacion: Formulacion,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "${formulacion.ordenMezcla}. ${formulacion.nombre} (${formulacion.tipoUnidad})",
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Row {
                IconButton(onClick = onMoveUp) {
                    Icon(Icons.Default.ArrowUpward, contentDescription = "Mover Arriba")
                }
                IconButton(onClick = onMoveDown) {
                    Icon(Icons.Default.ArrowDownward, contentDescription = "Mover Abajo")
                }
                IconButton(onClick = onEdit) {
                    Icon(Icons.Default.Edit, contentDescription = "Editar")
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Eliminar")
                }
            }
        }
    }
}

@Composable
fun AddEditFormulacionDialog(
    formulacion: Formulacion? = null,
    onDismiss: () -> Unit,
    onConfirm: (String, String) -> Unit
) {
    var nombre by remember { mutableStateOf(formulacion?.nombre ?: "") }
    var tipo by remember { mutableStateOf(formulacion?.tipoUnidad ?: "LIQUIDO") }
    var expanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (formulacion == null) "Agregar Formulación" else "Editar Formulación") },
        text = {
            Column {
                OutlinedTextField(
                    value = nombre,
                    onValueChange = { nombre = it },
                    label = { Text("Nombre") }
                )
                Spacer(modifier = Modifier.height(8.dp))
                Box {
                    OutlinedTextField(
                        value = tipo,
                        onValueChange = {},
                        label = { Text("Tipo de Unidad") },
                        readOnly = true,
                        trailingIcon = {
                            IconButton(onClick = { expanded = true }) {
                                Icon(Icons.Default.ArrowDropDown, contentDescription = "Desplegar")
                            }
                        }
                    )
                    DropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("LIQUIDO") },
                            onClick = {
                                tipo = "LIQUIDO"
                                expanded = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("SOLIDO") },
                            onClick = {
                                tipo = "SOLIDO"
                                expanded = false
                            }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(nombre, tipo) },
                enabled = nombre.isNotBlank()
            ) {
                Text("Guardar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}

@Composable
fun DeleteFormulacionDialog(
    formulacion: Formulacion,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
    viewModel: FormulacionesViewModel
) {
    var isInUse by remember { mutableStateOf<Boolean?>(null) }

    LaunchedEffect(formulacion) {
        isInUse = viewModel.isFormulacionInUse(formulacion.nombre)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Eliminar Formulación") },
        text = {
            when (isInUse) {
                null -> CircularProgressIndicator()
                true -> Text("No se puede eliminar. La formulación está en uso por uno o más productos.")
                false -> Text("¿Está seguro de que desea eliminar la formulación '${formulacion.nombre}'?")
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                enabled = isInUse == false
            ) {
                Text("Eliminar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}
