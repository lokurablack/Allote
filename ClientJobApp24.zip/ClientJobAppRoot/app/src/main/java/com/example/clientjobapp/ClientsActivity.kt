package com.example.clientjobapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.example.clientjobapp.data.AppDatabase
import com.example.clientjobapp.data.Client
import com.example.clientjobapp.ui.theme.ClientJobAppTheme
import kotlinx.coroutines.launch

class ClientsActivity : ComponentActivity() {

    private val db by lazy { AppDatabase.getDatabase(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ClientJobAppTheme {
                var refreshTrigger by remember { mutableStateOf(0) }
                var showClientDialog by remember { mutableStateOf(false) }
                var clientToEdit by remember { mutableStateOf<Client?>(null) }

                if (showClientDialog) {
                    ClientDialog(
                        client = clientToEdit,
                        onDismissRequest = {
                            showClientDialog = false
                            clientToEdit = null
                        },
                        onSave = { client ->
                            lifecycleScope.launch {
                                if (client.id == 0) {
                                    db.clientDao().insert(client)
                                    Toast.makeText(this@ClientsActivity, "Cliente añadido", Toast.LENGTH_SHORT).show()
                                } else {
                                    db.clientDao().update(client)
                                    Toast.makeText(this@ClientsActivity, "Cliente actualizado", Toast.LENGTH_SHORT).show()
                                }
                                refreshTrigger++
                                showClientDialog = false
                                clientToEdit = null
                            }
                        }
                    )
                }

                ClientsScreen(
                    onClientClick = { client ->
                        val intent = Intent(this, ClientAdministracionActivity::class.java)
                        intent.putExtra("CLIENT_ID", client.id)
                        startActivity(intent)
                    },
                    onEditClient = { client ->
                        clientToEdit = client
                        showClientDialog = true
                    },
                    onDeleteClient = { client ->
                        lifecycleScope.launch {
                            try {
                                db.jobDao().deleteJobsByClientId(client.id)
                                db.clientDao().delete(client)
                                Toast.makeText(this@ClientsActivity, "Cliente y sus trabajos eliminados", Toast.LENGTH_SHORT).show()
                                refreshTrigger++
                            } catch (e: Exception) {
                                Toast.makeText(this@ClientsActivity, "Error al eliminar: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    onAddClient = {
                        clientToEdit = null
                        showClientDialog = true
                    },
                    refreshTrigger = refreshTrigger
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClientsScreen(
    onClientClick: (Client) -> Unit,
    onEditClient: (Client) -> Unit,
    onDeleteClient: (Client) -> Unit,
    onAddClient: () -> Unit,
    refreshTrigger: Int = 0
) {
    val db = AppDatabase.getDatabase(LocalContext.current)
    var clients by remember { mutableStateOf(listOf<Client>()) }
    var filteredClients by remember { mutableStateOf(listOf<Client>()) }
    var searchQuery by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current

    LaunchedEffect(refreshTrigger) {
        scope.launch {
            clients = db.clientDao().getAll().sortedBy { it.name.lowercase() }
            filteredClients = clients
            isLoading = false
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Clientes") },
                actions = {
                    IconButton(onClick = onAddClient) {
                        Icon(Icons.Default.Add, contentDescription = "Agregar Cliente")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = {
                    searchQuery = it
                    filteredClients = if (it.isBlank()) {
                        clients
                    } else {
                        clients.filter { client -> client.name.contains(it, ignoreCase = true) ||
                                client.lastname.contains(it, ignoreCase = true) }
                    }
                },
                label = { Text("Buscar clientes") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() })
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                if (filteredClients.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No se encontraron clientes")
                    }
                } else {
                    LazyColumn {
                        items(filteredClients) { client ->
                            ClientListItem(
                                client = client,
                                onClick = { onClientClick(client) },
                                onEdit = { onEditClient(client) },
                                onDelete = { onDeleteClient(client) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ClientListItem(
    client: Client,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Confirmar eliminación") },
            text = { Text("¿Está seguro de eliminar al cliente ${client.name} ${client.lastname}?") },
            confirmButton = {
                TextButton(onClick = {
                    showDialog = false
                    onDelete()
                }) {
                    Text("Eliminar")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable { onClick() },
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${client.name} ${client.lastname}",
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.titleMedium
            )
            IconButton(onClick = onEdit) {
                Icon(Icons.Default.Edit, contentDescription = "Editar Cliente")
            }
            IconButton(onClick = { showDialog = true }) {
                Icon(Icons.Default.Delete, contentDescription = "Eliminar Cliente", tint = Color.Red)
            }
        }
    }
}