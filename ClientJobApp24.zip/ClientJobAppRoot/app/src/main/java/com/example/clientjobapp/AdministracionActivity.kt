package com.example.clientjobapp

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.clientjobapp.data.AdministracionTrabajo
import com.example.clientjobapp.data.AppDatabase
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import androidx.core.net.toUri

class AdministracionActivity : ComponentActivity() {
    private lateinit var db: AppDatabase
    private var jobId: Int = -1

    companion object {
        private const val IVA_PORCENTAJE = 0.105
        private const val PDF_VIEWER_REQUEST_CODE = 1001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        db = AppDatabase.getDatabase(this)
        jobId = intent.getIntExtra("JOB_ID", -1)

        if (jobId == -1) {
            finish()
            return
        }

        setContent {
            MaterialTheme {
                AdministracionScreen()
            }
        }
    }

    private fun getFileName(context: Context, uri: Uri): String? {
        var name: String? = null
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && nameIndex != -1) {
                name = cursor.getString(nameIndex)
            }
        }
        return name
    }

    private fun copyPdfToInternalStorageForAdministracion(uri: Uri): Uri? {
        val context = this
        val fileName = getFileName(context, uri) ?: "document.pdf"
        var file = File(context.filesDir, fileName)
        var count = 0
        while (file.exists()) {
            count++
            val newName = fileName.substringBeforeLast('.') + "_$count." + fileName.substringAfterLast('.')
            file = File(context.filesDir, newName)
        }
        return try {
            context.contentResolver.openInputStream(uri).use { inputStream ->
                FileOutputStream(file).use { outputStream ->
                    inputStream?.copyTo(outputStream)
                }
            }
            Uri.fromFile(file)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    @SuppressLint("DefaultLocale")
    @Composable
    fun AdministracionScreen() {
        var hectareas by remember { mutableDoubleStateOf(0.0) }
        var costoPorHectarea by remember { mutableStateOf("") }
        var aplicarIVA by remember { mutableStateOf(false) }
        var totalSinIVA by remember { mutableDoubleStateOf(0.0) }
        var totalConIVA by remember { mutableDoubleStateOf(0.0) }
        var showResults by remember { mutableStateOf(false) }
        var facturaUri by remember { mutableStateOf<Uri?>(null) }
        var isLoading by remember { mutableStateOf(true) }
        var isCopyingPdf by remember { mutableStateOf(false) }

        val context = LocalContext.current
        val scope = rememberCoroutineScope()

        // PDF Picker
        val pdfPickerLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.OpenDocument()
        ) { uri ->
            uri?.let {
                scope.launch {
                    isCopyingPdf = true
                    try {
                        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        val internalUri = copyPdfToInternalStorageForAdministracion(uri)
                        if (internalUri != null) {
                            guardarFacturaEnDB(internalUri)
                            facturaUri = internalUri
                            Toast.makeText(context, "Factura cargada exitosamente", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Error al copiar el archivo PDF a almacenamiento interno", Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(context, "Error al cargar factura", Toast.LENGTH_SHORT).show()
                    } finally {
                        isCopyingPdf = false
                    }
                }
            }
        }

        // PDF Viewer Launcher to handle result when PDF is deleted
        val pdfViewerLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == RESULT_OK) {
                // PDF was deleted, update UI to allow new upload
                facturaUri = null
                Toast.makeText(context, "Factura eliminada, puede cargar un nuevo archivo PDF.", Toast.LENGTH_SHORT).show()
            }
        }

        // Cargar datos iniciales
        LaunchedEffect(Unit) {
            try {
                val job = db.jobDao().getById(jobId)
                if (job != null) {
                    hectareas = job.surface

                    val registroExistente = db.administracionDao().getByJobId(jobId)
                    if (registroExistente != null) {
                        costoPorHectarea = registroExistente.costoPorHectarea.toString()
                        aplicarIVA = registroExistente.aplicaIVA
                        totalSinIVA = registroExistente.totalSinIVA
                        totalConIVA = registroExistente.totalConIVA
                        showResults = true
                        facturaUri = registroExistente.facturaUri?.toUri()
                    } else {
                        // Cargar valor por defecto desde SettingsActivity SharedPreferences
                        val sharedPrefs = getSharedPreferences("com.example.clientjobapp_preferences", MODE_PRIVATE)
                        val tipoAplicacion = job.tipoAplicacion ?: ""
                        val defaultPriceString = when (tipoAplicacion.lowercase()) {
                            "aplicacion liquida" -> sharedPrefs.getString("precio_liquida", "0.0")
                            "aplicacion solida" -> sharedPrefs.getString("precio_solida", "0.0")
                            "aplicacion mixta" -> sharedPrefs.getString("precio_mixta", "0.0")
                            "aplicaciones varias" -> sharedPrefs.getString("precio_varias", "0.0")
                            else -> "0.0"
                        }
                        val valorDefecto = defaultPriceString?.toFloatOrNull() ?: 0.0f
                        if (valorDefecto > 0) {
                            costoPorHectarea = valorDefecto.toString()
                        }
                    }
                } else {
                    Toast.makeText(context, "Trabajo no encontrado", Toast.LENGTH_SHORT).show()
                    finish()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Error al cargar datos", Toast.LENGTH_SHORT).show()
            } finally {
                isLoading = false
            }
        }

        // UI
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .systemBarsPadding()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Administración de Trabajo",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Hectáreas: $hectareas",
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            }

            if (isLoading) {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            } else {
                // Formulario
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Cálculo de Costos",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )

                        OutlinedTextField(
                            value = costoPorHectarea,
                            onValueChange = { newValue ->
                                if (newValue.isEmpty() || newValue.matches(Regex("^\\d*\\.?\\d*$"))) {
                                    costoPorHectarea = newValue
                                }
                            },
                            label = { Text("Costo por Hectárea (USD)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = aplicarIVA,
                                onCheckedChange = { aplicarIVA = it }
                            )
                            Text("Aplicar IVA (10.5%)")
                        }

                        Button(
                            onClick = {
                                val costo = costoPorHectarea.toDoubleOrNull()
                                if (costo != null) {
                                    totalSinIVA = hectareas * costo
                                    totalConIVA = if (aplicarIVA) totalSinIVA * (1 + IVA_PORCENTAJE) else totalSinIVA
                                    showResults = true
                                } else {
                                    Toast.makeText(context, "Ingrese un costo válido", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Calcular")
                        }
                    }
                }

                // Resultados
                if (showResults) {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "Resultados",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text("Total sin IVA: USD ${String.format("%.2f", totalSinIVA)}")
                            Text("Total con IVA: USD ${String.format("%.2f", totalConIVA)}")
                        }
                    }
                }

                // Botones de acción
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = {
                                scope.launch {
                                    val costo = costoPorHectarea.toDoubleOrNull()
                                    if (costo != null && showResults) {
                                        try {
                                            guardarDatos(costo, aplicarIVA, totalSinIVA, totalConIVA, facturaUri)
                                            Toast.makeText(context, "Guardado exitosamente", Toast.LENGTH_SHORT).show()
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "Error al guardar", Toast.LENGTH_SHORT).show()
                                        }
                                    } else {
                                        Toast.makeText(context, "Calcule primero los totales", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Guardar")
                        }

                        OutlinedButton(
                            onClick = {
                                val intent = Intent(context, PdfViewerActivity::class.java)
                                intent.putExtra("JOB_ID", jobId)
                                pdfViewerLauncher.launch(intent)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Documentos")
                        }


                        OutlinedButton(
                            onClick = {
                                val intent = Intent(context, AdministracionResumenActivity::class.java)
                                intent.putExtra("JOB_ID", jobId)
                                startActivity(intent)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Ver Resumen")
                        }
                    }
                }
            }
        }
    }

    private suspend fun guardarDatos(
        costo: Double,
        aplicaIVA: Boolean,
        sinIVA: Double,
        conIVA: Double,
        uri: Uri?
    ) {
        val registroExistente = db.administracionDao().getByJobId(jobId)
        val administracionTrabajo = AdministracionTrabajo(
            id = registroExistente?.id ?: 0,
            jobId = jobId,
            facturaUri = uri?.toString(),
            costoPorHectarea = costo,
            totalSinIVA = sinIVA,
            totalConIVA = conIVA,
            aplicaIVA = aplicaIVA
        )
        db.administracionDao().insert(administracionTrabajo)
    }

    private suspend fun guardarFacturaEnDB(uri: Uri) {
        val registroExistente = db.administracionDao().getByJobId(jobId)
        val administracionTrabajo = AdministracionTrabajo(
            id = registroExistente?.id ?: 0,
            jobId = jobId,
            facturaUri = uri.toString(),
            costoPorHectarea = registroExistente?.costoPorHectarea ?: 0.0,
            totalSinIVA = registroExistente?.totalSinIVA ?: 0.0,
            totalConIVA = registroExistente?.totalConIVA ?: 0.0,
            aplicaIVA = registroExistente?.aplicaIVA ?: false
        )
        db.administracionDao().insert(administracionTrabajo)
    }
}