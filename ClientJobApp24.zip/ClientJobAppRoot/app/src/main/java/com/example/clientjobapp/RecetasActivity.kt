package com.example.clientjobapp

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.clientjobapp.data.AppDatabase
import com.example.clientjobapp.data.Formulacion
import com.example.clientjobapp.data.Product
import com.example.clientjobapp.data.Recipe
import com.example.clientjobapp.data.RecipeProduct
import kotlinx.coroutines.launch

class RecetasActivity : ComponentActivity() {

    private val viewModel: RecetasViewModel by viewModels {
        RecetasViewModel.Factory(AppDatabase.getDatabase(this), intent.getIntExtra(Constants.EXTRA_JOB_ID, -1))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (viewModel.jobId == -1) {
            Toast.makeText(this, Constants.ERROR_NO_JOB_SPECIFIED, Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        setContent {
            RecetasScreen(viewModel)
        }

        viewModel.loadReceta()
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun RecetasScreen(viewModel: RecetasViewModel) {
        val context = LocalContext.current
        val scrollState = rememberScrollState()

        var hectareasText by remember { mutableStateOf("") }
        var caudalText by remember { mutableStateOf("") }
        var caldoPorTachadaText by remember { mutableStateOf("") }
        var resumenText by remember { mutableStateOf(Constants.RESUMEN_TEXT) }
        var showAgregarDialog by remember { mutableStateOf(false) }
        var showActionMenu by remember { mutableStateOf(false) }
        var showEditDialog by remember { mutableStateOf(false) }
        var showDeleteDialog by remember { mutableStateOf(false) }

        // Observe receta state changes
        LaunchedEffect(viewModel.receta) {
            viewModel.receta?.let {
                hectareasText = it.hectareas.toString()
                caudalText = it.caudal.toString()
                caldoPorTachadaText = if (it.caldoPorTachada > 0) it.caldoPorTachada.toString() else ""
                resumenText = if (it.resumen.isBlank()) Constants.RESUMEN_TEXT else it.resumen
            }
        }

        // Observe resumen update from calculation
        LaunchedEffect(viewModel.resumenActual) {
            viewModel.resumenActual?.let {
                resumenText = it
            }
        }

        Scaffold(
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { showAgregarDialog = true },
                    containerColor = MaterialTheme.colorScheme.primary
                ) {
                    Icon(Icons.Filled.Add, contentDescription = Constants.CONTENT_DESC_ADD_PRODUCT)
                }
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .padding(paddingValues)
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .background(Color.White)
                    .padding(16.dp)
            ) {
                Text(
                    text = "Recetas",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth(),
                    color = Color.Black
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = hectareasText,
                    onValueChange = { hectareasText = it },
                    label = { Text("Hectáreas") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = caudalText,
                    onValueChange = { caudalText = it },
                    label = { Text("Caudal (L/ha)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = caldoPorTachadaText,
                    onValueChange = { caldoPorTachadaText = it },
                    label = { Text("Caldo a preparar por tachada (L)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        val hectareas = hectareasText.toDoubleOrNull()
                        val caudal = caudalText.toDoubleOrNull()
                        val caldoPorTachada = caldoPorTachadaText.toDoubleOrNull()
                        if (!viewModel.validateInputs(hectareas, caudal, context)) return@Button
                        viewModel.calcularReceta(hectareas!!, caudal!!, caldoPorTachada, context)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Calcular Receta")
                }
                Spacer(modifier = Modifier.height(12.dp))
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 0.dp, max = 300.dp)
                ) {
                    items(viewModel.productosReceta) { item ->
                        ProductoRecetaItemView(item)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .combinedClickable(
                            onClick = { },
                            onLongClick = {
                                if (viewModel.receta != null && resumenText != Constants.RESUMEN_TEXT) {
                                    showActionMenu = true
                                }
                            }
                        ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    Column {
                        Text(
                            text = resumenText,
                            fontSize = 16.sp,
                            color = Color.Black,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        )
                    }
                }
            }
        }

        if (showAgregarDialog) {
            AgregarProductoDialog(
                onDismiss = { showAgregarDialog = false },
                onAgregar = { nombre, dosis ->
                    if (nombre.isBlank() || dosis.isBlank()) {
                        Toast.makeText(this, "Debe ingresar producto y dosis", Toast.LENGTH_SHORT).show()
                        return@AgregarProductoDialog
                    }
                    val dosisDouble = dosis.toDoubleOrNull()
                    if (dosisDouble == null || dosisDouble <= 0) {
                        Toast.makeText(this, "Dosis inválida", Toast.LENGTH_SHORT).show()
                        return@AgregarProductoDialog
                    }
                    viewModel.agregarProducto(nombre, dosisDouble, this)
                    showAgregarDialog = false
                }
            )
        }

        if (showActionMenu) {
            AlertDialog(
                onDismissRequest = { showActionMenu = false },
                title = { Text("Opciones de Receta") },
                text = { Text("¿Qué desea hacer con esta receta?") },
                confirmButton = {
                    Row {
                        TextButton(
                            onClick = {
                                showActionMenu = false
                                showEditDialog = true
                            }
                        ) {
                            Text("Editar")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        TextButton(
                            onClick = {
                                showActionMenu = false
                                showDeleteDialog = true
                            }
                        ) {
                            Text("Eliminar", color = MaterialTheme.colorScheme.error)
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showActionMenu = false }) {
                        Text("Cancelar")
                    }
                }
            )
        }

        if (showEditDialog) {
            EditarRecetaDialog(
                hectareasActual = hectareasText,
                caudalActual = caudalText,
                caldoPorTachadaActual = caldoPorTachadaText,
                onDismiss = { showEditDialog = false },
                onConfirmar = { nuevasHectareas, nuevoCaudal, nuevoCaldoPorTachada ->
                    hectareasText = nuevasHectareas
                    caudalText = nuevoCaudal
                    caldoPorTachadaText = nuevoCaldoPorTachada
                    val hectareas = nuevasHectareas.toDoubleOrNull()
                    val caudal = nuevoCaudal.toDoubleOrNull()
                    val caldoPorTachada = nuevoCaldoPorTachada.toDoubleOrNull()
                    if (hectareas != null && hectareas > 0 && caudal != null && caudal > 0) {
                        viewModel.calcularReceta(hectareas, caudal, caldoPorTachada, context)
                        Toast.makeText(context, "Receta actualizada", Toast.LENGTH_SHORT).show()
                    }
                    showEditDialog = false
                }
            )
        }

        if (showDeleteDialog) {
            AlertDialog(
                onDismissRequest = { showDeleteDialog = false },
                title = { Text("Eliminar Receta") },
                text = { Text("¿Está seguro de que desea eliminar esta receta? Esta acción no se puede deshacer.") },
                confirmButton = {
                    TextButton(
                        onClick = {
                            viewModel.eliminarReceta {
                                Toast.makeText(context, "Receta eliminada", Toast.LENGTH_SHORT).show()
                            }
                            showDeleteDialog = false
                        }
                    ) {
                        Text("Eliminar", color = MaterialTheme.colorScheme.error)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteDialog = false }) {
                        Text("Cancelar")
                    }
                }
            )
        }
    }

    @Composable
    fun EditarRecetaDialog(
        hectareasActual: String,
        caudalActual: String,
        caldoPorTachadaActual: String,
        onDismiss: () -> Unit,
        onConfirmar: (String, String, String) -> Unit
    ) {
        var hectareas by remember { mutableStateOf(hectareasActual) }
        var caudal by remember { mutableStateOf(caudalActual) }
        var caldoPorTachada by remember { mutableStateOf(caldoPorTachadaActual) }

        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Editar Receta") },
            text = {
                Column {
                    OutlinedTextField(
                        value = hectareas,
                        onValueChange = { hectareas = it },
                        label = { Text("Hectáreas") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = caudal,
                        onValueChange = { caudal = it },
                        label = { Text("Caudal (L/ha)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = caldoPorTachada,
                        onValueChange = { caldoPorTachada = it },
                        label = { Text("Caldo a preparar por tachada (L)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val hectareasDouble = hectareas.toDoubleOrNull()
                        val caudalDouble = caudal.toDoubleOrNull()
                        if (hectareasDouble == null || hectareasDouble <= 0) {
                            Toast.makeText(this@RecetasActivity, "Ingrese un valor válido para hectáreas", Toast.LENGTH_SHORT).show()
                            return@TextButton
                        }
                        if (caudalDouble == null || caudalDouble <= 0) {
                            Toast.makeText(this@RecetasActivity, "Ingrese un valor válido para caudal", Toast.LENGTH_SHORT).show()
                            return@TextButton
                        }
                        onConfirmar(hectareas, caudal, caldoPorTachada)
                    }
                ) {
                    Text("Guardar")
                }
            },
            dismissButton = {
                TextButton(onClick = onDismiss) {
                    Text("Cancelar")
                }
            }
        )
    }

    @Composable
    fun ProductoRecetaItemView(item: RecetasViewModel.ProductoRecetaItem) {
        val unidad = if (item.tipoUnidad == "SOLIDO") "kg" else "litros"
        val bandaColorMap = mapOf(
            "la" to Color(0xFFFF0000),
            "lb" to Color(0xFFFF0000),
            "ii" to Color(0xFFFFC107),
            "iii" to Color(0xFF00008B),
            "iv" to Color(0xFF388E3C)
        )
        val bandaKey = item.bandaToxicologica?.trim()?.lowercase() ?: ""
        val color = bandaColorMap[bandaKey] ?: Color.Black

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .height(80.dp)
                .clickable { }
                .padding(8.dp)
        ) {
            Text(
                text = item.nombreComercial,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
            Text(
                text = "Dosis: %.2f".format(item.dosis),
                fontSize = 14.sp,
                color = Color.DarkGray
            )
            Text(
                text = "Cantidad total: %.2f %s".format(item.cantidadTotal, unidad),
                fontSize = 14.sp,
                color = Color.DarkGray
            )
        }
    }

    @Composable
    fun AgregarProductoDialog(
        onDismiss: () -> Unit,
        onAgregar: (String, String) -> Unit
    ) {
        var nombreProducto by remember { mutableStateOf("") }
        var dosis by remember { mutableStateOf("") }
        var suggestions by remember { mutableStateOf(listOf<Product>()) }
        val context = LocalContext.current

        LaunchedEffect(nombreProducto) {
            if (nombreProducto.isNotBlank()) {
                try {
                    val results = viewModel.searchProductsAsync(nombreProducto, context)
                    suggestions = results
                } catch (e: Exception) {
                    suggestions = emptyList()
                }
            } else {
                suggestions = emptyList()
            }
        }

        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Agregar Producto") },
            text = {
                Column {
                    OutlinedTextField(
                        value = nombreProducto,
                        onValueChange = { nombreProducto = it },
                        label = { Text("Buscar producto (nombre o principio activo)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (suggestions.isNotEmpty()) {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 150.dp)
                                .background(Color.White)
                        ) {
                            itemsIndexed(suggestions) { _, product ->
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            nombreProducto = product.nombreComercial
                                            suggestions = emptyList()
                                        }
                                        .padding(8.dp)
                                ) {
                                    Text(
                                        text = product.nombreComercial,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.Black
                                    )
                                    Text(
                                        text = product.principioActivo,
                                        color = Color.Gray,
                                        fontSize = 12.sp
                                    )
                                }
                                Divider()
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = dosis,
                        onValueChange = { dosis = it },
                        label = { Text("Dosis (L/ha o gramos)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    onAgregar(nombreProducto, dosis)
                    onDismiss()
                }) {
                    Text("Agregar")
                }
            },
            dismissButton = {
                TextButton(onClick = onDismiss) {
                    Text("Cancelar")
                }
            }
        )
    }
}

class RecetasViewModel(
    private val db: AppDatabase,
    val jobId: Int
) : ViewModel() {

    data class ProductoRecetaItem(
        val id: Int,
        val productId: Int,
        val nombreComercial: String,
        val dosis: Double,
        val cantidadTotal: Double,
        val ordenMezclado: Int,
        val bandaToxicologica: String? = null,
        val tipoUnidad: String
    )

    var receta by mutableStateOf<Recipe?>(null)
        private set

    var productosReceta = mutableStateListOf<ProductoRecetaItem>()

    var resumenActual by mutableStateOf<String?>(null)

    private var formulaciones: List<Formulacion> = emptyList()

    fun loadReceta() {
        viewModelScope.launch {
            formulaciones = db.formulacionDao().getAllFormulaciones()
            val job = db.jobDao().getById(jobId)
            if (job != null && receta == null) {
                receta = receta ?: Recipe(
                    jobId = jobId,
                    hectareas = job.surface,
                    caudal = 0.0,
                    totalCaldo = 0.0,
                    fechaCreacion = System.currentTimeMillis()
                )
            }

            receta = db.recipeDao().getRecipeByJobId(jobId)

            receta?.let {
                productosReceta.clear()
                val productosEnReceta = db.recipeDao().getRecipeProductsByRecipeId(it.id)
                val allProducts = db.productDao().getAll()

                productosReceta.addAll(productosEnReceta.mapNotNull { rp ->
                    val product = allProducts.find { p -> p.id == rp.productId }
                    val formulacion = formulaciones.find { f -> f.id == product?.formulacionId }
                    if (product != null && formulacion != null) {
                        ProductoRecetaItem(
                            id = rp.id,
                            productId = rp.productId,
                            nombreComercial = product.nombreComercial,
                            dosis = rp.dosis,
                            cantidadTotal = rp.cantidadTotal,
                            ordenMezclado = formulacion.ordenMezcla,
                            bandaToxicologica = product.bandaToxicologica,
                            tipoUnidad = formulacion.tipoUnidad
                        )
                    } else {
                        null
                    }
                })
                calcularReceta(it.hectareas, it.caudal, if (it.caldoPorTachada > 0) it.caldoPorTachada else null, null)
            }
        }
    }

    fun validateInputs(hectareas: Double?, caudal: Double?, context: Context): Boolean {
        if (hectareas == null || hectareas <= 0) {
            Toast.makeText(context, "Ingrese un valor válido para hectáreas", Toast.LENGTH_SHORT).show()
            return false
        }
        if (caudal == null || caudal <= 0) {
            Toast.makeText(context, "Ingrese un valor válido para caudal", Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }

    fun agregarProducto(nombre: String, dosis: Double, context: Context) {
        viewModelScope.launch {
            val producto = db.productDao().getAll().find {
                it.nombreComercial.equals(nombre, true) || it.principioActivo.equals(nombre, true)
            }
            if (producto == null) {
                Toast.makeText(context, "Producto no encontrado", Toast.LENGTH_SHORT).show()
                return@launch
            }
            val formulacion = formulaciones.find { it.id == producto.formulacionId }
            if (formulacion == null) {
                Toast.makeText(context, "Formulación no encontrada para el producto", Toast.LENGTH_SHORT).show()
                return@launch
            }

            val item = ProductoRecetaItem(
                id = 0,
                productId = producto.id,
                nombreComercial = producto.nombreComercial,
                dosis = dosis,
                cantidadTotal = 0.0,
                ordenMezclado = formulacion.ordenMezcla,
                bandaToxicologica = producto.bandaToxicologica,
                tipoUnidad = formulacion.tipoUnidad
            )
            productosReceta.add(item)
        }
    }

    suspend fun searchProductsAsync(query: String, context: Context): List<Product> {
        return db.productDao().searchByName("%$query%")
    }

    fun calcularReceta(hectareas: Double, caudal: Double, caldoPorTachada: Double?, context: Context?) {
        viewModelScope.launch {
            if (context == null) return@launch

            val tankCapacity = caldoPorTachada
            var totalProductos = 0.0

            productosReceta.forEachIndexed { index, item ->
                val cantidadTotal = if (item.tipoUnidad == "SOLIDO") {
                    (item.dosis * hectareas) / 1000 // Convertir gramos a kg
                } else {
                    item.dosis * hectareas
                }
                productosReceta[index] = item.copy(cantidadTotal = cantidadTotal)
                totalProductos += cantidadTotal
            }

            val totalCaldo = caudal * hectareas
            val agua = totalCaldo - totalProductos

            if (agua < 0) {
                Toast.makeText(context, "Error en la receta (la cantidad de producto supera la de agua).", Toast.LENGTH_LONG).show()
                return@launch
            }

            productosReceta.sortBy { it.ordenMezclado }

            val resumenBuilder = StringBuilder()
            resumenBuilder.append("🔍 RESUMEN DE LA RECETA\n")
            resumenBuilder.append("Total Caldo: %.2f L\n".format(totalCaldo))
            resumenBuilder.append("Total Agua: %.2f L\n".format(agua))
            resumenBuilder.append("Total Productos: %.2f L\n".format(totalProductos))

            if (tankCapacity == null || tankCapacity <= 0 || totalCaldo <= tankCapacity) {
                resumenBuilder.append("🧪 Carga única\n")
                resumenBuilder.append("💧 Agua: %.2f L\n".format(agua))
                productosReceta.forEach {
                    val unidad = if (it.tipoUnidad == "SOLIDO") "kg" else "litros"
                    resumenBuilder.append("• %s: %.2f %s\n".format(it.nombreComercial.ifBlank { "-" }, it.cantidadTotal, unidad))
                }
            } else {
                val numCargasCompletas = (totalCaldo / tankCapacity).toInt()
                val cargaFinal = totalCaldo % tankCapacity

                // Calcular proporciones
                val proporcionCargaCompleta = tankCapacity / totalCaldo
                val proporcionCargaFinal = cargaFinal / totalCaldo

                // Calcular cantidades para carga completa
                var sumaProductosCompleta = 0.0
                val dosisCompletaMap = productosReceta.associate { producto ->
                    val dosisCarga = producto.dosis * hectareas * proporcionCargaCompleta
                    val dosisFinal = if (producto.tipoUnidad == "SOLIDO") dosisCarga / 1000 else dosisCarga
                    sumaProductosCompleta += dosisFinal
                    producto to dosisFinal
                }
                val aguaCargaCompleta = tankCapacity - sumaProductosCompleta

                // Mostrar cargas completas agrupadas
                if (numCargasCompletas > 0) {
                    resumenBuilder.append("\n🧪 Cargas 1 a $numCargasCompletas (%.2f L c/u)\n".format(tankCapacity))
                    resumenBuilder.append("💧 Agua: %.2f L\n".format(aguaCargaCompleta))
                    productosReceta.forEach { producto ->
                        val unidad = if (producto.tipoUnidad == "SOLIDO") "kg" else "litros"
                        resumenBuilder.append("• %s: %.2f %s\n".format(producto.nombreComercial.ifBlank { "-" }, dosisCompletaMap[producto], unidad))
                    }
                }

                // Mostrar carga final si existe
                if (cargaFinal > 0) {
                    var sumaProductosFinal = 0.0
                    resumenBuilder.append("\n🧪 Carga ${numCargasCompletas + 1} (%.2f L)\n".format(cargaFinal))
                    
                    productosReceta.forEach { producto ->
                        val dosisCarga = producto.dosis * hectareas * proporcionCargaFinal
                        val dosisFinal = if (producto.tipoUnidad == "SOLIDO") dosisCarga / 1000 else dosisCarga
                        sumaProductosFinal += dosisFinal
                        val unidad = if (producto.tipoUnidad == "SOLIDO") "kg" else "litros"
                        resumenBuilder.append("• %s: %.2f %s\n".format(producto.nombreComercial.ifBlank { "-" }, dosisFinal, unidad))
                    }
                    
                    val aguaCargaFinal = cargaFinal - sumaProductosFinal
                    resumenBuilder.append("💧 Agua: %.2f L\n".format(aguaCargaFinal))
                }
            }

            val resumenFinal = resumenBuilder.toString()
            resumenActual = resumenFinal

            if (receta == null) {
                val nuevaReceta = Recipe(
                    jobId = jobId,
                    hectareas = hectareas,
                    caudal = caudal,
                    caldoPorTachada = tankCapacity ?: 0.0,
                    totalCaldo = totalCaldo,
                    fechaCreacion = System.currentTimeMillis(),
                    resumen = resumenFinal
                )
                val idReceta = db.recipeDao().insertRecipe(nuevaReceta)
                receta = nuevaReceta.copy(id = idReceta.toInt())
            } else {
                receta = receta!!.copy(
                    hectareas = hectareas,
                    caudal = caudal,
                    caldoPorTachada = tankCapacity ?: 0.0,
                    totalCaldo = totalCaldo,
                    fechaCreacion = System.currentTimeMillis(),
                    resumen = resumenFinal
                )
                db.recipeDao().updateRecipe(receta!!)
                db.recipeDao().deleteRecipeProductsByRecipeId(receta!!.id)
            }

            receta?.let { rec ->
                productosReceta.forEach { item ->
                    val rp = RecipeProduct(
                        recipeId = rec.id,
                        productId = item.productId,
                        dosis = item.dosis,
                        cantidadTotal = item.cantidadTotal,
                        ordenMezclado = item.ordenMezclado
                    )
                    db.recipeDao().insertRecipeProduct(rp)
                }
            }
        }
    }

    fun eliminarReceta(onComplete: () -> Unit) {
        viewModelScope.launch {
            receta?.let { rec ->
                db.recipeDao().deleteRecipeProductsByRecipeId(rec.id)
                db.recipeDao().deleteRecipe(rec)

                receta = null
                productosReceta.clear()

                onComplete()
            }
        }
    }

    class Factory(
        private val db: AppDatabase,
        private val jobId: Int
    ) : androidx.lifecycle.ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(RecetasViewModel::class.java)) {
                return RecetasViewModel(db, jobId) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}

object Constants {
    const val EXTRA_JOB_ID = "JOB_ID"
    const val ERROR_NO_JOB_SPECIFIED = "Error: Trabajo no especificado"
    const val RESUMEN_TEXT = "Resumen"
    const val CONTENT_DESC_ADD_PRODUCT = "Agregar Producto"
}
