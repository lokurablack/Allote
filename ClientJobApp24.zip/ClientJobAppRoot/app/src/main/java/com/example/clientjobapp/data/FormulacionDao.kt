package com.example.clientjobapp.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Delete
import androidx.room.Query
import androidx.room.Update

@Dao
interface FormulacionDao {

    @Query("SELECT * FROM formulaciones ORDER BY ordenMezcla ASC")
    suspend fun getAllFormulaciones(): List<Formulacion>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(formulaciones: List<Formulacion>)

    @Update
    suspend fun updateFormulaciones(formulaciones: List<Formulacion>)

    @Delete
    suspend fun delete(formulaciones: List<Formulacion>)

    @Query("SELECT COUNT(*) FROM products WHERE formulacionId = :nombreFormulacion")
    suspend fun getProductCountForFormulacion(nombreFormulacion: String): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(formulacion: Formulacion): Long
}
