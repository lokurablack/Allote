package com.example.clientjobapp.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.clientjobapp.AdministracionGeneralViewModel

@Composable
fun AdministracionGeneralScreen(viewModel: AdministracionGeneralViewModel) {
    val totals = viewModel.totals.collectAsState()

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .verticalScroll(scrollState)
            .systemBarsPadding()
            .padding(16.dp)
    ) {
        Text(
            text = "Total trabajos finalizados: UsD ${"%.2f".format(totals.value.totalFinalizados)}",
            fontSize = 18.sp,
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            style = MaterialTheme.typography.bodyLarge
        )
        Text(
            text = "Total trabajos pendientes: UsD ${"%.2f".format(totals.value.totalPendientes)}",
            fontSize = 18.sp,
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            style = MaterialTheme.typography.bodyLarge
        )
        Text(
            text = "Total trabajos no facturados: UsD ${"%.2f".format(totals.value.totalNoFacturados)}",
            fontSize = 18.sp,
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            style = MaterialTheme.typography.bodyLarge
        )
        Text(
            text = "Total trabajos facturados: UsD ${"%.2f".format(totals.value.totalFacturados)}",
            fontSize = 18.sp,
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            style = MaterialTheme.typography.bodyLarge
        )
        Text(
            text = "Total trabajos pagados: UsD ${"%.2f".format(totals.value.totalPagados)}",
            fontSize = 18.sp,
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            style = MaterialTheme.typography.bodyLarge
        )
    }
}
