package com.example.clientjobapp

import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.lifecycleScope
import com.example.clientjobapp.data.AppDatabase
import com.example.clientjobapp.data.Formulacion
import com.example.clientjobapp.data.Product
import com.example.clientjobapp.ui.ProductDetailScreen
import kotlinx.coroutines.launch

class ProductDetailActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private var productId: Int = -1

    private var currentProduct by mutableStateOf<Product?>(null)
    private var formulacionName by mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        db = AppDatabase.getDatabase(this)
        productId = intent.getIntExtra("PRODUCT_ID", -1)

        if (productId == -1) {
            finish()
            return
        }

        lifecycleScope.launch {
            val product = db.productDao().getAll().find { it.id == productId }
            if (product != null) {
                val formulacion = db.formulacionDao().getAllFormulaciones().find { it.id == product.formulacionId }
                currentProduct = product
                formulacionName = formulacion?.nombre ?: "Desconocida"
                
                runOnUiThread {
                    setContent {
                        ProductDetailScreen(
                            product = currentProduct,
                            formulacionName = formulacionName,
                            onUpdateProduct = { updatedProduct ->
                                lifecycleScope.launch {
                                    db.productDao().update(updatedProduct)
                                    runOnUiThread {
                                        Toast.makeText(this@ProductDetailActivity, "Datos guardados correctamente", Toast.LENGTH_SHORT).show()
                                        currentProduct = updatedProduct
                                    }
                                }
                            }
                        )
                    }
                }
            } else {
                finish()
            }
        }
    }
}
