package com.example.clientjobapp

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import android.content.Intent
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                SettingsScreen()
            }
        }
    }
}

// Pantalla de configuración de precios
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PricesScreen(
    precioLiquida: String,
    precioSolida: String,
    precioMixta: String,
    precioVarias: String,
    onPrecioLiquidaChange: (String) -> Unit,
    onPrecioSolidaChange: (String) -> Unit,
    onPrecioMixtaChange: (String) -> Unit,
    onPrecioVariasChange: (String) -> Unit,
    onDismiss: () -> Unit
) {
    // Estados para controlar los diálogos de precios
    var showPrecioLiquidaDialog by remember { mutableStateOf(false) }
    var showPrecioSolidaDialog by remember { mutableStateOf(false) }
    var showPrecioMixtaDialog by remember { mutableStateOf(false) }
    var showPrecioVariasDialog by remember { mutableStateOf(false) }

    // Estados temporales para los diálogos
    var tempPrecioLiquida by remember { mutableStateOf("") }
    var tempPrecioSolida by remember { mutableStateOf("") }
    var tempPrecioMixta by remember { mutableStateOf("") }
    var tempPrecioVarias by remember { mutableStateOf("") }

    // Pantalla completa con fondo
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            // TopAppBar
            TopAppBar(
                title = { Text("Configurar Precios") },
                navigationIcon = {
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Cerrar"
                        )
                    }
                }
            )

            // Contenido
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "Configure los precios por hectárea para cada tipo de aplicación",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 24.dp)
                )

                // Precio Aplicación Líquida
                TextPreference(
                    title = "Aplicación Líquida",
                    summary = if (precioLiquida.isNotEmpty()) "${precioLiquida}/Ha" else "No establecido",
                    onClick = {
                        tempPrecioLiquida = precioLiquida
                        showPrecioLiquidaDialog = true
                    }
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                // Precio Aplicación Sólida
                TextPreference(
                    title = "Aplicación Sólida",
                    summary = if (precioSolida.isNotEmpty()) "${precioSolida}/Ha" else "No establecido",
                    onClick = {
                        tempPrecioSolida = precioSolida
                        showPrecioSolidaDialog = true
                    }
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                // Precio Aplicación Mixta
                TextPreference(
                    title = "Aplicación Mixta",
                    summary = if (precioMixta.isNotEmpty()) "${precioMixta}/Ha" else "No establecido",
                    onClick = {
                        tempPrecioMixta = precioMixta
                        showPrecioMixtaDialog = true
                    }
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                // Precio Aplicaciones Varias
                TextPreference(
                    title = "Aplicaciones Varias",
                    summary = if (precioVarias.isNotEmpty()) "${precioVarias}/Ha" else "No establecido",
                    onClick = {
                        tempPrecioVarias = precioVarias
                        showPrecioVariasDialog = true
                    }
                )
            }
        }
    }

    // Diálogos para cada precio
    if (showPrecioLiquidaDialog) {
        PriceDialog(
            title = "Precio Aplicación Líquida",
            value = tempPrecioLiquida,
            onValueChange = { tempPrecioLiquida = it },
            onConfirm = {
                onPrecioLiquidaChange(tempPrecioLiquida)
                showPrecioLiquidaDialog = false
            },
            onDismiss = { showPrecioLiquidaDialog = false }
        )
    }

    if (showPrecioSolidaDialog) {
        PriceDialog(
            title = "Precio Aplicación Sólida",
            value = tempPrecioSolida,
            onValueChange = { tempPrecioSolida = it },
            onConfirm = {
                onPrecioSolidaChange(tempPrecioSolida)
                showPrecioSolidaDialog = false
            },
            onDismiss = { showPrecioSolidaDialog = false }
        )
    }

    if (showPrecioMixtaDialog) {
        PriceDialog(
            title = "Precio Aplicación Mixta",
            value = tempPrecioMixta,
            onValueChange = { tempPrecioMixta = it },
            onConfirm = {
                onPrecioMixtaChange(tempPrecioMixta)
                showPrecioMixtaDialog = false
            },
            onDismiss = { showPrecioMixtaDialog = false }
        )
    }

    if (showPrecioVariasDialog) {
        PriceDialog(
            title = "Precio Aplicaciones Varias",
            value = tempPrecioVarias,
            onValueChange = { tempPrecioVarias = it },
            onConfirm = {
                onPrecioVariasChange(tempPrecioVarias)
                showPrecioVariasDialog = false
            },
            onDismiss = { showPrecioVariasDialog = false }
        )
    }
}

// Función para generar resumen de precios
fun getPricesSummary(liquida: String, solida: String, mixta: String, varias: String): String {
    val configurados = listOfNotNull(
        if (liquida.isNotEmpty()) "Líquida" else null,
        if (solida.isNotEmpty()) "Sólida" else null,
        if (mixta.isNotEmpty()) "Mixta" else null,
        if (varias.isNotEmpty()) "Varias" else null
    )

    return if (configurados.isEmpty()) {
        "No configurado"
    } else {
        "${configurados.size} de 4 tipos configurados"
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val sharedPrefs = remember {
        context.getSharedPreferences("com.example.clientjobapp_preferences", Context.MODE_PRIVATE)
    }

    // Estados para cada preferencia
    var notificationsEnabled by remember {
        mutableStateOf(sharedPrefs.getBoolean("notifications", true))
    }

    var username by remember {
        mutableStateOf(sharedPrefs.getString("username", "") ?: "")
    }

    var tankCapacity by remember {
        mutableStateOf(sharedPrefs.getString("tank_capacity", "") ?: "")
    }

    // Estados para precios
    var precioLiquida by remember {
        mutableStateOf(sharedPrefs.getString("precio_liquida", "") ?: "")
    }

    var precioSolida by remember {
        mutableStateOf(sharedPrefs.getString("precio_solida", "") ?: "")
    }

    var precioMixta by remember {
        mutableStateOf(sharedPrefs.getString("precio_mixta", "") ?: "")
    }

    var precioVarias by remember {
        mutableStateOf(sharedPrefs.getString("precio_varias", "") ?: "")
    }

    // Estados para controlar los diálogos
    var showUsernameDialog by remember { mutableStateOf(false) }
    var showTankCapacityDialog by remember { mutableStateOf(false) }
    var showPricesScreen by remember { mutableStateOf(false) }

    // Estados para controlar los diálogos de precios
    var showPrecioLiquidaDialog by remember { mutableStateOf(false) }
    var showPrecioSolidaDialog by remember { mutableStateOf(false) }
    var showPrecioMixtaDialog by remember { mutableStateOf(false) }
    var showPrecioVariasDialog by remember { mutableStateOf(false) }

    // Estados temporales para los diálogos
    var tempUsername by remember { mutableStateOf("") }
    var tempTankCapacity by remember { mutableStateOf("") }
    var tempPrecioLiquida by remember { mutableStateOf("") }
    var tempPrecioSolida by remember { mutableStateOf("") }
    var tempPrecioMixta by remember { mutableStateOf("") }
    var tempPrecioVarias by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Título de la categoría
        Text(
            text = "General Settings",
            fontSize = 18.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Switch para notificaciones
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = "Enable notifications",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Normal
                )
            }
            Switch(
                checked = notificationsEnabled,
                onCheckedChange = { newValue ->
                    notificationsEnabled = newValue
                    sharedPrefs.edit().putBoolean("notifications", newValue).apply()
                }
            )
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

        // Preferencia de Username
        TextPreference(
            title = "Username",
            summary = if (username.isNotEmpty()) username else "No establecido",
            onClick = {
                tempUsername = username
                showUsernameDialog = true
            }
        )

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

        // Preferencia de Capacidad del tanque
        TextPreference(
            title = "Capacidad del tanque mezclador",
            summary = if (tankCapacity.isNotEmpty()) "$tankCapacity Litros" else "No establecido",
            onClick = {
                tempTankCapacity = tankCapacity
                showTankCapacityDialog = true
            }
        )

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

        // Opción para configurar precios (abre pantalla separada)
        TextPreference(
            title = "Precios por Tipo de Aplicación",
            summary = getPricesSummary(precioLiquida, precioSolida, precioMixta, precioVarias),
            onClick = {
                showPricesScreen = true
            }
        )

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

        // Opción para configurar formulaciones
        TextPreference(
            title = "Gestionar Formulaciones",
            summary = "Editar, ordenar y crear nuevas formulaciones",
            onClick = {
                context.startActivity(Intent(context, FormulacionesActivity::class.java))
            }
        )
    }

    // Pantalla de precios como overlay
    if (showPricesScreen) {
        PricesScreen(
            precioLiquida = precioLiquida,
            precioSolida = precioSolida,
            precioMixta = precioMixta,
            precioVarias = precioVarias,
            onPrecioLiquidaChange = { newValue ->
                precioLiquida = newValue
                sharedPrefs.edit().putString("precio_liquida", newValue).apply()
            },
            onPrecioSolidaChange = { newValue ->
                precioSolida = newValue
                sharedPrefs.edit().putString("precio_solida", newValue).apply()
            },
            onPrecioMixtaChange = { newValue ->
                precioMixta = newValue
                sharedPrefs.edit().putString("precio_mixta", newValue).apply()
            },
            onPrecioVariasChange = { newValue ->
                precioVarias = newValue
                sharedPrefs.edit().putString("precio_varias", newValue).apply()
            },
            onDismiss = { showPricesScreen = false }
        )
    }

    // Diálogos para precios (ya no se usan directamente desde settings)
    if (showPrecioLiquidaDialog) {
        PriceDialog(
            title = "Precio Aplicación Líquida",
            value = tempPrecioLiquida,
            onValueChange = { tempPrecioLiquida = it },
            onConfirm = {
                precioLiquida = tempPrecioLiquida
                sharedPrefs.edit().putString("precio_liquida", tempPrecioLiquida).apply()
                showPrecioLiquidaDialog = false
            },
            onDismiss = { showPrecioLiquidaDialog = false }
        )
    }

    if (showPrecioSolidaDialog) {
        PriceDialog(
            title = "Precio Aplicación Sólida",
            value = tempPrecioSolida,
            onValueChange = { tempPrecioSolida = it },
            onConfirm = {
                precioSolida = tempPrecioSolida
                sharedPrefs.edit().putString("precio_solida", tempPrecioSolida).apply()
                showPrecioSolidaDialog = false
            },
            onDismiss = { showPrecioSolidaDialog = false }
        )
    }

    if (showPrecioMixtaDialog) {
        PriceDialog(
            title = "Precio Aplicación Mixta",
            value = tempPrecioMixta,
            onValueChange = { tempPrecioMixta = it },
            onConfirm = {
                precioMixta = tempPrecioMixta
                sharedPrefs.edit().putString("precio_mixta", tempPrecioMixta).apply()
                showPrecioMixtaDialog = false
            },
            onDismiss = { showPrecioMixtaDialog = false }
        )
    }

    if (showPrecioVariasDialog) {
        PriceDialog(
            title = "Precio Aplicaciones Varias",
            value = tempPrecioVarias,
            onValueChange = { tempPrecioVarias = it },
            onConfirm = {
                precioVarias = tempPrecioVarias
                sharedPrefs.edit().putString("precio_varias", tempPrecioVarias).apply()
                showPrecioVariasDialog = false
            },
            onDismiss = { showPrecioVariasDialog = false }
        )
    }

    // Diálogo para Username
    if (showUsernameDialog) {
        AlertDialog(
            onDismissRequest = { showUsernameDialog = false },
            title = { Text("Enter your username") },
            text = {
                OutlinedTextField(
                    value = tempUsername,
                    onValueChange = { tempUsername = it },
                    label = { Text("Username") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        username = tempUsername
                        sharedPrefs.edit().putString("username", tempUsername).apply()
                        showUsernameDialog = false
                    }
                ) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showUsernameDialog = false }
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    // Diálogo para Capacidad del tanque
    if (showTankCapacityDialog) {
        AlertDialog(
            onDismissRequest = { showTankCapacityDialog = false },
            title = { Text("Ingrese la capacidad del tanque en litros") },
            text = {
                OutlinedTextField(
                    value = tempTankCapacity,
                    onValueChange = { newValue ->
                        // Solo permitir números y punto decimal
                        if (newValue.isEmpty() || newValue.matches(Regex("^\\d*\\.?\\d*$"))) {
                            tempTankCapacity = newValue
                        }
                    },
                    label = { Text("Capacidad (Litros)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        tankCapacity = tempTankCapacity
                        sharedPrefs.edit().putString("tank_capacity", tempTankCapacity).apply()
                        showTankCapacityDialog = false
                    }
                ) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showTankCapacityDialog = false }
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun PriceDialog(
    title: String,
    value: String,
    onValueChange: (String) -> Unit,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                Text(
                    text = "Ingrese el precio en USD por hectárea",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                OutlinedTextField(
                    value = value,
                    onValueChange = { newValue ->
                        // Solo permitir números y punto decimal
                        if (newValue.isEmpty() || newValue.matches(Regex("^\\d*\\.?\\d*$"))) {
                            onValueChange(newValue)
                        }
                    },
                    label = { Text("Precio USD/Ha") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                    prefix = { Text("$") }
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = onConfirm
            ) {
                Text("OK")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss
            ) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun TextPreference(
    title: String,
    summary: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Normal
            )
            if (summary.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = summary,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}