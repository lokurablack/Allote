package com.example.clientjobapp

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.animateBounds
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.lifecycleScope
import com.example.clientjobapp.data.AppDatabase
import com.example.clientjobapp.data.Formulacion
import com.example.clientjobapp.data.Product
import kotlinx.coroutines.launch

class ProductosActivity : ComponentActivity() {

    private lateinit var db: AppDatabase
    private val tiposList = mutableListOf("Herbicida", "Insecticida", "Fungicida", "Fertilizante", "Coadyuvante", "PGR", "Bactericida", "Defoliante", "Desecante", "Acaricida", "Nematicida", "Otros")
    
    private var formulacionesList by mutableStateOf<List<Formulacion>>(emptyList())

    private val productDetailLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        // Reload products when returning from ProductDetailActivity
        loadProducts()
    }

    private var productos by mutableStateOf<List<Product>>(emptyList())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        db = AppDatabase.getDatabase(this)
        loadProducts()
        loadFormulaciones()

        setContent {
            MaterialTheme {
                ProductosScreen()
            }
        }
    }

    private fun loadProducts() {
        lifecycleScope.launch {
            val productList = db.productDao().getAll()
            productos = productList
        }
    }

    private fun loadFormulaciones() {
        lifecycleScope.launch {
            formulacionesList = db.formulacionDao().getAllFormulaciones()
        }
    }

    @OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class,
        ExperimentalSharedTransitionApi::class
    )
    @Composable
    fun ProductosScreen() {
        var searchQuery by remember { mutableStateOf("") }
        var showAddDialog by remember { mutableStateOf(false) }
        var showEditDeleteDialog by remember { mutableStateOf(false) }
        var selectedProduct by remember { mutableStateOf<Product?>(null) }

        val filteredProducts = remember(productos, searchQuery) {
            if (searchQuery.isBlank()) {
                productos
            } else {
                productos.filter { product ->
                    product.nombreComercial.contains(searchQuery, ignoreCase = true) ||
                            product.principioActivo.contains(searchQuery, ignoreCase = true)
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .systemBarsPadding()
        ) {
            // Search field
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Buscar productos") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                singleLine = true
            )

            // Add product button
            Button(
                onClick = { showAddDialog = true },
                modifier = Modifier
                    .padding(bottom = 8.dp)
            ) {
                Text("Agregar nuevo producto")
            }

            // Products list
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredProducts) { product ->
                    ProductItem(
                        product = product,
                        onClick = {
                            val intent = Intent(this@ProductosActivity, ProductDetailActivity::class.java).apply {
                                putExtra("PRODUCT_ID", product.id)
                            }
                            productDetailLauncher.launch(intent)
                        },
                        onLongClick = {
                            selectedProduct = product
                            showEditDeleteDialog = true
                        }
                    )
                }
            }
        }

        // Add product dialog
        if (showAddDialog) {
            AddProductDialog(
                onDismiss = { showAddDialog = false },
                onSave = { nombreComercial, principioActivo, tipo, formulacionId ->
                    saveProduct(nombreComercial, principioActivo, tipo, formulacionId)
                    showAddDialog = false
                },
                formulaciones = formulacionesList
            )
        }

        // Edit/Delete dialog
        if (showEditDeleteDialog && selectedProduct != null) {
            EditDeleteDialog(
                product = selectedProduct!!,
                onDismiss = { showEditDeleteDialog = false },
                onEdit = {
                    showEditDeleteDialog = false
                    showAddDialog = true // For now, reuse add dialog for editing
                },
                onDelete = {
                    lifecycleScope.launch {
                        db.productDao().delete(selectedProduct!!)
                        loadProducts()
                    }
                    showEditDeleteDialog = false
                }
            )
        }
    }

    @OptIn(ExperimentalFoundationApi::class)
    @Composable
    fun ProductItem(
        product: Product,
        onClick: () -> Unit,
        onLongClick: () -> Unit
    ) {
        // Determine color based on banda toxicológica
        val bandaColor = when (product.bandaToxicologica?.trim()?.uppercase()) {
            "LA", "IA", "LB", "IB" -> Color(0xFFFF0000) // Rojo
            "II" -> Color(0xFFFFD700)                   // Amarillo (más visible que puro)
            "III" -> Color(0xFF0000FF)                  // Azul
            "IV" -> Color(0xFF00AA00)                   // Verde (más visible que puro)
            else -> Color(0xFFB0B0B0)                   // Gris claro para undefined
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .combinedClickable(
                    onClick = onClick,
                    onLongClick = onLongClick
                ),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(IntrinsicSize.Min) // Importante: permite que el Box tome la altura del contenido
            ) {
                // Franja vertical de color (banda toxicológica)
                Box(
                    modifier = Modifier
                        .width(8.dp)
                        .fillMaxHeight()
                        .background(bandaColor)
                )

                // Contenido del producto
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(16.dp)
                ) {
                    Text(
                        text = product.nombreComercial,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${product.principioActivo}",
                        fontSize = 12.sp
                    )
                }
            }
        }
    }

    @Composable
    fun AddProductDialog(
        onDismiss: () -> Unit,
        onSave: (String, String, String, Int) -> Unit,
        formulaciones: List<Formulacion>
    ) {
        var nombreComercial by remember { mutableStateOf("") }
        var principioActivo by remember { mutableStateOf("") }
        var selectedFormulacion by remember { mutableStateOf<Formulacion?>(null) }
        var selectedTipos by remember { mutableStateOf(mutableListOf<String>()) }
        var showTipoDialog by remember { mutableStateOf(false) }
        var showFormulacionDropdown by remember { mutableStateOf(false) }
        var showCustomTipoDialog by remember { mutableStateOf(false) }
        var customInput by remember { mutableStateOf("") }
        var principiosActivos by remember { mutableStateOf<List<String>>(emptyList()) }
        var showPrincipioDropdown by remember { mutableStateOf(false) }

        // Load existing principios activos
        LaunchedEffect(Unit) {
            principiosActivos = db.productDao().getAll().map { it.principioActivo }.distinct()
        }

        Dialog(onDismissRequest = onDismiss) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "Agregar producto",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    // Nombre Comercial
                    Text(
                        text = "Nombre Comercial",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    OutlinedTextField(
                        value = nombreComercial,
                        onValueChange = { nombreComercial = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        singleLine = true
                    )

                    // Principio Activo (AutoComplete simulation)
                    Text(
                        text = "Principio Activo",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    Box {
                        OutlinedTextField(
                            value = principioActivo,
                            onValueChange = {
                                principioActivo = it
                                showPrincipioDropdown = it.isNotEmpty()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 16.dp),
                            singleLine = true
                        )

                        DropdownMenu(
                            expanded = showPrincipioDropdown && principiosActivos.filter {
                                it.contains(principioActivo, ignoreCase = true)
                            }.isNotEmpty(),
                            onDismissRequest = { showPrincipioDropdown = false }
                        ) {
                            principiosActivos.filter {
                                it.contains(principioActivo, ignoreCase = true)
                            }.forEach { principio ->
                                DropdownMenuItem(
                                    text = { Text(principio) },
                                    onClick = {
                                        principioActivo = principio
                                        showPrincipioDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    // Tipo selection
                    Text(
                        text = "Tipo",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    Button(
                        onClick = { showTipoDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                    ) {
                        Text(
                            if (selectedTipos.isEmpty()) "Seleccionar Tipo"
                            else selectedTipos.joinToString(", ")
                        )
                    }

                    // Formulación
                    Text(
                        text = "Formulación",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    Box {
                        Button(
                            onClick = { showFormulacionDropdown = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 16.dp)
                        ) {
                            Text(selectedFormulacion?.nombre ?: "Seleccionar Formulación")
                        }

                        DropdownMenu(
                            expanded = showFormulacionDropdown,
                            onDismissRequest = { showFormulacionDropdown = false }
                        ) {
                            formulaciones.forEach { formulacion ->
                                DropdownMenuItem(
                                    text = { Text(formulacion.nombre) },
                                    onClick = {
                                        selectedFormulacion = formulacion
                                        showFormulacionDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = onDismiss) {
                            Text("Cancelar")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (nombreComercial.isNotBlank() && principioActivo.isNotBlank() &&
                                    selectedTipos.isNotEmpty() && selectedFormulacion != null) {
                                    onSave(nombreComercial, principioActivo, selectedTipos.joinToString(", "), selectedFormulacion!!.id)
                                }
                            }
                        ) {
                            Text("Guardar")
                        }
                    }
                }
            }
        }

        // Tipo selection dialog
        if (showTipoDialog) {
            val checkedStates = remember { mutableStateMapOf<String, Boolean>() }

            AlertDialog(
                onDismissRequest = { showTipoDialog = false },
                title = { Text("Seleccione Tipo(s)") },
                text = {
                    LazyColumn {
                        items(tiposList) { tipo ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = checkedStates[tipo] ?: false,
                                    onCheckedChange = { checked ->
                                        checkedStates[tipo] = checked
                                    }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(tipo)
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            val selected = checkedStates.filter { it.value }.keys.toMutableList()
                            if (selected.contains("Otros")) {
                                showCustomTipoDialog = true
                            } else {
                                selectedTipos.clear()
                                selectedTipos.addAll(selected)
                            }
                            showTipoDialog = false
                        }
                    ) {
                        Text("Aceptar")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showTipoDialog = false }) {
                        Text("Cancelar")
                    }
                }
            )
        }

        // Custom tipo input dialog
        if (showCustomTipoDialog) {
            AlertDialog(
                onDismissRequest = { showCustomTipoDialog = false },
                title = { Text("Ingrese nuevo tipo") },
                text = {
                    OutlinedTextField(
                        value = customInput,
                        onValueChange = { customInput = it },
                        singleLine = true
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            if (customInput.isNotBlank()) {
                                if (!tiposList.any { it.equals(customInput, ignoreCase = true) }) {
                                    tiposList.add(customInput)
                                }
                                selectedTipos.clear()
                                selectedTipos.add(customInput)
                                customInput = ""
                            }
                            showCustomTipoDialog = false
                        }
                    ) {
                        Text("Aceptar")
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            showCustomTipoDialog = false
                            customInput = ""
                        }
                    ) {
                        Text("Cancelar")
                    }
                }
            )
        }

    }

    @Composable
    fun EditDeleteDialog(
        product: Product,
        onDismiss: () -> Unit,
        onEdit: () -> Unit,
        onDelete: () -> Unit
    ) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Seleccione acción") },
            text = { Text("¿Qué desea hacer con ${product.nombreComercial}?") },
            confirmButton = {
                TextButton(onClick = onDelete) {
                    Text("Eliminar")
                }
            },
            dismissButton = {
                TextButton(onClick = onEdit) {
                    Text("Editar")
                }
            }
        )
    }

    private fun saveProduct(nombreComercial: String, principioActivo: String, tipo: String, formulacionId: Int) {
        lifecycleScope.launch {
            val nuevoProducto = Product(0, nombreComercial, principioActivo, tipo, formulacionId)
            db.productDao().insert(nuevoProducto)
            loadProducts()
        }
    }

    override fun onResume() {
        super.onResume()
        loadProducts()
        loadFormulaciones()
    }
}