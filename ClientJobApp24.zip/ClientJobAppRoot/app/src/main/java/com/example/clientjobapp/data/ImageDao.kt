package com.example.clientjobapp.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface ImageDao {
    @Query("SELECT * FROM images WHERE jobId = :jobId")
    suspend fun getImagesByJobId(jobId: Int): List<ImageEntity>

    @Insert
    suspend fun insert(image: ImageEntity)

    @Delete
    suspend fun delete(image: ImageEntity)

    @Query("DELETE FROM images WHERE jobId = :jobId")
    suspend fun deleteImagesByJobId(jobId: Int)
}
