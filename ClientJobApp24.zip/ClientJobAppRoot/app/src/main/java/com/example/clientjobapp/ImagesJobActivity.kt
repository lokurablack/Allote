package com.example.clientjobapp

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import coil.compose.rememberAsyncImagePainter
import coil.request.ImageRequest
import com.example.clientjobapp.data.AppDatabase
import com.example.clientjobapp.data.ImageEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.UUID

class ImagesJobActivity : ComponentActivity() {

    private lateinit var db: AppDatabase
    private var jobId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        jobId = intent.getIntExtra("JOB_ID", -1)
        if (jobId == -1) {
            Toast.makeText(this, "Trabajo no encontrado", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        db = AppDatabase.getDatabase(this)

        setContent {
            // State to hold list of image Uris
            val selectedImageUris = remember { mutableStateListOf<Uri>() }
            val context = LocalContext.current

            // Load images from DB when the Composable enters composition
            LaunchedEffect(jobId) {
                val images = withContext(Dispatchers.IO) {
                    db.imageDao().getImagesByJobId(jobId)
                }
                selectedImageUris.clear()
                selectedImageUris.addAll(images.map { Uri.parse(it.imageUri) })
            }

            Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
                ImagesJobScreen(
                    imageUris = selectedImageUris,
                    onSelectImages = {
                        // Launch image selector on the Activity
                        selectImageLauncher.launch("image/*")
                    }
                )
            }
        }
    }

    // Register launcher to select multiple images
    private val selectImageLauncher = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) {
            lifecycleScope.launch {
                uris.forEach { uri ->
                    val savedUri = saveCompressedImageToInternalStorage(uri)
                    if (savedUri != null) {
                        db.imageDao().insert(ImageEntity(jobId = jobId, imageUri = savedUri.toString()))
                    }
                }
                loadImagesFromDb()
            }
        } else {
            Toast.makeText(this, "No se seleccionó ninguna imagen", Toast.LENGTH_SHORT).show()
        }
    }

    // Reload images from DB and update UI state
    private fun loadImagesFromDb() {
        lifecycleScope.launch {
            val images = db.imageDao().getImagesByJobId(jobId)
            // Update UI state in the Compose context
            setContent {
                val selectedImageUris = remember { mutableStateListOf<Uri>() }
                selectedImageUris.clear()
                selectedImageUris.addAll(images.map { Uri.parse(it.imageUri) })
                Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
                    ImagesJobScreen(
                        imageUris = selectedImageUris,
                        onSelectImages = {
                            selectImageLauncher.launch("image/*")
                        }
                    )
                }
            }
        }
    }

    // Compress and save image internally, return new Uri
    private suspend fun saveCompressedImageToInternalStorage(uri: Uri): Uri? {
        return withContext(Dispatchers.IO) {
            try {
                val inputStream: InputStream? = contentResolver.openInputStream(uri)
                val originalBitmap = android.graphics.BitmapFactory.decodeStream(inputStream)
                inputStream?.close()

                val compressedFile = File(filesDir, "${UUID.randomUUID()}.jpg")
                val outputStream = FileOutputStream(compressedFile)

                originalBitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 70, outputStream)
                outputStream.flush()
                outputStream.close()

                Uri.fromFile(compressedFile)
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }
    }
}

// Composable UI
@Composable
fun ImagesJobScreen(
    imageUris: List<Uri>,
    onSelectImages: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp).systemBarsPadding()) {
        Button(onClick = onSelectImages, modifier = Modifier.fillMaxWidth()) {
            Text(text = "Seleccionar Imagen")
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (imageUris.isEmpty()) {
            Text(text = "No hay imágenes seleccionadas")
        } else {
            LazyColumn(modifier = Modifier.fillMaxWidth()) {
                items(imageUris) { uri ->
                    Box(modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)) {
                        val painter = rememberAsyncImagePainter(
                            ImageRequest.Builder(LocalContext.current)
                                .data(uri)
                                .crossfade(true)
                                .build()
                        )
                        Image(
                            painter = painter,
                            contentDescription = null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
            }
        }
    }
}
