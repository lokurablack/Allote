package com.example.clientjobapp.ui

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Composable
fun ProductDetailScreen(
    product: com.example.clientjobapp.data.Product?,
    formulacionName: String,
    onUpdateProduct: (com.example.clientjobapp.data.Product) -> Unit
) {
    val context = LocalContext.current
    var showExtraDataDialog by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .systemBarsPadding()
                .verticalScroll(rememberScrollState())
        ) {
            product?.let {
                Text(
                    text = it.nombreComercial ?: "",
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                Text(
                    text = "Principio Activo: ${it.principioActivo ?: ""}",
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Text(
                    text = "Tipo: ${it.tipo ?: ""}",
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Text(
                    text = "Formulación: $formulacionName",
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                // Conditionally show additional fields if not blank
                AnimatedVisibility(
                    visible = !it.numeroRegistroSenasa.isNullOrBlank(),
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Text(
                        text = "Número de registro en SENASA: ${it.numeroRegistroSenasa}",
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(top = 16.dp)
                    )
                }
                AnimatedVisibility(
                    visible = !it.concentracion.isNullOrBlank(),
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Text(
                        text = "Concentración: ${it.concentracion}",
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                AnimatedVisibility(
                    visible = !it.fabricante.isNullOrBlank(),
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Text(
                        text = "Fabricante: ${it.fabricante}",
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                AnimatedVisibility(
                    visible = !it.bandaToxicologica.isNullOrBlank(),
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Text(
                        text = "Banda Toxicológica: ${it.bandaToxicologica}",
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                AnimatedVisibility(
                    visible = !it.modoAccion.isNullOrBlank(),
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Text(
                        text = "Modo de Acción: ${it.modoAccion}",
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { showExtraDataDialog = true },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text(
                        text = "Agregar más datos",
                        color = MaterialTheme.colorScheme.onPrimary,
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            }
        }

        if (showExtraDataDialog && product != null) {
            ExtraDataDialog(
                product = product,
                onDismiss = { showExtraDataDialog = false },
                onSave = { updatedProduct ->
                    onUpdateProduct(updatedProduct)
                    showExtraDataDialog = false
                    Toast.makeText(context, "Datos guardados correctamente", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExtraDataDialog(
    product: com.example.clientjobapp.data.Product,
    onDismiss: () -> Unit,
    onSave: (com.example.clientjobapp.data.Product) -> Unit
) {
    val bandaOptions = listOf("la", "lb", "II", "III", "IV")

    var numeroRegistroSenasa by remember { mutableStateOf(product.numeroRegistroSenasa ?: "") }
    var concentracion by remember { mutableStateOf(product.concentracion ?: "") }
    var fabricante by remember { mutableStateOf(product.fabricante ?: "") }
    var modoAccion by remember { mutableStateOf(product.modoAccion ?: "") }
    var expanded by remember { mutableStateOf(false) }
    var selectedBanda by remember { mutableStateOf(product.bandaToxicologica ?: bandaOptions[0]) }

    val focusRequester = remember { FocusRequester() }

    // Solicitar foco correctamente cuando se expande el menú
    LaunchedEffect(expanded) {
        if (expanded) {
            focusRequester.requestFocus()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = "Agregar más datos") },
        text = {
            Column {
                OutlinedTextField(
                    value = numeroRegistroSenasa,
                    onValueChange = { numeroRegistroSenasa = it },
                    label = { Text("Número de registro SENASA") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = concentracion,
                    onValueChange = { concentracion = it },
                    label = { Text("Concentración") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = fabricante,
                    onValueChange = { fabricante = it },
                    label = { Text("Fabricante") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }
                ) {
                    OutlinedTextField(
                        value = selectedBanda,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Banda Toxicológica") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor()
                            .focusRequester(focusRequester)
                            .clickable { expanded = !expanded }
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        if (bandaOptions.isEmpty()) {
                            DropdownMenuItem(
                                text = { Text("No hay opciones disponibles") },
                                onClick = { }
                            )
                        } else {
                            bandaOptions.forEach { banda ->
                                DropdownMenuItem(
                                    text = { Text(banda) },
                                    onClick = {
                                        selectedBanda = banda
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }
                }
                OutlinedTextField(
                    value = modoAccion,
                    onValueChange = { modoAccion = it },
                    label = { Text("Modo de Acción") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val updatedProduct = product.copy(
                        numeroRegistroSenasa = numeroRegistroSenasa.takeIf { it.isNotBlank() },
                        concentracion = concentracion.takeIf { it.isNotBlank() },
                        fabricante = fabricante.takeIf { it.isNotBlank() },
                        bandaToxicologica = selectedBanda,
                        modoAccion = modoAccion.takeIf { it.isNotBlank() }
                    )
                    onSave(updatedProduct)
                }
            ) {
                Text("Guardar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}

