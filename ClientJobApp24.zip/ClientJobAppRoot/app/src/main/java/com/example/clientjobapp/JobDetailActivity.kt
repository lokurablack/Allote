package com.example.clientjobapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.example.clientjobapp.data.AppDatabase
import com.example.clientjobapp.data.Job
import com.example.clientjobapp.data.JobParametros
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.*
import kotlinx.coroutines.launch

class JobDetailActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private var jobId: Int = -1
    private var currentJob by mutableStateOf<Job?>(null)

    private var showLocationDialog by mutableStateOf(false)
    private var isPickerMode by mutableStateOf(true)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        db = AppDatabase.getDatabase(this)
        initializeJob()

        setContent {
            MaterialTheme {
                JobDetailContent()
            }
        }
    }

    private fun initializeJob() {
        val jobFromIntent = intent.getParcelableExtra<Job>("JOB_EXTRA")
        jobId = intent.getIntExtra("JOB_ID", -1)

        when {
            jobFromIntent != null -> {
                currentJob = jobFromIntent
            }
            jobId != -1 -> {
                loadJobFromDatabase()
            }
            else -> {
                showErrorAndFinish("Error: trabajo no encontrado")
            }
        }
    }

    private fun loadJobFromDatabase() {
        lifecycleScope.launch {
            try {
                val job = db.jobDao().getById(jobId)
                if (job != null) {
                    currentJob = job
                } else {
                    showErrorAndFinish("Error: trabajo no encontrado")
                }
            } catch (e: Exception) {
                showErrorAndFinish("Error al cargar el trabajo")
            }
        }
    }

    private fun updateJobLocation(lat: Double, lng: Double) {
        lifecycleScope.launch {
            try {
                val updatedJob = currentJob!!.copy(latitude = lat, longitude = lng)
                db.jobDao().update(updatedJob)
                currentJob = updatedJob
                showToast("Ubicación guardada correctamente")
            } catch (e: Exception) {
                showToast("Error al guardar la ubicación")
            }
        }
    }

    @Composable
    private fun JobDetailContent() {
        currentJob?.let { job ->
            JobDetailScreen(
                job = job,
                onAdministracionClick = { navigateToAdministracion() },
                onParametrosClick = { navigateToParametros() },
                onLocationButtonClick = {
                    if (hasValidLocation(job)) {
                        isPickerMode = false
                    } else {
                        isPickerMode = true
                    }
                    showLocationDialog = true
                },
                onRecetasClick = { navigateToRecetas() },
                onImagenesClick = { navigateToImagenes() },
                db = db,
                showLocationDialog = showLocationDialog,
                isPickerMode = isPickerMode,
                onDismissLocationDialog = { showLocationDialog = false },
                onLocationConfirmed = { lat, lng ->
                    updateJobLocation(lat, lng)
                    showLocationDialog = false
                }
            )
        }
    }

    private fun navigateToAdministracion() {
        startActivity(Intent(this, AdministracionActivity::class.java).apply {
            putExtra("JOB_ID", jobId)
        })
    }

    private fun navigateToParametros() {
        startActivity(Intent(this, ParametrosActivity::class.java).apply {
            putExtra("JOB_ID", jobId)
        })
    }

    private fun navigateToRecetas() {
        startActivity(Intent(this, RecetasActivity::class.java).apply {
            putExtra("JOB_ID", jobId)
        })
    }

    private fun navigateToImagenes() {
        startActivity(Intent(this, ImagesJobActivity::class.java).apply {
            putExtra("JOB_ID", jobId)
        })
    }

    private fun hasValidLocation(job: Job): Boolean {
        return job.latitude != null && job.longitude != null &&
                (job.latitude != 0.0 || job.longitude != 0.0)
    }

    private fun showErrorAndFinish(message: String) {
        showToast(message)
        finish()
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun JobDetailScreen(
    job: Job,
    onAdministracionClick: () -> Unit,
    onParametrosClick: () -> Unit,
    onLocationButtonClick: () -> Unit,
    onRecetasClick: () -> Unit,
    onImagenesClick: () -> Unit,
    db: AppDatabase,
    showLocationDialog: Boolean,
    isPickerMode: Boolean,
    onDismissLocationDialog: () -> Unit,
    onLocationConfirmed: (Double, Double) -> Unit
) {
    var parametros by remember { mutableStateOf<JobParametros?>(null) }
    val scrollState = rememberScrollState()

    LaunchedEffect(job.id) {
        parametros = try {
            db.jobParametrosDao().getByJobId(job.id)
        } catch (e: Exception) {
            null
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        JobHeader(job)
        JobInfo(job)
        ActionButtons(
            onAdministracionClick = onAdministracionClick,
            onParametrosClick = onParametrosClick,
            onLocationButtonClick = onLocationButtonClick,
            onRecetasClick = onRecetasClick,
            onImagenesClick = onImagenesClick
        )
    }

    if (showLocationDialog) {
        if (isPickerMode) {
            LocationPickerDialog(
                initialLat = job.latitude ?: -32.364954,
                initialLng = job.longitude ?: -62.312972,
                onConfirm = { lat, lng -> onLocationConfirmed(lat, lng) },
                onDismiss = onDismissLocationDialog
            )
        } else {
            LocationViewerDialog(
                lat = job.latitude ?: 0.0,
                lng = job.longitude ?: 0.0,
                description = job.description,
                onDismiss = onDismissLocationDialog
            )
        }
    }
}

@Composable
private fun JobHeader(job: Job) {
    Text(
        text = job.description,
        fontSize = 20.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(bottom = 16.dp)
    )
}

@Composable
private fun JobInfo(job: Job) {
    val infoItems = listOf(
        "Cliente" to job.clientName,
        "Hectáreas" to job.surface.toString(),
        "Estado" to job.status,
        "Creado" to DateFormatter.formatDate(job.date),
        "Inicio real" to formatDateOrDefault(job.startDate),
        "Finalizado" to formatDateOrDefault(job.endDate),
        "Facturación" to job.billingStatus,
        "Notas" to (job.notes?.takeIf { it.isNotBlank() } ?: "N/A")
    )

    infoItems.forEach { (label, value) ->
        InfoRow(label = label, value = value)
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Text(
        text = "$label: $value",
        fontSize = 16.sp,
        fontWeight = if (label == "Cliente") FontWeight.Bold else FontWeight.Normal,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

@Composable
private fun ActionButtons(
    onAdministracionClick: () -> Unit,
    onParametrosClick: () -> Unit,
    onLocationButtonClick: () -> Unit,
    onRecetasClick: () -> Unit,
    onImagenesClick: () -> Unit
) {
    val buttonModifier = Modifier
        .fillMaxWidth()
        .padding(top = 8.dp)

    PrimaryButton("Administración", onAdministracionClick, buttonModifier)
    PrimaryButton("Parametros utilizados", onParametrosClick, buttonModifier)

    Button(
        onClick = onLocationButtonClick,
        modifier = buttonModifier
    ) {
        Text("Ubicación")
    }

    PrimaryButton("Recetas", onRecetasClick, buttonModifier)
    PrimaryButton("Imágenes del Trabajo", onImagenesClick, buttonModifier)
}

@Composable
private fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        modifier = modifier,
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary
        )
    ) {
        Text(
            text = text,
            color = Color.White,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun LocationPickerDialog(
    initialLat: Double,
    initialLng: Double,
    onConfirm: (Double, Double) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedLatLng by remember { mutableStateOf<LatLng?>(null) }
    val defaultLocation = LatLng(initialLat, initialLng)
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition(defaultLocation, 10f, 0f, 0f)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Seleccionar Ubicación") },
        text = {
            Column {
                GoogleMap(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp),
                    cameraPositionState = cameraPositionState,
                    properties = MapProperties(mapType = MapType.SATELLITE),
                    onMapClick = { latLng ->
                        selectedLatLng = latLng
                    }
                ) {
                    selectedLatLng?.let {
                        Marker(state = MarkerState(position = it), title = "Ubicación seleccionada")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    selectedLatLng?.let {
                        onConfirm(it.latitude, it.longitude)
                    }
                },
                enabled = selectedLatLng != null
            ) {
                Text("Confirmar ubicación")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}

@Composable
fun LocationViewerDialog(
    lat: Double,
    lng: Double,
    description: String,
    onDismiss: () -> Unit
) {
    val jobLocation = LatLng(lat, lng)
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition(jobLocation, 16f, 0f, 0f)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ubicación del Trabajo") },
        text = {
            GoogleMap(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp),
                cameraPositionState = cameraPositionState,
                properties = MapProperties(mapType = MapType.SATELLITE)
            ) {
                Marker(
                    state = MarkerState(position = jobLocation),
                    title = description
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Cerrar")
            }
        }
    )
}

private fun formatDateOrDefault(timestamp: Long): String {
    return if (timestamp > 0L) {
        DateFormatter.formatMillis(timestamp)
    } else {
        "Fecha no establecida"
    }
}
