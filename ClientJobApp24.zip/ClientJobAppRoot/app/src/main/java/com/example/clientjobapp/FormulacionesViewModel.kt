package com.example.clientjobapp

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.clientjobapp.data.AppDatabase
import com.example.clientjobapp.data.Formulacion
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class FormulacionesViewModel(private val db: AppDatabase) : ViewModel() {

    private val _formulaciones = MutableStateFlow<List<Formulacion>>(emptyList())
    val formulaciones: StateFlow<List<Formulacion>> = _formulaciones.asStateFlow()

    private val toDelete = mutableListOf<Formulacion>()

    init {
        loadFormulaciones()
    }

    private fun loadFormulaciones() {
        viewModelScope.launch {
            _formulaciones.value = db.formulacionDao().getAllFormulaciones()
        }
    }

    fun moveUp(formulacion: Formulacion) {
        val currentList = _formulaciones.value.toMutableList()
        val index = currentList.indexOf(formulacion)
        if (index > 0) {
            currentList.removeAt(index)
            currentList.add(index - 1, formulacion)
            updateOrder(currentList)
        }
    }

    fun moveDown(formulacion: Formulacion) {
        val currentList = _formulaciones.value.toMutableList()
        val index = currentList.indexOf(formulacion)
        if (index < currentList.size - 1) {
            currentList.removeAt(index)
            currentList.add(index + 1, formulacion)
            updateOrder(currentList)
        }
    }

    private fun updateOrder(newList: List<Formulacion>) {
        val updatedList = newList.mapIndexed { index, formulacion ->
            formulacion.copy(ordenMezcla = index + 1)
        }
        _formulaciones.value = updatedList
    }

    fun addFormulacion(nombre: String, tipoUnidad: String) {
        val currentList = _formulaciones.value.toMutableList()
        val newFormulacion = Formulacion(
            nombre = nombre,
            tipoUnidad = tipoUnidad,
            ordenMezcla = currentList.size + 1
        )
        currentList.add(newFormulacion)
        _formulaciones.value = currentList
    }

    fun updateFormulacion(id: Int, newName: String, newTipo: String) {
        val currentList = _formulaciones.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == id }
        if (index != -1) {
            val updatedFormulacion = currentList[index].copy(nombre = newName, tipoUnidad = newTipo)
            currentList[index] = updatedFormulacion
            _formulaciones.value = currentList
        }
    }

    fun deleteFormulacion(formulacion: Formulacion) {
        val currentList = _formulaciones.value.toMutableList()
        currentList.remove(formulacion)
        if (formulacion.id != 0) { // Only track deletions for existing items
            toDelete.add(formulacion)
        }
        updateOrder(currentList)
    }

    fun saveChanges(onComplete: () -> Unit) {
        viewModelScope.launch {
            if (toDelete.isNotEmpty()) {
                db.formulacionDao().delete(toDelete)
                toDelete.clear()
            }
            db.formulacionDao().insertAll(_formulaciones.value)
            onComplete()
        }
    }

    suspend fun isFormulacionInUse(nombreFormulacion: String): Boolean {
        return db.formulacionDao().getProductCountForFormulacion(nombreFormulacion) > 0
    }
}
