package com.example.clientjobapp.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [Client::class, Job::class, AdministracionTrabajo::class, JobParametros::class, Product::class, Recipe::class, RecipeProduct::class, ImageEntity::class, DocumentoTrabajo::class, Formulacion::class], version = 12)
abstract class AppDatabase : RoomDatabase() {
    abstract fun clientDao(): ClientDao
    abstract fun jobDao(): JobDao
    abstract fun administracionDao(): AdministracionDao
    abstract fun jobParametrosDao(): JobParametrosDao
    abstract fun productDao(): ProductDao
    abstract fun recipeDao(): RecipeDao
    abstract fun imageDao(): ImageDao
    abstract fun formulacionDao(): FormulacionDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE jobs ADD COLUMN startDate INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE jobs ADD COLUMN endDate INTEGER NOT NULL DEFAULT 0")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE jobs ADD COLUMN billingStatus TEXT NOT NULL DEFAULT 'No Facturado'")
            }
        }

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE jobs ADD COLUMN valuePerHectare REAL NOT NULL DEFAULT 0")
            }
        }

        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    "CREATE TABLE IF NOT EXISTS job_parametros (" +
                            "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                            "jobId INTEGER NOT NULL, " +
                            "dosis REAL, " +
                            "tamanoGota REAL, " +
                            "interlineado REAL, " +
                            "velocidad REAL, " +
                            "altura REAL, " +
                            "discoUtilizado TEXT)"
                )
            }
        }

        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE job_parametros ADD COLUMN revoluciones REAL")
            }
        }

        private val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    "CREATE TABLE IF NOT EXISTS products (" +
                            "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                            "nombreComercial TEXT NOT NULL, " +
                            "principioActivo TEXT NOT NULL, " +
                            "tipo TEXT NOT NULL, " +
                            "formulacion TEXT NOT NULL)"
                )
            }
        }

        private val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    "CREATE TABLE IF NOT EXISTS recipes (" +
                            "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                            "jobId INTEGER NOT NULL, " +
                            "hectareas REAL NOT NULL, " +
                            "caudal REAL NOT NULL, " +
                            "totalCaldo REAL NOT NULL, " +
                            "fechaCreacion INTEGER NOT NULL)"
                )
                database.execSQL(
                    "CREATE TABLE IF NOT EXISTS recipe_products (" +
                            "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                            "recipeId INTEGER NOT NULL, " +
                            "productId INTEGER NOT NULL, " +
                            "dosis REAL NOT NULL, " +
                            "cantidadTotal REAL NOT NULL, " +
                            "ordenMezclado INTEGER NOT NULL)"
                )
            }
        }

        private val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE products ADD COLUMN numeroRegistroSenasa TEXT")
                database.execSQL("ALTER TABLE products ADD COLUMN concentracion TEXT")
                database.execSQL("ALTER TABLE products ADD COLUMN fabricante TEXT")
                database.execSQL("ALTER TABLE products ADD COLUMN bandaToxicologica TEXT")
                database.execSQL("ALTER TABLE products ADD COLUMN modoAccion TEXT")
            }
        }

        private val MIGRATION_9_10 = object : Migration(9, 10) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE recipes ADD COLUMN resumen TEXT NOT NULL DEFAULT ''")
            }
        }

        private val MIGRATION_10_11 = object : Migration(10, 11) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE clients ADD COLUMN localidad TEXT NOT NULL DEFAULT ''")
                database.execSQL("ALTER TABLE clients ADD COLUMN direccion TEXT NOT NULL DEFAULT ''")
            }
        }

        private val MIGRATION_11_12 = object : Migration(11, 12) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE administracion_trabajo ADD COLUMN documentUri TEXT NOT NULL DEFAULT ''")
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "client_job_app_database" // Changed database name to force recreation
                )
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // This callback is executed on a background thread, so we can run database operations directly.
                            // We use raw SQL here to avoid timing issues with the INSTANCE variable.
                            PREPOPULATE_DATA.forEach { formulacion ->
                                val sql = "INSERT INTO formulaciones (id, nombre, ordenMezcla, tipoUnidad) VALUES (${formulacion.id}, '${formulacion.nombre}', ${formulacion.ordenMezcla}, '${formulacion.tipoUnidad}')"
                                db.execSQL(sql)
                            }
                        }
                    })
                    //.addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9, MIGRATION_9_10, MIGRATION_10_11, MIGRATION_11_12)
                    .fallbackToDestructiveMigration(true)
                    .build()
                INSTANCE = instance
                instance
            }
        }

        val PREPOPULATE_DATA = listOf(
            Formulacion(id = 1, nombre = "Agua", ordenMezcla = 1, tipoUnidad = "LIQUIDO"),
            Formulacion(id = 2, nombre = "Compatibilizador de mezcla", ordenMezcla = 2, tipoUnidad = "LIQUIDO"),
            Formulacion(id = 3, nombre = "Corrector/Secuestrante", ordenMezcla = 3, tipoUnidad = "LIQUIDO"),
            Formulacion(id = 4, nombre = "Antiespumante", ordenMezcla = 4, tipoUnidad = "LIQUIDO"),
            Formulacion(id = 5, nombre = "Adyuvante", ordenMezcla = 5, tipoUnidad = "LIQUIDO"),
            Formulacion(id = 6, nombre = "Polvos Mojables/WP", ordenMezcla = 6, tipoUnidad = "SOLIDO"),
            Formulacion(id = 7, nombre = "Granulos Dispersables/WG", ordenMezcla = 7, tipoUnidad = "SOLIDO"),
            Formulacion(id = 8, nombre = "Suspensiones Concentradas/SC", ordenMezcla = 8, tipoUnidad = "LIQUIDO"),
            Formulacion(id = 9, nombre = "Concentrados Solubles/EC", ordenMezcla = 9, tipoUnidad = "LIQUIDO"),
            Formulacion(id = 10, nombre = "Liquidos Solubles/SL", ordenMezcla = 10, tipoUnidad = "LIQUIDO"),
            Formulacion(id = 11, nombre = "Aceites", ordenMezcla = 11, tipoUnidad = "LIQUIDO"),
            Formulacion(id = 12, nombre = "Foliares", ordenMezcla = 12, tipoUnidad = "LIQUIDO")
        )
    }
}
