package com.example.clientjobapp

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.example.clientjobapp.data.AppDatabase
import com.example.clientjobapp.data.Client
import com.example.clientjobapp.data.Job
import com.example.clientjobapp.ui.theme.ClientJobAppTheme
import com.example.clientjobapp.ui.theme.FilterCardBackgroundColor
import com.example.clientjobapp.ui.theme.LightBlueJobColor
import com.example.clientjobapp.ui.theme.LightBrownJobColor
import com.example.clientjobapp.ui.theme.LightGreenJobColor
import com.example.clientjobapp.ui.theme.LightYellowJobColor
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class JobsActivity : ComponentActivity() {

    private val db by lazy { AppDatabase.getDatabase(this) }
    private val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

    // CLAVE: Variable para forzar recomposición
    private var refreshTrigger by mutableStateOf(0)

    // NUEVA: Función para actualizar la UI
    private fun refreshUI() {
        refreshTrigger++
    }

    private var showJobDialog = mutableStateOf(false)
    private var jobToEdit = mutableStateOf<Job?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ClientJobAppTheme {
                val valuePerHa = getSharedPreferences("app_prefs", MODE_PRIVATE).getFloat("value_per_ha", 0.0f)
                val clients = remember { mutableStateOf(listOf<com.example.clientjobapp.data.Client>()) }
                val dbInstance = db

                // Load clients once
                LaunchedEffect(Unit) {
                    clients.value = dbInstance.clientDao().getAll()
                }

                JobsScreen(
                    refreshTrigger = refreshTrigger,
                    onAddJob = {
                        jobToEdit.value = null
                        showJobDialog.value = true
                    },
                    onJobClick = { job ->
                        val intent = Intent(this, JobDetailActivity::class.java)
                        intent.putExtra("JOB_ID", job.id)
                        startActivity(intent)
                    },
                    onJobOptions = { job ->
                        showJobOptionsDialog(job)
                    }
                )

                if (showJobDialog.value) {
                    JobDialogCompose(
                        clients = clients.value,
                        initialJob = jobToEdit.value,
                        valuePerHectare = valuePerHa.toDouble(),
                        onDismiss = { showJobDialog.value = false },
                        onJobSaved = { job ->
                            lifecycleScope.launch {
                                if (jobToEdit.value == null) {
                                    db.jobDao().insert(job)
                                    Toast.makeText(this@JobsActivity, "Trabajo añadido", Toast.LENGTH_SHORT).show()
                                } else {
                                    db.jobDao().update(job)
                                    Toast.makeText(this@JobsActivity, "Trabajo actualizado", Toast.LENGTH_SHORT).show()
                                }
                                refreshUI()
                                showJobDialog.value = false
                            }
                        }
                    )
                }
            }
        }
    }

    private fun showJobOptionsDialog(job: Job) {
        val options = listOf("Marcar finalizado", "Editar", "Eliminar", "Facturación", "Recetas")
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Opciones")
            .setItems(options.toTypedArray()) { _, idx ->
                when (idx) {
                    0 -> markAsFinished(job)
                    1 -> {
                        jobToEdit.value = job
                        showJobDialog.value = true
                    }
                    2 -> deleteWithConfirm(job)
                    3 -> showBillingDialog(job)
                    4 -> {
                        val intent = Intent(this, RecetasActivity::class.java)
                        intent.putExtra("JOB_ID", job.id)
                        startActivity(intent)
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun markAsFinished(job: Job) {
        val cal = Calendar.getInstance()
        DatePickerDialog(
            this,
            { _, y, m, d ->
                cal.set(y, m, d, 0, 0, 0)
                lifecycleScope.launch {
                    db.jobDao().update(job.copy(status = "Finalizado", endDate = cal.timeInMillis))
                    refreshUI() // NUEVO: Actualizar UI después de marcar como finalizado
                    Toast.makeText(this@JobsActivity, "Trabajo marcado como finalizado", Toast.LENGTH_SHORT).show()
                }
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun deleteWithConfirm(job: Job) {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Eliminar trabajo")
            .setMessage("¿Seguro que desea eliminar este trabajo?")
            .setPositiveButton("Eliminar") { _, _ -> deleteJob(job) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun deleteJob(job: Job) {
        lifecycleScope.launch {
            val images = db.imageDao().getImagesByJobId(job.id)
            images.forEach { imageEntity ->
                try {
                    val file = java.io.File(android.net.Uri.parse(imageEntity.imageUri).path ?: "")
                    if (file.exists()) {
                        file.delete()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            db.imageDao().deleteImagesByJobId(job.id)
            db.jobDao().delete(job)
            refreshUI() // NUEVO: Actualizar UI después de eliminar
            Toast.makeText(this@JobsActivity, "Trabajo eliminado", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showBillingDialog(job: Job) {
        val options = listOf("No Facturado", "Facturado", "Pagado")
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Estado de facturación")
            .setItems(options.toTypedArray()) { _, idx ->
                val status = options[idx]
                lifecycleScope.launch {
                    db.jobDao().update(job.copy(billingStatus = status))
                    refreshUI() // NUEVO: Actualizar UI después de cambiar facturación
                    Toast.makeText(this@JobsActivity, "Estado de facturación actualizado", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JobsScreen(
    refreshTrigger: Int, // NUEVO: Parámetro para forzar recargar datos
    onAddJob: () -> Unit,
    onJobClick: (Job) -> Unit,
    onJobOptions: (Job) -> Unit
) {
    val db = AppDatabase.getDatabase(LocalContext.current)
    var allJobs by remember { mutableStateOf(listOf<Job>()) }
    var allClients by remember { mutableStateOf(listOf<Client>()) }
    var filteredJobs by remember { mutableStateOf(listOf<Job>()) }
    var isLoading by remember { mutableStateOf(true) }

    // Estados de filtros
    var selectedClient by remember { mutableStateOf("") }
    var selectedStatus by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf("") }
    var selectedBilling by remember { mutableStateOf("") }
    var fromDate by remember { mutableStateOf<Long?>(null) }
    var toDate by remember { mutableStateOf<Long?>(null) }

    val scope = rememberCoroutineScope()

    // MODIFICADO: Cargar trabajos y clientes - ahora responde a refreshTrigger
    LaunchedEffect(refreshTrigger) {
        isLoading = true
        scope.launch {
            allJobs = db.jobDao().getAll()
            allClients = db.clientDao().getAll()
            filteredJobs = allJobs
            isLoading = false
        }
    }

    // Aplicar filtros automáticamente
    LaunchedEffect(selectedClient, selectedStatus, selectedType, selectedBilling, fromDate, toDate, allJobs) {
        filteredJobs = allJobs.filter { job ->
            (selectedClient.isBlank() || job.clientName.contains(selectedClient, ignoreCase = true)) &&
                    (selectedStatus.isBlank() || job.status.equals(selectedStatus, ignoreCase = true)) &&
                    (selectedType.isBlank() || job.tipoAplicacion.equals(selectedType, ignoreCase = true)) &&
                    (selectedBilling.isBlank() || job.billingStatus.equals(selectedBilling, ignoreCase = true)) &&
                    (fromDate == null || job.startDate >= fromDate!!) &&
                    (toDate == null || job.endDate?.let { it <= toDate!! } != false)
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Trabajos") },
                actions = {
                    IconButton(onClick = onAddJob) {
                        Icon(Icons.Filled.Add, contentDescription = "Agregar Trabajo")
                    }
                }
            )
        }
    ) { padding ->
        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterSection(
                        allClients = allClients,
                        selectedClient = selectedClient,
                        onClientChange = { selectedClient = it },
                        selectedStatus = selectedStatus,
                        onStatusChange = { selectedStatus = it },
                        selectedType = selectedType,
                        onTypeChange = { selectedType = it },
                        selectedBilling = selectedBilling,
                        onBillingChange = { selectedBilling = it },
                        fromDate = fromDate,
                        onFromDateChange = { fromDate = it },
                        toDate = toDate,
                        onToDateChange = { toDate = it }
                    )
                }

                val pendingJobs = filteredJobs.filter { it.status.equals("Pendiente", true) }
                val finishedJobs = filteredJobs.filter { it.status.equals("Finalizado", true) }

                if (pendingJobs.isNotEmpty()) {
                    item {
                        Text(
                            text = "Pendientes (${pendingJobs.sumOf { it.surface ?: 0.0 }} ha)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                    items(pendingJobs) { job ->
                        JobListItem(
                            job = job,
                            onClick = { onJobClick(job) },
                            onOptionsClick = { onJobOptions(job) }
                        )
                    }
                }

                if (finishedJobs.isNotEmpty()) {
                    item {
                        Text(
                            text = "Finalizados (${finishedJobs.sumOf { it.surface ?: 0.0 }} ha)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                    items(finishedJobs) { job ->
                        JobListItem(
                            job = job,
                            onClick = { onJobClick(job) },
                            onOptionsClick = { onJobOptions(job) }
                        )
                    }
                }

                if (filteredJobs.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No se encontraron trabajos",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun JobListItem(
    job: Job,
    onClick: () -> Unit,
    onOptionsClick: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    val backgroundColor = when (job.tipoAplicacion?.lowercase()) {
        "aplicacion liquida" -> LightBlueJobColor
        "aplicacion solida" -> LightYellowJobColor
        "aplicacion mixta" -> LightBrownJobColor
        "aplicaciones varias" -> LightGreenJobColor
        else -> MaterialTheme.colorScheme.surface
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = job.clientName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "${job.surface} has",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (!job.description.isNullOrBlank()) {
                    Text(
                        text = "Descripción: ${job.description}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            IconButton(onClick = { onOptionsClick() }) {
                Icon(Icons.Filled.MoreVert, contentDescription = "Opciones")
            }
        }
    }
}

@Composable
fun FilterSection(
    allClients: List<Client>,
    selectedClient: String,
    onClientChange: (String) -> Unit,
    selectedStatus: String,
    onStatusChange: (String) -> Unit,
    selectedType: String,
    onTypeChange: (String) -> Unit,
    selectedBilling: String,
    onBillingChange: (String) -> Unit,
    fromDate: Long?,
    onFromDateChange: (Long?) -> Unit,
    toDate: Long?,
    onToDateChange: (Long?) -> Unit
) {
    var expandedFilter by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = FilterCardBackgroundColor)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expandedFilter = !expandedFilter },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Filtros",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Medium
                )
                Icon(
                    imageVector = if (expandedFilter) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                    contentDescription = if (expandedFilter) "Ocultar filtros" else "Mostrar filtros"
                )
            }

            if (expandedFilter) {
                // Campo de cliente
                FilterDropdown(
                    label = "Cliente",
                    options = listOf("") + allClients.map { "${it.name} ${it.lastname}" },
                    selected = selectedClient,
                    onSelected = onClientChange,
                    modifier = Modifier.fillMaxWidth()
                )

                // Primera fila de dropdowns
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterDropdown(
                        label = "Estado",
                        options = listOf("", "Pendiente", "Finalizado"),
                        selected = selectedStatus,
                        onSelected = onStatusChange,
                        modifier = Modifier.weight(1f)
                    )
                    FilterDropdown(
                        label = "Aplicación",
                        options = listOf("", "Aplicacion liquida", "Aplicacion solida", "Aplicacion mixta", "Aplicaciones varias"),
                        selected = selectedType,
                        onSelected = onTypeChange,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Segunda fila
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterDropdown(
                        label = "Facturación",
                        options = listOf("", "No Facturado", "Facturado", "Pagado"),
                        selected = selectedBilling,
                        onSelected = onBillingChange,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Selectores de fecha
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DateSelector(
                        label = "Desde",
                        value = fromDate,
                        onDateSelected = onFromDateChange,
                        modifier = Modifier.weight(1f)
                    )
                    DateSelector(
                        label = "Hasta",
                        value = toDate,
                        onDateSelected = onToDateChange,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilterDropdown(
    label: String,
    options: List<String>,
    selected: String,
    onSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = it },
        modifier = modifier
    ) {
        OutlinedTextField(
            value = if (selected.isEmpty()) "" else selected,
            onValueChange = {},
            readOnly = true,
            label = { Text(label, style = MaterialTheme.typography.labelMedium) },
            textStyle = MaterialTheme.typography.bodyMedium,
            trailingIcon = {
                ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
            },
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
                .height(56.dp),
            singleLine = true
        )

        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = {
                        Text(
                            text = if (option.isEmpty()) "Todos" else option,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    },
                    onClick = {
                        onSelected(option)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
fun DateSelector(
    label: String,
    value: Long?,
    onDateSelected: (Long?) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    val calendar = Calendar.getInstance()
    val displayText = value?.let { dateFormat.format(Date(it)) } ?: ""

    OutlinedTextField(
        value = displayText,
        onValueChange = {},
        label = { Text(label, style = MaterialTheme.typography.labelMedium) },
        textStyle = MaterialTheme.typography.bodyMedium,
        readOnly = true,
        singleLine = true,
        modifier = modifier
            .height(56.dp)
            .clickable {
                DatePickerDialog(
                    context,
                    { _, year, month, dayOfMonth ->
                        calendar.set(year, month, dayOfMonth, 0, 0, 0)
                        calendar.set(Calendar.MILLISECOND, 0)
                        onDateSelected(calendar.timeInMillis)
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
                ).show()
            },
        trailingIcon = {
            Row {
                if (value != null) {
                    IconButton(onClick = { onDateSelected(null) }) {
                        Icon(Icons.Default.Clear, contentDescription = "Limpiar fecha")
                    }
                }
                Icon(Icons.Default.DateRange, contentDescription = "Seleccionar fecha")
            }
        }
    )
}