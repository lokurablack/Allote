package com.example.clientjobapp.ui.theme

import androidx.compose.ui.graphics.Color

val BluePrimary = Color(0xFF0D47A1)
val BlueSecondary = Color(0xFF1976D2)
val BlueTertiary = Color(0xFF64B5F6)

// New colors for job application types
val LightBlueJobColor = Color(0xFFB3E5FC)    // Aplicacion liquida - very light blue
val LightYellowJobColor = Color(0xFFFFF9C4)  // Aplicacion solida - very light yellow
val LightBrownJobColor = Color(0xFFD7CCC8)   // Aplicacion mixta - very light brown
val LightGreenJobColor = Color(0xFFC8E6C9)   // Aplicaciones varias - very light green

// Background color for filter card
val FilterCardBackgroundColor = Color(0xFFF1F8E9)  // light pastel greenish background

// Billing status colors for checkmark
val BillingRed = Color(0xFFFF0000)          // Red for "No Facturado"
val BillingYellow = Color(0xFFE5C200)       // Yellow for "Facturado"
val BillingGreen = Color(0xFF4CAF50)        // Green for "Pagado"

// Background colors for job status
val BackgroundLightYellow = Color(0xFFFFFDE7)  // Very light yellow for "Pendiente"
val BackgroundLightGreen = Color(0xFFE8F5E9)   // Very light green for "Finalizado"
