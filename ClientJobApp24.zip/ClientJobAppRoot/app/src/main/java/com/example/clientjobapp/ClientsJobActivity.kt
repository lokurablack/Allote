package com.example.clientjobapp

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.clientjobapp.data.AppDatabase
import com.example.clientjobapp.data.Job
import com.example.clientjobapp.ui.theme.ClientJobAppTheme
import kotlinx.coroutines.launch
import java.util.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.IntOffset
import com.example.clientjobapp.ui.theme.BillingGreen
import com.example.clientjobapp.ui.theme.BillingRed
import com.example.clientjobapp.ui.theme.BillingYellow
import com.example.clientjobapp.ui.theme.BackgroundLightGreen
import com.example.clientjobapp.ui.theme.BackgroundLightYellow
import androidx.core.net.toUri

class ClientJobsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val clientId = intent.getIntExtra("CLIENT_ID", -1)
        if (clientId == -1) {
            Toast.makeText(this, "Error al obtener el cliente", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        setContent {
            ClientJobAppTheme {
                ClientJobsScreen(
                    clientId = clientId,
                    onJobClick = { job ->
                        val intent = Intent(this, JobDetailActivity::class.java)
                        intent.putExtra("JOB_ID", job.id)
                        startActivity(intent)
                    },
                    onViewRecipes = { job ->
                        val intent = Intent(this, RecetasActivity::class.java)
                        intent.putExtra("JOB_ID", job.id)
                        startActivity(intent)
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClientJobsScreen(
    clientId: Int,
    onJobClick: (Job) -> Unit,
    onViewRecipes: (Job) -> Unit
) {
    val context = LocalContext.current
    val db = remember { AppDatabase.getDatabase(context) }
    var jobs by remember { mutableStateOf(listOf<Job>()) }
    var clientName by remember { mutableStateOf<String?>(null) }
    var clientLastName by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(true) }

    // Estado para diálogos
    var selectedJob by remember { mutableStateOf<Job?>(null) }
    var showBillingDialog by remember { mutableStateOf(false) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var showJobDialog by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()

    LaunchedEffect(clientId) {
        jobs = db.jobDao().getJobsByClientId(clientId)
        val client = db.clientDao().getById(clientId)
        clientName = client?.name ?: "Cliente desconocido"
        clientLastName = client?.lastname ?: "Apellido desconocido"
        isLoading = false
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(title = { Text("Trabajos de ${clientName ?: ""} ${clientLastName}") })
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showJobDialog = true }
            ) {
                Icon(
                    imageVector = androidx.compose.material.icons.Icons.Default.Add,
                    contentDescription = "Agregar trabajo"
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            if (isLoading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                if (jobs.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No se encontraron trabajos")
                    }
                } else {
                    LazyColumn {
                        items(jobs) { job ->
                            JobListItem(
                                job = job,
                                onClick = { onJobClick(job) },
                                onFinish = {
                                    val cal = Calendar.getInstance()
                                    DatePickerDialog(
                                        context,
                                        { _, year, month, dayOfMonth ->
                                            cal.set(year, month, dayOfMonth, 0, 0, 0)
                                            val finishMillis = cal.timeInMillis
                                            scope.launch {
                                                db.jobDao().update(
                                                    job.copy(status = "Finalizado", endDate = finishMillis)
                                                )
                                                jobs = db.jobDao().getJobsByClientId(clientId)
                                                Toast.makeText(
                                                    context,
                                                    "Trabajo finalizado el ${dayOfMonth}/${month + 1}/$year",
                                                    Toast.LENGTH_SHORT
                                                ).show()
                                            }
                                        },
                                        cal.get(Calendar.YEAR),
                                        cal.get(Calendar.MONTH),
                                        cal.get(Calendar.DAY_OF_MONTH)
                                    ).show()
                                },
                                onUpdateBilling = {
                                    selectedJob = job
                                    showBillingDialog = true
                                },
                                onDelete = {
                                    selectedJob = job
                                    showDeleteDialog = true
                                },
                                onViewRecipes = { onViewRecipes(job) }
                            )
                        }
                    }
                }
            }
        }
    }

    // Diálogo de Facturación
    if (showBillingDialog && selectedJob != null) {
        AlertDialog(
            onDismissRequest = { showBillingDialog = false },
            title = { Text("Selecciona el estado de facturación") },
            text = {
                Column {
                    listOf("Facturado", "No Facturado", "Pagado").forEach { option ->
                        Text(
                            text = option,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    scope.launch {
                                        db.jobDao().update(selectedJob!!.copy(billingStatus = option))
                                        jobs = db.jobDao().getJobsByClientId(clientId)
                                        Toast.makeText(context, "Facturación: $option", Toast.LENGTH_SHORT).show()
                                    }
                                    showBillingDialog = false
                                }
                                .padding(8.dp)
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showBillingDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }

    // Diálogo de eliminación
    if (showDeleteDialog && selectedJob != null) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Eliminar trabajo") },
            text = { Text("¿Seguro de eliminar este trabajo?") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        val images = db.imageDao().getImagesByJobId(selectedJob!!.id)
                        images.forEach {
                            try {
                                val file = java.io.File(it.imageUri.toUri().path ?: "")
                                if (file.exists()) file.delete()
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                        db.imageDao().deleteImagesByJobId(selectedJob!!.id)
                        db.jobDao().delete(selectedJob!!)
                        jobs = db.jobDao().getJobsByClientId(clientId)
                        Toast.makeText(context, "Trabajo eliminado", Toast.LENGTH_SHORT).show()
                    }
                    showDeleteDialog = false
                }) {
                    Text("Eliminar")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }

    // Diálogo para agregar o editar trabajo
    if (showJobDialog) {
        val clients = listOf(
            com.example.clientjobapp.data.Client(
                id = clientId,
                name = clientName ?: "Cliente desconocido",
                lastname = clientLastName ?: "Apellido desconocido"
            )
        )
        val initialJob = com.example.clientjobapp.data.Job(
            clientId = clientId,
            clientName = clientName ?: "Cliente desconocido",
            description = "",
            date = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date()),
            status = "Pendiente",
            startDate = 0L,
            endDate = 0L,
            surface = 0.0,
            valuePerHectare = 0.0,
            billingStatus = "No Facturado",
            notes = null,
            tipoAplicacion = "",
            latitude = null,
            longitude = null
        )
        JobDialogCompose(
            clients = clients,
            initialJob = initialJob,
            valuePerHectare = 0.0,
            onDismiss = { showJobDialog = false },
            onJobSaved = { newJob ->
                scope.launch {
                    db.jobDao().insert(newJob)
                    jobs = db.jobDao().getJobsByClientId(clientId)
                    Toast.makeText(context, "Trabajo agregado", Toast.LENGTH_SHORT).show()
                }
                showJobDialog = false
            }
        )
    }
}

@Composable
fun JobListItem(
    job: Job,
    onClick: () -> Unit,
    onFinish: () -> Unit,
    onUpdateBilling: () -> Unit,
    onDelete: () -> Unit,
    onViewRecipes: () -> Unit
) {
    // Determine background color based on job status
    val backgroundColor = when (job.status.lowercase()) {
        "pendiente" -> BackgroundLightYellow
        "finalizado" -> BackgroundLightGreen
        else -> Color.White
    }

    // Determine checkmark color based on billing status
    val checkmarkColor = when (job.billingStatus.lowercase()) {
        "no facturado" -> BillingRed
        "facturado" -> BillingYellow
        "pagado" -> BillingGreen
        else -> Color.Transparent
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .clickable { onClick() }
    ) {
        Box (modifier = Modifier.background(backgroundColor).fillMaxWidth()){
            // Checkmark icon in top-left corner
            if (checkmarkColor != Color.Transparent && job.billingStatus.lowercase() != "no facturado") {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Estado de facturación",
                    tint = checkmarkColor,
                    modifier = Modifier
                        .offset { IntOffset(924, 20) }
                        .size(28.dp)
                )
            }
            if (checkmarkColor != Color.Transparent && job.billingStatus.lowercase() == "no facturado") {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Estado de facturación",
                    tint = checkmarkColor,
                    modifier = Modifier
                        .offset { IntOffset(924, 20) }
                        .size(28.dp)
                )
            }
            var modifier = Modifier.background(backgroundColor)

            Column(modifier = Modifier.padding(16.dp)) {
                if (job.description != "") {
                    Text(text = job.description, style = MaterialTheme.typography.titleMedium)
                }
                Text(text = (DateFormatter.formatDate (job.date)))
                Text(text = "${job.tipoAplicacion}", style = MaterialTheme.typography.titleMedium)
                //Text(text = "Estado: ${job.status}")
                Text(text = "Hectareas: ${job.surface}")
                //Text(text = "Facturación: ${job.billingStatus}")
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.SpaceEvenly) {
                    if (job.status != "Finalizado")
                        TextButton(onClick = onFinish) { Text("Finalizar") }

                    TextButton(onClick = onUpdateBilling) { Text("Facturación") }
                    TextButton(onClick = onDelete) { Text("Eliminar") }
                    TextButton(onClick = onViewRecipes) { Text("Receta") }
                }
            }
        }
    }
}
