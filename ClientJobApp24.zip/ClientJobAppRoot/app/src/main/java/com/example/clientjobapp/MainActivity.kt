package com.example.clientjobapp

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.clientjobapp.ui.theme.ClientJobAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ClientJobAppTheme {
                MainScreen(
                    onClientsClick = { startActivity(Intent(this, ClientsActivity::class.java)) },
                    onJobsClick = { startActivity(Intent(this, JobsActivity::class.java)) },
                    onAdminClick = { startActivity(Intent(this, AdministracionGeneralActivity::class.java)) },
                    onProductosClick = { startActivity(Intent(this, ProductosActivity::class.java)) },
                    onSettingsClick = { startActivity(Intent(this, SettingsActivity::class.java)) }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    onClientsClick: () -> Unit,
    onJobsClick: () -> Unit,
    onAdminClick: () -> Unit,
    onProductosClick: () -> Unit,
    onSettingsClick: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Client Job App") },
                actions = {
                    IconButton(onClick = onSettingsClick) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp, Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Button(modifier = Modifier.fillMaxWidth(), onClick = onClientsClick) {
                Text("Clientes")
            }
            Button(modifier = Modifier.fillMaxWidth(), onClick = onJobsClick) {
                Text("Trabajos")
            }
            Button(modifier = Modifier.fillMaxWidth(), onClick = onAdminClick) {
                Text("Administración")
            }
            Button(modifier = Modifier.fillMaxWidth(), onClick = onProductosClick) {
                Text("Productos")
            }
        }
    }
}
