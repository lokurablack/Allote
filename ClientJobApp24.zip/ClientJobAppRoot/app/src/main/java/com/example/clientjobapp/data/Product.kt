package com.example.clientjobapp.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nombreComercial: String,
    val principioActivo: String,
    val tipo: String,
    val formulacionId: Int,
    val numeroRegistroSenasa: String? = null,
    val concentracion: String? = null,
    val fabricante: String? = null,
    val bandaToxicologica: String? = null,
    val modoAccion: String? = null
)
