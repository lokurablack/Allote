package com.example.clientjobapp

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.clientjobapp.data.Client

@Composable
fun ClientDialog(
    client: Client? = null,
    onDismissRequest: () -> Unit,
    onSave: (Client) -> Unit
) {
    var name by remember { mutableStateOf(client?.name ?: "") }
    var lastName by remember { mutableStateOf(client?.lastname ?: "") }
    var phone by remember { mutableStateOf(client?.phone ?: "") }
    var email by remember { mutableStateOf(client?.email ?: "") }
    var cuit by remember { mutableStateOf(client?.cuit ?: "") }
    var localidad by remember { mutableStateOf(client?.localidad ?: "") }
    var direccion by remember { mutableStateOf(client?.direccion ?: "") }

    var nameError by remember { mutableStateOf(false) }
    var lastNameError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismissRequest,
        title = { Text(text = if (client == null) "Crear Cliente" else "Editar Cliente") },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        nameError = it.isBlank()
                    },
                    label = { Text("Nombre*") },
                    isError = nameError,
                    modifier = Modifier.fillMaxWidth()
                )
                if (nameError) {
                    Text("El nombre es obligatorio", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = lastName,
                    onValueChange = {
                        lastName = it
                        lastNameError = it.isBlank()
                    },
                    label = { Text("Apellido*") },
                    isError = lastNameError,
                    modifier = Modifier.fillMaxWidth()
                )
                if (lastNameError) {
                    Text("El apellido es obligatorio", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Teléfono") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = cuit,
                    onValueChange = { cuit = it },
                    label = { Text("CUIT (xx-xxxxxxxx-x)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = localidad,
                    onValueChange = { localidad = it },
                    label = { Text("Localidad") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = direccion,
                    onValueChange = { direccion = it },
                    label = { Text("Dirección") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    nameError = name.isBlank()
                    lastNameError = lastName.isBlank()
                    if (!nameError && !lastNameError) {
                        val newClient = Client(
                            id = client?.id ?: 0,
                            name = name,
                            lastname = lastName,
                            phone = phone.ifBlank { null },
                            email = email.ifBlank { null },
                            cuit = cuit.ifBlank { null },
                            localidad = localidad.ifBlank { null },
                            direccion = direccion.ifBlank { null }
                        )
                        onSave(newClient)
                    }
                }
            ) {
                Text("Guardar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismissRequest) {
                Text("Cancelar")
            }
        }
    )
}
