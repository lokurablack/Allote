package com.example.clientjobapp

import android.app.Application
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.clientjobapp.data.AppDatabase
import com.example.clientjobapp.data.Job
import com.example.clientjobapp.data.AdministracionTrabajo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class TotalsState(
    val totalFinalizados: Double = 0.0,
    val totalPendientes: Double = 0.0,
    val totalNoFacturados: Double = 0.0,
    val totalFacturados: Double = 0.0,
    val totalPagados: Double = 0.0
)

class AdministracionGeneralViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)

    private val _totals = MutableStateFlow(TotalsState())
    val totals: StateFlow<TotalsState> = _totals

    init {
        loadTotals()
    }

    private fun loadTotals() {
        viewModelScope.launch {
            try {
                val jobs: List<Job> = db.jobDao().getAll()
                val administracionList: List<AdministracionTrabajo> = db.administracionDao().getAllAdministracionTrabajos()
                val administracionMap = administracionList.associateBy { it.jobId }

                var totalFinalizadosLocal = 0.0
                var totalPendientesLocal = 0.0
                var totalNoFacturadosLocal = 0.0
                var totalFacturadosLocal = 0.0
                var totalPagadosLocal = 0.0

                for (job in jobs) {
                    val adm = administracionMap[job.id]
                    val costoPorHectarea = adm?.costoPorHectarea ?: 0.0
                    val surface = job.surface

                    val totalJob = costoPorHectarea * surface

                    when (job.status?.lowercase() ?: "") {
                        "finalizado", "finalizados" -> totalFinalizadosLocal += totalJob
                        "pendiente", "pendientes" -> totalPendientesLocal += totalJob
                    }

                    when (job.billingStatus?.lowercase() ?: "") {
                        "no facturado" -> totalNoFacturadosLocal += totalJob
                        "facturado" -> totalFacturadosLocal += totalJob
                        "pagado" -> totalPagadosLocal += totalJob
                    }
                }

                _totals.value = TotalsState(
                    totalFinalizados = totalFinalizadosLocal,
                    totalPendientes = totalPendientesLocal,
                    totalNoFacturados = totalNoFacturadosLocal,
                    totalFacturados = totalFacturadosLocal,
                    totalPagados = totalPagadosLocal
                )

            } catch (e: Exception) {
                Toast.makeText(getApplication(), "Error al cargar datos administrativos", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
