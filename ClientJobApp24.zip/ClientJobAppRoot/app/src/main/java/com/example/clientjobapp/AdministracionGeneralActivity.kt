package com.example.clientjobapp

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.clientjobapp.ui.AdministracionGeneralScreen

class AdministracionGeneralActivity : AppCompatActivity() {

    private val viewModel: AdministracionGeneralViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            AdministracionGeneralScreen(viewModel = viewModel)
        }
    }
}
