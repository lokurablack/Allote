package com.example.clientjobapp

import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.example.clientjobapp.data.AppDatabase
import com.example.clientjobapp.data.JobParametros
import kotlinx.coroutines.launch
import androidx.compose.foundation.text.KeyboardOptions

class ParametrosActivity : AppCompatActivity() {
    private lateinit var db: AppDatabase
    private var jobId: Int = -1
    private var tipoAplicacion: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        db = AppDatabase.getDatabase(this)
        jobId = intent.getIntExtra("JOB_ID", -1)

        if (jobId == -1) {
            Toast.makeText(this, "ID de trabajo inválido", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        lifecycleScope.launch {
            val job = db.jobDao().getById(jobId)
            if (job == null) {
                Toast.makeText(this@ParametrosActivity, "Trabajo no encontrado", Toast.LENGTH_SHORT).show()
                finish()
                return@launch
            }
            tipoAplicacion = job.tipoAplicacion ?: ""

            val parametros = db.jobParametrosDao().getByJobId(jobId)

            runOnUiThread {
                setContent {
                    MaterialTheme {
                        Surface(modifier = Modifier.fillMaxSize()) {
                            ParametrosScreen(
                                tipoAplicacion = tipoAplicacion,
                                initialParametros = parametros,
                                onSave = { newParametros ->
                                    lifecycleScope.launch {
                                        db.jobParametrosDao().insert(
                                            newParametros.copy(
                                                id = parametros?.id ?: 0,
                                                jobId = jobId
                                            )
                                        )
                                        runOnUiThread {
                                            Toast.makeText(this@ParametrosActivity, "Parámetros guardados", Toast.LENGTH_SHORT).show()
                                            finish()
                                        }
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ParametrosScreen(
    tipoAplicacion: String,
    initialParametros: JobParametros?,
    onSave: (JobParametros) -> Unit
) {
    val dosisUnit = when (tipoAplicacion.lowercase()) {
        "aplicacion liquida" -> "l/ha"
        "aplicacion solida" -> "kg/ha"
        else -> "unidad"
    }

    var dosis by remember { mutableStateOf(initialParametros?.dosis?.toString() ?: "") }
    var tamanoGota by remember { mutableStateOf(initialParametros?.tamanoGota?.toString() ?: "") }
    var interlineado by remember { mutableStateOf(initialParametros?.interlineado?.toString() ?: "") }
    var velocidad by remember { mutableStateOf(initialParametros?.velocidad?.toString() ?: "") }
    var altura by remember { mutableStateOf(initialParametros?.altura?.toString() ?: "") }
    var revoluciones by remember { mutableStateOf(initialParametros?.revoluciones?.toString() ?: "") }
    var discoUtilizado by remember { mutableStateOf(initialParametros?.discoUtilizado ?: "") }
    var expanded by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val discoOptions = listOf("Disco grande", "Disco chico")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .systemBarsPadding()
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(text = "Dosis ($dosisUnit)", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(
            value = dosis,
            onValueChange = { dosis = it },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true
        )

        if (tipoAplicacion.lowercase() == "aplicacion liquida") {
            Text(text = "Tamaño de gota (micrones)", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = tamanoGota,
                onValueChange = { tamanoGota = it },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true
            )
        }

        Text(text = "Interlineado (metros)", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(
            value = interlineado,
            onValueChange = { interlineado = it },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true
        )

        Text(text = "Velocidad (km/h)", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(
            value = velocidad,
            onValueChange = { velocidad = it },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true
        )

        Text(text = "Altura (metros)", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(
            value = altura,
            onValueChange = { altura = it },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true
        )

        if (tipoAplicacion.lowercase() == "aplicacion solida") {
            Text(text = "Disco utilizado", style = MaterialTheme.typography.titleMedium)
            ExposedDropdownMenuBox(
                expanded = expanded,
                onExpandedChange = { expanded = !expanded }
            ) {
                OutlinedTextField(
                    value = discoUtilizado,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Seleccione disco") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth()
                )
                ExposedDropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    discoOptions.forEach { option ->
                        DropdownMenuItem(
                            text = { Text(option) },
                            onClick = {
                                discoUtilizado = option
                                expanded = false
                            }
                        )
                    }
                }
            }

            Text(text = "Revoluciones", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = revoluciones,
                onValueChange = { revoluciones = it },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true
            )
        }

        Button(
            onClick = {
                val dosisDouble = dosis.toDoubleOrNull()
                val tamanoGotaDouble = tamanoGota.toDoubleOrNull()
                val interlineadoDouble = interlineado.toDoubleOrNull()
                val velocidadDouble = velocidad.toDoubleOrNull()
                val alturaDouble = altura.toDoubleOrNull()
                val revolucionesDouble = revoluciones.toDoubleOrNull()
                val disco = if (tipoAplicacion.lowercase() == "aplicacion solida") discoUtilizado else null

                if (dosisDouble == null) {
                    Toast.makeText(context, "Ingrese un valor válido para dosis", Toast.LENGTH_SHORT).show()
                    return@Button
                }

                onSave(
                    JobParametros(
                        id = initialParametros?.id ?: 0,
                        jobId = initialParametros?.jobId ?: 0,
                        dosis = dosisDouble,
                        tamanoGota = tamanoGotaDouble,
                        interlineado = interlineadoDouble,
                        velocidad = velocidadDouble,
                        altura = alturaDouble,
                        discoUtilizado = disco,
                        revoluciones = revolucionesDouble
                    )
                )
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = "Guardar")
        }
    }
}

