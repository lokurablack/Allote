package com.example.clientjobapp.data

import androidx.room.*

@Dao
interface AdministracionDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(adm: AdministracionTrabajo)

    @Query("SELECT * FROM AdministracionTrabajo WHERE jobId = :jobId LIMIT 1")
    suspend fun getByJobId(jobId: Int): AdministracionTrabajo?

    @Query("SELECT * FROM AdministracionTrabajo")
    suspend fun getAllAdministracionTrabajos(): List<AdministracionTrabajo>

    @Query("SELECT * FROM documento_trabajo WHERE jobId = :jobId")
    suspend fun getAllDocumentsForJob(jobId: Int): List<DocumentoTrabajo>

    @Insert
    suspend fun insertDocumento(documento: DocumentoTrabajo)

    @Delete
    suspend fun deleteDocumento(documento: DocumentoTrabajo)

    // (Opcional) para borrar por URI directamente:
    @Query("DELETE FROM documento_trabajo WHERE documentUri = :uri")
    suspend fun deleteByUri(uri: String)
}
