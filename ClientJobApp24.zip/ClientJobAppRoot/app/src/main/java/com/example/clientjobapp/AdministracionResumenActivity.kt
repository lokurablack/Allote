package com.example.clientjobapp

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import com.example.clientjobapp.data.AppDatabase
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class AdministracionResumenActivity : ComponentActivity() {

    private var jobId: Int = -1
    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        jobId = intent.getIntExtra("JOB_ID", -1)
        db = AppDatabase.getDatabase(this)

        setContent {
            MaterialTheme {
                AdministracionResumenScreen(jobId, db) {
                    Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        }
    }
}

@Composable
fun AdministracionResumenScreen(
    jobId: Int,
    db: AppDatabase,
    onError: (String) -> Unit
) {
    var resumen by remember { mutableStateOf<ResumenData?>(null) }

    LaunchedEffect(jobId) {
        if (jobId != -1) {
            val job = db.jobDao().getById(jobId)
            val adm = db.administracionDao().getByJobId(jobId)

            if (job != null && adm != null) {
                resumen = ResumenData(
                    hectareas = job.surface,
                    costoPorHectarea = adm.costoPorHectarea,
                    totalSinIVA = adm.totalSinIVA,
                    totalConIVA = adm.totalConIVA,
                    aplicaIVA = adm.aplicaIVA
                )
            } else {
                onError("Datos no encontrados")
            }
        } else {
            onError("ID inválido")
        }
    }

    resumen?.let {
        ResumenUI(it)
    }
}

@Composable
fun ResumenUI(resumen: ResumenData) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Hectáreas: %.2f".format(resumen.hectareas), style = MaterialTheme.typography.titleMedium)
        Text("Costo por hectárea: UsD %.2f".format(resumen.costoPorHectarea), style = MaterialTheme.typography.bodyLarge)
        Text("Total sin IVA: UsD %.2f".format(resumen.totalSinIVA), style = MaterialTheme.typography.bodyLarge)
        Text("Total con IVA: UsD %.2f".format(resumen.totalConIVA), style = MaterialTheme.typography.bodyLarge)
        Text("IVA aplicado: ${if (resumen.aplicaIVA) "Sí (10.5%)" else "No"}", style = MaterialTheme.typography.bodyLarge)
    }
}

data class ResumenData(
    val hectareas: Double,
    val costoPorHectarea: Double,
    val totalSinIVA: Double,
    val totalConIVA: Double,
    val aplicaIVA: Boolean
)