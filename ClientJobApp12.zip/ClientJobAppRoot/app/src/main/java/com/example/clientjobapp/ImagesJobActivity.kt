package com.example.clientjobapp

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ImagesJobActivity : AppCompatActivity() {

    private val selectedImageUris = mutableListOf<Uri>()
    private lateinit var imageAdapter: ImageAdapter
    private var jobId: Int = -1

    private val selectImageLauncher = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) {
            selectedImageUris.addAll(uris)
            imageAdapter.notifyDataSetChanged()
        } else {
            Toast.makeText(this, "No se seleccionó ninguna imagen", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_images_job)

        jobId = intent.getIntExtra("JOB_ID", -1)
        if (jobId == -1) {
            Toast.makeText(this, "Trabajo no encontrado", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        val buttonSelectImage = findViewById<Button>(R.id.buttonSelectImage)
        val recyclerViewImages = findViewById<RecyclerView>(R.id.recyclerViewImages)

        imageAdapter = ImageAdapter(selectedImageUris)
        recyclerViewImages.layoutManager = LinearLayoutManager(this)
        recyclerViewImages.adapter = imageAdapter

        buttonSelectImage.setOnClickListener {
            selectImageLauncher.launch("image/*")
        }
    }
}
