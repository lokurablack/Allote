package com.example.clientjobapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.clientjobapp.data.AppDatabase
import com.example.clientjobapp.data.Product
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.launch

class ProductDetailActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private var productId: Int = -1
    private var currentProduct: Product? = null

    private lateinit var nombreComercialTextView: TextView
    private lateinit var principioActivoTextView: TextView
    private lateinit var tipoTextView: TextView
    private lateinit var formulacionTextView: TextView

    private lateinit var btnAgregarMasDatos: Button

    private lateinit var textViewNumeroRegistroSenasa: TextView
    private lateinit var textViewConcentracion: TextView
    private lateinit var textViewFabricante: TextView
    private lateinit var textViewBandaToxicologica: TextView
    private lateinit var textViewModoAccion: TextView

    private val bandaOptions = listOf("la", "lb", "II", "III", "IV")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product_detail)

        db = AppDatabase.getDatabase(this)
        productId = intent.getIntExtra("PRODUCT_ID", -1)

        nombreComercialTextView = findViewById(R.id.textViewNombreComercial)
        principioActivoTextView = findViewById(R.id.textViewPrincipioActivo)
        tipoTextView = findViewById(R.id.textViewTipo)
        formulacionTextView = findViewById(R.id.textViewFormulacion)

        btnAgregarMasDatos = findViewById(R.id.btnAgregarMasDatos)

        textViewNumeroRegistroSenasa = findViewById(R.id.textViewNumeroRegistroSenasa)
        textViewConcentracion = findViewById(R.id.textViewConcentracion)
        textViewFabricante = findViewById(R.id.textViewFabricante)
        textViewBandaToxicologica = findViewById(R.id.textViewBandaToxicologica)
        textViewModoAccion = findViewById(R.id.textViewModoAccion)

        if (productId == -1) {
            finish()
            return
        }

        lifecycleScope.launch {
            val product = db.productDao().getAll().find { it.id == productId }
            if (product != null) {
                currentProduct = product
                runOnUiThread {
                    bind(product)
                }
            } else {
                finish()
            }
        }

        btnAgregarMasDatos.setOnClickListener {
            mostrarDialogoMasDatos()
        }
    }

    private fun bind(product: Product) {
        nombreComercialTextView.text = product.nombreComercial
        principioActivoTextView.text = "Principio Activo: ${product.principioActivo}"
        tipoTextView.text = "Tipo: ${product.tipo}"
        formulacionTextView.text = "Formulación: ${product.formulacion}"

        if (!product.numeroRegistroSenasa.isNullOrBlank()) {
            textViewNumeroRegistroSenasa.text = "Número de registro en SENASA: ${product.numeroRegistroSenasa}"
            textViewNumeroRegistroSenasa.visibility = android.view.View.VISIBLE
        } else {
            textViewNumeroRegistroSenasa.visibility = android.view.View.GONE
        }

        if (!product.concentracion.isNullOrBlank()) {
            textViewConcentracion.text = "Concentración: ${product.concentracion}"
            textViewConcentracion.visibility = android.view.View.VISIBLE
        } else {
            textViewConcentracion.visibility = android.view.View.GONE
        }

        if (!product.fabricante.isNullOrBlank()) {
            textViewFabricante.text = "Fabricante: ${product.fabricante}"
            textViewFabricante.visibility = android.view.View.VISIBLE
        } else {
            textViewFabricante.visibility = android.view.View.GONE
        }

        if (!product.bandaToxicologica.isNullOrBlank()) {
            textViewBandaToxicologica.text = "Banda Toxicológica: ${product.bandaToxicologica}"
            textViewBandaToxicologica.visibility = android.view.View.VISIBLE
        } else {
            textViewBandaToxicologica.visibility = android.view.View.GONE
        }

        if (!product.modoAccion.isNullOrBlank()) {
            textViewModoAccion.text = "Modo de Acción: ${product.modoAccion}"
            textViewModoAccion.visibility = android.view.View.VISIBLE
        } else {
            textViewModoAccion.visibility = android.view.View.GONE
        }
    }

    private fun mostrarDialogoMasDatos() {
        val inflater = layoutInflater
        val dialogView = inflater.inflate(R.layout.dialog_add_product_extra_data, null)

        val etNumeroRegistroSenasa = dialogView.findViewById<EditText>(R.id.etNumeroRegistroSenasa)
        val etConcentracion = dialogView.findViewById<EditText>(R.id.etConcentracion)
        val etFabricante = dialogView.findViewById<EditText>(R.id.etFabricante)
        val spinnerBandaToxicologica = dialogView.findViewById<Spinner>(R.id.spinnerBandaToxicologica)
        val etModoAccion = dialogView.findViewById<EditText>(R.id.etModoAccion)

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, bandaOptions)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerBandaToxicologica.adapter = adapter

        currentProduct?.let { product ->
            etNumeroRegistroSenasa.setText(product.numeroRegistroSenasa ?: "")
            etConcentracion.setText(product.concentracion ?: "")
            etFabricante.setText(product.fabricante ?: "")
            val bandaIndex = bandaOptions.indexOf(product.bandaToxicologica)
            spinnerBandaToxicologica.setSelection(if (bandaIndex >= 0) bandaIndex else 0)
            etModoAccion.setText(product.modoAccion ?: "")
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("Agregar más datos")
            .setView(dialogView)
            .setPositiveButton("Guardar") { _, _ ->
                val numeroRegistroSenasa = etNumeroRegistroSenasa.text.toString().takeIf { it.isNotBlank() }
                val concentracion = etConcentracion.text.toString().takeIf { it.isNotBlank() }
                val fabricante = etFabricante.text.toString().takeIf { it.isNotBlank() }
                val bandaToxicologica = spinnerBandaToxicologica.selectedItem as String
                val modoAccion = etModoAccion.text.toString().takeIf { it.isNotBlank() }

                val updatedProduct = currentProduct?.copy(
                    numeroRegistroSenasa = numeroRegistroSenasa,
                    concentracion = concentracion,
                    fabricante = fabricante,
                    bandaToxicologica = bandaToxicologica,
                    modoAccion = modoAccion
                )

                if (updatedProduct != null) {
                    lifecycleScope.launch {
                        db.productDao().update(updatedProduct)
                        runOnUiThread {
                            Toast.makeText(this@ProductDetailActivity, "Datos guardados correctamente", Toast.LENGTH_SHORT).show()
                            currentProduct = updatedProduct
                            bind(updatedProduct)
                        }
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
