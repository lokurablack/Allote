package com.example.clientjobapp

import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.clientjobapp.data.AppDatabase
import com.example.clientjobapp.data.Job
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class JobsActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private lateinit var swipeRefreshLayout: SwipeRefreshLayout
    private lateinit var progressBar: View

    private lateinit var rvPendingJobs: RecyclerView
    private lateinit var rvFinishedJobs: RecyclerView
    private lateinit var tvPendingHeader: TextView
    private lateinit var tvFinishedHeader: TextView

    private lateinit var pendingJobAdapter: JobAdapter
    private lateinit var finishedJobAdapter: JobAdapter

    private var fromDateMillis: Long? = null
    private var toDateMillis: Long? = null

    private val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

    private val jobAddedReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: android.content.Intent?) {
            refreshSpinners()
            loadJobs()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_jobs_separated)

        db = AppDatabase.getDatabase(this)
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayoutJobs)
        progressBar = findViewById(R.id.progressBarJobs)

        rvPendingJobs = findViewById(R.id.rvPendingJobs)
        rvFinishedJobs = findViewById(R.id.rvFinishedJobs)
        tvPendingHeader = findViewById(R.id.tvPendingHeader)
        tvFinishedHeader = findViewById(R.id.tvFinishedHeader)

        rvPendingJobs.layoutManager = LinearLayoutManager(this)
        rvFinishedJobs.layoutManager = LinearLayoutManager(this)

        pendingJobAdapter = JobAdapter(
            context = this,
            onClick = { job ->
                startActivity(
                    Intent(this, JobDetailActivity::class.java)
                        .putExtra("JOB_ID", job.id)
                )
            },
            onLongClick = { job -> showJobOptions(job) }
        )
        finishedJobAdapter = JobAdapter(
            context = this,
            onClick = { job ->
                startActivity(
                    Intent(this, JobDetailActivity::class.java)
                        .putExtra("JOB_ID", job.id)
                )
            },
            onLongClick = { job -> showJobOptions(job) }
        )

        rvPendingJobs.adapter = pendingJobAdapter
        rvFinishedJobs.adapter = finishedJobAdapter

        registerReceiver(jobAddedReceiver,
            android.content.IntentFilter("com.example.clientjobapp.JOB_ADDED"), Context.RECEIVER_NOT_EXPORTED)


        val acStatus = findViewById<AutoCompleteTextView>(R.id.spinnerStatus)
        val acBilling = findViewById<AutoCompleteTextView>(R.id.spinnerBillingStatus)
        val acClient = findViewById<AutoCompleteTextView>(R.id.spinnerClient)
        val acTipoAplicacion = findViewById<AutoCompleteTextView>(R.id.spinnerTipoAplicacion)
        val etFrom = findViewById<TextInputEditText>(R.id.inputStartDate)
        val etTo = findViewById<TextInputEditText>(R.id.inputEndDate)

        val buttonToggleFilters = findViewById<MaterialButton>(R.id.buttonToggleFilters)
        val buttonValueHa = findViewById<MaterialButton>(R.id.buttonValueHa)
        val filterContainer = findViewById<LinearLayout>(R.id.filterContainer)

        val sharedPrefs = getSharedPreferences("app_prefs", MODE_PRIVATE)
        var valuePerHa = sharedPrefs.getFloat("value_per_ha", 0.0f)

        buttonToggleFilters.setOnClickListener {
            if (filterContainer.visibility == View.GONE) {
                filterContainer.visibility = View.VISIBLE
                buttonToggleFilters.text = "Ocultar filtros"
            } else {
                filterContainer.visibility = View.GONE
                buttonToggleFilters.text = "Mostrar filtros"
                // Además, al ocultar, aplicamos los filtros
                filterJobs(
                    acStatus.text.toString(),
                    acBilling.text.toString(),
                    acClient.text.toString(),
                    acTipoAplicacion.text.toString()
                )
            }
        }

        buttonValueHa.setOnClickListener {
            val inflater = layoutInflater
            val dialogView = inflater.inflate(R.layout.dialog_value_per_ha, null)

            val editTextLiquida = dialogView.findViewById<EditText>(R.id.editTextAplicacionLiquida)
            val editTextSolida = dialogView.findViewById<EditText>(R.id.editTextAplicacionSolida)
            val editTextMixta = dialogView.findViewById<EditText>(R.id.editTextAplicacionMixta)
            val editTextVarias = dialogView.findViewById<EditText>(R.id.editTextAplicacionVarias)

            val sharedPrefs = getSharedPreferences("app_prefs", MODE_PRIVATE)
            val liquidaValue = sharedPrefs.getFloat("value_per_ha_liquida", 0.0f)
            val solidaValue = sharedPrefs.getFloat("value_per_ha_solida", 0.0f)
            val mixtaValue = sharedPrefs.getFloat("value_per_ha_mixta", 0.0f)
            val variasValue = sharedPrefs.getFloat("value_per_ha_varias", 0.0f)

            if (liquidaValue > 0) editTextLiquida.setText(liquidaValue.toString())
            if (solidaValue > 0) editTextSolida.setText(solidaValue.toString())
            if (mixtaValue > 0) editTextMixta.setText(mixtaValue.toString())
            if (variasValue > 0) editTextVarias.setText(variasValue.toString())

            MaterialAlertDialogBuilder(this)
                .setTitle("Valor por Hectárea (USD)")
                .setView(dialogView)
                .setPositiveButton("Guardar") { _, _ ->
                    val liquidaInput = editTextLiquida.text.toString().toFloatOrNull()
                    val solidaInput = editTextSolida.text.toString().toFloatOrNull()
                    val mixtaInput = editTextMixta.text.toString().toFloatOrNull()
                    val variasInput = editTextVarias.text.toString().toFloatOrNull()

                    val editor = sharedPrefs.edit()
                    if (liquidaInput != null && liquidaInput > 0) {
                        editor.putFloat("value_per_ha_liquida", liquidaInput)
                    } else {
                        editor.remove("value_per_ha_liquida")
                    }
                    if (solidaInput != null && solidaInput > 0) {
                        editor.putFloat("value_per_ha_solida", solidaInput)
                    } else {
                        editor.remove("value_per_ha_solida")
                    }
                    if (mixtaInput != null && mixtaInput > 0) {
                        editor.putFloat("value_per_ha_mixta", mixtaInput)
                    } else {
                        editor.remove("value_per_ha_mixta")
                    }
                    if (variasInput != null && variasInput > 0) {
                        editor.putFloat("value_per_ha_varias", variasInput)
                    } else {
                        editor.remove("value_per_ha_varias")
                    }
                    editor.apply()

                    Snackbar.make(findViewById(android.R.id.content), "Valores guardados", Snackbar.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }

        // Re-implementación del filtro "Estado" con cuadro emergente
        val estadoOptions = listOf("Todos", "Pendientes", "Finalizados")
        acStatus.setAdapter(ArrayAdapter(this,
            android.R.layout.simple_list_item_1, estadoOptions))
        acStatus.setOnClickListener {
            acStatus.showDropDown()
        }
        acStatus.setOnItemClickListener { _, _, _, _ ->
            filterJobs(
                acStatus.text.toString(),
                acBilling.text.toString(),
                acClient.text.toString(),
                acTipoAplicacion.text.toString()
            )
        }


        // Re-implementación del filtro "Estado de facturación" con cuadro emergente
        val billingOptions = listOf("Todos", "No Facturado", "Facturado", "Pagado")
        acBilling.setAdapter(ArrayAdapter(this,
            android.R.layout.simple_list_item_1, billingOptions))
        acBilling.setOnClickListener {
            acBilling.showDropDown()
        }
        acBilling.setOnItemClickListener { _, _, _, _ ->
            filterJobs(
                acStatus.text.toString(),
                acBilling.text.toString(),
                acClient.text.toString(),
                acTipoAplicacion.text.toString()
            )
        }

        // Re-implementación del filtro "Cliente" con cuadro emergente
        lifecycleScope.launch {
            val clientNames = listOf("Todos") + db.jobDao().getAll().map { it.clientName }.distinct().sorted()
            acClient.setAdapter(ArrayAdapter(this@JobsActivity,
                android.R.layout.simple_list_item_1, clientNames))
        }
        acClient.setOnClickListener {
            acClient.showDropDown()
        }
        acClient.setOnItemClickListener { _, _, _, _ ->
            filterJobs(
                acStatus.text.toString(),
                acBilling.text.toString(),
                acClient.text.toString(),
                acTipoAplicacion.text.toString()
            )
        }
        acTipoAplicacion.setOnClickListener {
            acTipoAplicacion.showDropDown()
        }
        acTipoAplicacion.setOnItemClickListener { _, _, _, _ ->
            filterJobs(
                acStatus.text.toString(),
                acBilling.text.toString(),
                acClient.text.toString(),
                acTipoAplicacion.text.toString()
            )
        }

        lifecycleScope.launch {
            acStatus.setAdapter(ArrayAdapter(this@JobsActivity,
                android.R.layout.simple_list_item_1, getStatusOptions()))
        }
        lifecycleScope.launch {
            acBilling.setAdapter(ArrayAdapter(this@JobsActivity,
                android.R.layout.simple_list_item_1, getBillingOptions()))
        }
        lifecycleScope.launch {
            acClient.setAdapter(ArrayAdapter(this@JobsActivity,
                android.R.layout.simple_list_item_1, getClientNames()))
        }
        lifecycleScope.launch {
            acTipoAplicacion.setAdapter(ArrayAdapter(this@JobsActivity,
                android.R.layout.simple_list_item_1, getTipoAplicacionOptions()))
        }

        etFrom.setOnClickListener {
            showDatePicker { millis ->
                fromDateMillis = millis
                etFrom.setText(dateFormat.format(Date(millis)))
                filterJobs(
                    acStatus.text.toString(),
                    acBilling.text.toString(),
                    acClient.text.toString(),
                    acTipoAplicacion.text.toString()
                )
            }
        }

        etTo.setOnClickListener {
            showDatePicker { millis ->
                toDateMillis = millis
                etTo.setText(dateFormat.format(Date(millis)))
                filterJobs(
                    acStatus.text.toString(),
                    acBilling.text.toString(),
                    acClient.text.toString(),
                    acTipoAplicacion.text.toString()
                )
            }
        }

        findViewById<FloatingActionButton>(R.id.fabAddJob).setOnClickListener {
            JobDialog(
                context = this,
                db = db,
                valuePerHectare = valuePerHa.toDouble(),
                onJobSaved = { job ->
                    lifecycleScope.launch {
                        db.jobDao().insert(job)
                        sendBroadcast(Intent("com.example.clientjobapp.JOB_ADDED"))
                        loadJobs()
                        Snackbar.make(
                            findViewById(android.R.id.content),
                            "Trabajo añadido",
                            Snackbar.LENGTH_SHORT
                        ).show()
                    }
                }
            ).show()
        }

        swipeRefreshLayout.setOnRefreshListener { loadJobs() }

        loadJobs()
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(jobAddedReceiver)
    }

    private fun loadJobs() {
        progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            val allJobs = db.jobDao().getAll()
            updateJobLists(allJobs)
            progressBar.visibility = View.GONE
            swipeRefreshLayout.isRefreshing = false
        }
    }

    private fun filterJobs(status: String, billing: String, client: String, tipoAplicacion: String) {
        lifecycleScope.launch {
            var list = db.jobDao().getAll()
            if (status.isNotBlank() && status != "Todos")
                list = list.filter { it.status.equals(status, true) }
            if (billing.isNotBlank() && billing != "Todos")
                list = list.filter { it.billingStatus.equals(billing, true) }
            if (client.isNotBlank() && client != "Todos")
                list = list.filter { it.clientName.equals(client, true) }
            if (fromDateMillis != null)
                list = list.filter { it.createdAt >= fromDateMillis!! }
            if (toDateMillis != null)
                list = list.filter { it.createdAt <= toDateMillis!! }

            val tipoAplicacionFilter = findViewById<AutoCompleteTextView>(R.id.spinnerTipoAplicacion).text.toString()
            if (tipoAplicacionFilter.isNotBlank() && tipoAplicacionFilter != "Todos") {
                list = list.filter { it.tipoAplicacion.equals(tipoAplicacionFilter, true) }
            }

            updateJobLists(list)
        }
    }

    private fun updateJobLists(jobs: List<Job>) {
        val pendingJobs = jobs.filter { it.status.equals("Pendiente", true) }
        val finishedJobs = jobs.filter { it.status.equals("Finalizado", true) }

        val totalPendingHectares = pendingJobs.sumOf { it.surface ?: 0.0 }
        val totalFinishedHectares = finishedJobs.sumOf { it.surface ?: 0.0 }

        tvPendingHeader.text = "Pendientes (Total: %.2f ha)".format(totalPendingHectares)
        tvFinishedHeader.text = "Finalizados (Total: %.2f ha)".format(totalFinishedHectares)

        pendingJobAdapter.updateData(pendingJobs)
        finishedJobAdapter.updateData(finishedJobs)
    }

    private fun showDatePicker(onDateSelected: (Long) -> Unit) {
        val cal = Calendar.getInstance()
        DatePickerDialog(
            this,
            { _, y, m, d ->
                cal.set(y, m, d, 0, 0, 0)
                onDateSelected(cal.timeInMillis)
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private suspend fun getClientNames(): List<String> =
        listOf("Todos") + db.jobDao().getAll().map { it.clientName }.distinct().sorted()

    private suspend fun getStatusOptions(): List<String> =
        listOf("Todos") + db.jobDao().getAll().map { it.status }.distinct().sorted()

    private suspend fun getBillingOptions(): List<String> =
        listOf("Todos", "No Facturado", "Facturado", "Pagado")

    private suspend fun getTipoAplicacionOptions(): List<String> =
        listOf("Todos") + db.jobDao().getAll().mapNotNull { it.tipoAplicacion }.distinct().sorted()

    private fun showJobOptions(job: Job) {
        val opts = arrayOf("Marcar finalizado", "Editar", "Eliminar", "Facturación", "Recetas")
        MaterialAlertDialogBuilder(this)
            .setTitle("Opciones")
            .setItems(opts) { _, idx ->
                when (idx) {
                    0 -> markAsFinished(job)
                    1 -> editJob(job)
                    2 -> deleteWithConfirm(job)
                    3 -> showBillingDialog(job)
                    4 -> {
                        val intent = android.content.Intent(this, RecetasActivity::class.java)
                        intent.putExtra("JOB_ID", job.id)
                        startActivity(intent)
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun markAsFinished(job: Job) {
        val cal = Calendar.getInstance()
        DatePickerDialog(
            this,
            { _, y, m, d ->
                cal.set(y, m, d, 0, 0, 0)
                lifecycleScope.launch {
                    db.jobDao().update(job.copy(
                        status = "Finalizado",
                        endDate = cal.timeInMillis
                    ))
                    loadJobs()
                }
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun editJob(job: Job) {
        JobDialog(
            context = this,
            db = db,
            onJobSaved = { updated ->
                lifecycleScope.launch {
                    db.jobDao().update(updated)
                    loadJobs()
                }
            },
            job = job
        ).show()
    }

    private fun deleteWithConfirm(job: Job) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Eliminar trabajo")
            .setMessage("¿Seguro?")
            .setPositiveButton("Eliminar") { _, _ -> deleteJob(job) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun deleteJob(job: Job) {
        lifecycleScope.launch {
            db.jobDao().delete(job)
            loadJobs()
        }
    }

    private fun showBillingDialog(job: Job) {
        val opts = arrayOf("No Facturado", "Facturado", "Pagado")
        MaterialAlertDialogBuilder(this)
            .setTitle("Estado de facturación")
            .setItems(opts) { _, idx ->
                val status = opts[idx]
                lifecycleScope.launch {
                    db.jobDao().update(job.copy(billingStatus = status))
                    loadJobs()
                }
            }
            .show()
    }

    private fun refreshSpinners() {
        lifecycleScope.launch {
            findViewById<AutoCompleteTextView>(R.id.spinnerClient)
                .setAdapter(ArrayAdapter(this@JobsActivity,
                    android.R.layout.simple_list_item_1, getClientNames()))
            findViewById<AutoCompleteTextView>(R.id.spinnerStatus)
                .setAdapter(ArrayAdapter(this@JobsActivity,
                    android.R.layout.simple_list_item_1, getStatusOptions()))
            findViewById<AutoCompleteTextView>(R.id.spinnerBillingStatus)
                .setAdapter(ArrayAdapter(this@JobsActivity,
                    android.R.layout.simple_list_item_1, getBillingOptions()))
            findViewById<AutoCompleteTextView>(R.id.spinnerTipoAplicacion)
                .setAdapter(ArrayAdapter(this@JobsActivity,
                    android.R.layout.simple_list_item_1, getTipoAplicacionOptions()))
        }
    }
}
