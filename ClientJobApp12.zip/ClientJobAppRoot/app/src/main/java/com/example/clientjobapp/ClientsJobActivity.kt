package com.example.clientjobapp

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.clientjobapp.data.AppDatabase
import com.example.clientjobapp.data.Job
import kotlinx.coroutines.launch
import java.util.Calendar

class ClientJobsActivity : AppCompatActivity() {

    private lateinit var jobAdapter: JobAdapter
    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_clients_job)

        val clientId = intent.getIntExtra("CLIENT_ID", -1)
        if (clientId == -1) {
            Toast.makeText(this, "Error al obtener el cliente", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        db = AppDatabase.getDatabase(this)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewClientJobs)
        recyclerView.layoutManager = LinearLayoutManager(this)

        jobAdapter = JobAdapter(
            context = this,
            onClick = { job ->
                val intent = Intent(this, JobDetailActivity::class.java)
                intent.putExtra("JOB_ID", job.id)
                startActivity(intent)
            },
            onLongClick = { job ->
                showJobOptionsDialog(job)
            }
        )

        recyclerView.adapter = jobAdapter
        loadJobsForClient(clientId)
    }

    private fun loadJobsForClient(clientId: Int) {
        lifecycleScope.launch {
            val jobs: List<Job> = db.jobDao().getJobsByClientId(clientId)
            jobAdapter.updateData(jobs)
        }
    }

    private fun showJobOptionsDialog(job: Job) {
        val options = arrayOf("Marcar como finalizado", "Facturación", "Editar", "Eliminar", "Recetas")
        AlertDialog.Builder(this)
            .setTitle("Selecciona una opción")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> markJobAsFinished(job)
                    1 -> updateBillingStatus(job)
                    2 -> editJob(job)
                    3 -> confirmDeleteJob(job)
                    4 -> {
                        val intent = android.content.Intent(this, RecetasActivity::class.java)
                        intent.putExtra("JOB_ID", job.id)
                        startActivity(intent)
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun loadJobs() {
        lifecycleScope.launch {
            val jobs = db.jobDao().getAll()
            jobAdapter.updateData(jobs)
        }
    }

    private fun markJobAsFinished(job: Job) {
        val cal = Calendar.getInstance()
        DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                cal.set(year, month, dayOfMonth, 0, 0, 0)
                val finishMillis = cal.timeInMillis
                lifecycleScope.launch {
                    db.jobDao().update(
                        job.copy(status = "Finalizado", endDate = finishMillis)
                    )
                    loadJobs()
                    Toast.makeText(
                        this@ClientJobsActivity,
                        "Trabajo finalizado el ${dayOfMonth}/${month + 1}/$year",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun updateBillingStatus(job: Job) {
        val billingOptions = arrayOf("Facturado", "No Facturado", "Pagado")
        AlertDialog.Builder(this)
            .setTitle("Selecciona el estado de facturación")
            .setItems(billingOptions) { _, idx ->
                val nuevo = billingOptions[idx]
                lifecycleScope.launch {
                    db.jobDao().update(job.copy(billingStatus = nuevo))
                    loadJobs()
                    Toast.makeText(this@ClientJobsActivity, "Facturación: $nuevo", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun editJob(job: Job) {
        JobDialog(this, db, job = job, onJobSaved = {
            lifecycleScope.launch {
                db.jobDao().update(it)
                loadJobs()
                Toast.makeText(this@ClientJobsActivity, "Trabajo actualizado", Toast.LENGTH_SHORT).show()
            }
        }).show()
    }

    private fun confirmDeleteJob(job: Job) {
        AlertDialog.Builder(this)
            .setTitle("Eliminar trabajo")
            .setMessage("¿Seguro de eliminar este trabajo?")
            .setPositiveButton("Eliminar") { _, _ -> deleteJob(job) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun deleteJob(job: Job) {
        lifecycleScope.launch {
            db.jobDao().delete(job)
            loadJobs()
            Toast.makeText(this@ClientJobsActivity, "Trabajo eliminado", Toast.LENGTH_SHORT).show()
        }
    }
}
