package com.example.clientjobapp

import com.example.clientjobapp.data.ClientRepository
import android.app.AlertDialog
import android.content.Context
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.Toast
import com.example.clientjobapp.data.Client
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import com.google.android.material.textfield.TextInputEditText

// ClientDialog.kt
class ClientDialog(
    private val context: Context,
    private val onClientSaved: (Client) -> Unit,  // Recibe el Client creado
    private val client: Client? = null
) {
    fun show() {
        val dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_client, null)
        val editTextName = dialogView.findViewById<EditText>(R.id.editTextClientName)
        val editTextLastName = dialogView.findViewById<EditText>(R.id.editTextClientLastName)
        val editTextCUIT = dialogView.findViewById<TextInputEditText>(R.id.editTextClientCUIT)

        client?.let {
            editTextName.setText(it.name)
            editTextLastName.setText(it.lastname)
            editTextCUIT.setText(it.cuit ?: "")
        }

        AlertDialog.Builder(context)
            .setView(dialogView)
            .setPositiveButton("Guardar") { _, _ ->
                val name = editTextName.text.toString()
                val lastName = editTextLastName.text.toString()
                val cuitInput = editTextCUIT.text.toString().trim()

                if (name.isBlank() || lastName.isBlank()) {
                    Toast.makeText(context, "Rellena todos los campos", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                if (cuitInput.isNotEmpty() && !Regex("^[0-9]{2}-[0-9]{8}-[0-9]{1}$").matches(cuitInput)) {
                    Toast.makeText(context, "CUIT en formato incorrecto. Debe ser xx-xxxxxxxx-x", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                val newClient = client?.copy(
                    name = name,
                    lastname = lastName,
                    phone = null,
                    email = null,
                    cuit = if (cuitInput.isEmpty()) null else cuitInput
                ) ?: Client(
                    name = name,
                    lastname = lastName,
                    phone = null,
                    email = null,
                    cuit = if (cuitInput.isEmpty()) null else cuitInput
                )

                onClientSaved(newClient)  // Pasa el nuevo cliente
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
