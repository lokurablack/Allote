package com.example.clientjobapp

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.clientjobapp.data.AppDatabase
import com.example.clientjobapp.data.Product
import kotlinx.coroutines.launch

class ProductosActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private lateinit var productosAdapter: ProductAdapter
    private lateinit var recyclerView: RecyclerView
    private val tiposList = mutableListOf("Herbicida", "Insecticida", "Fungicida", "Fertilizante", "Coadyuvante", "PGR", "Bactericida", "Defoliante", "Desecante", "Acaricida", "Nematicida", "Otros")
    private val formulacionesList = mutableListOf("Compatibilizador de mezcla", "Corrector/Secuestrante", "Antiespumante", "Adyuvante", "Polvos Mojables/WP", "Granulos Dispersables/WG", "Suspensiones Concentradas/SC", "Concentrados Solubles/EC", "Liquidos Solubles/SL", "Aceites", "Foliares", "Otros")

    private val productDetailLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        // Reload products when returning from ProductDetailActivity
        loadProducts()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_productos)

        loadProducts()

        db = AppDatabase.getDatabase(this)
        recyclerView = findViewById(R.id.recyclerViewProducts)
        recyclerView.layoutManager = LinearLayoutManager(this)
        productosAdapter = ProductAdapter(
            emptyList(),
            onItemClick = { product ->
                val intent = Intent(this, ProductDetailActivity::class.java).apply {
                    putExtra("PRODUCT_ID", product.id)
                }
                productDetailLauncher.launch(intent)
            },
            onItemLongClick = { product ->
                showEditDeleteDialog(product)
            }
        )
        recyclerView.adapter = productosAdapter

        findViewById<Button>(R.id.buttonAddProduct).setOnClickListener {
            showAddProductDialog()
        }

        val searchEditText = findViewById<EditText>(R.id.editTextSearch)
        searchEditText.addTextChangedListener {
            val query = it.toString().trim()
            lifecycleScope.launch {
                val productos = db.productDao().getAll().filter { p ->
                    p.nombreComercial.contains(query, ignoreCase = true) || p.principioActivo.contains(query, ignoreCase = true)
                }
                runOnUiThread {
                    productosAdapter.updateProductos(productos)
                }
            }
        }

        loadProducts()
    }

    private fun loadProducts() {
        val db = AppDatabase.getDatabase(this)
        lifecycleScope.launch {
            val productos = db.productDao().getAll()
            runOnUiThread {
                productosAdapter.updateProductos(productos)
            }
        }
    }

    private fun showAddProductDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_product, null)
        val nombreComercialEditText = dialogView.findViewById<EditText>(R.id.editTextNombreComercial)
        val principioActivoAutoComplete = dialogView.findViewById<AutoCompleteTextView>(R.id.autoCompletePrincipioActivo)
        val formulacionSpinner = dialogView.findViewById<Spinner>(R.id.spinnerFormulacion)

        lifecycleScope.launch {
            val principios = db.productDao().getAll().map { it.principioActivo }.distinct()
            runOnUiThread {
                val adapter = ArrayAdapter(this@ProductosActivity, android.R.layout.simple_dropdown_item_1line, principios)
                principioActivoAutoComplete.setAdapter(adapter)
            }
        }

        val formulacionAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, formulacionesList)
        formulacionAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        formulacionSpinner.adapter = formulacionAdapter

        val selectedTipos = BooleanArray(tiposList.size)
        val tiposSelectedList = mutableListOf<String>()

        val tipoButton = Button(this)
        tipoButton.text = "Seleccionar Tipo"
        tipoButton.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Seleccione Tipo(s)")
                .setMultiChoiceItems(tiposList.toTypedArray(), selectedTipos) { _, which, isChecked ->
                    selectedTipos[which] = isChecked
                }
                .setPositiveButton("Aceptar") { dialog, _ ->
                    tiposSelectedList.clear()
                    for (i in selectedTipos.indices) {
                        if (selectedTipos[i]) {
                            tiposSelectedList.add(tiposList[i])
                        }
                    }
                    if (tiposSelectedList.contains("Otros")) {
                        showInputDialog("Ingrese nuevo tipo") { inputTipo ->
                            if (inputTipo.isNotBlank()) {
                                tiposSelectedList.remove("Otros")
                                if (!tiposList.any { it.equals(inputTipo, ignoreCase = true) }) {
                                    tiposList.add(inputTipo)
                                }
                                tiposSelectedList.add(inputTipo)
                                tipoButton.text = tiposSelectedList.joinToString(", ")
                            }
                        }
                    } else {
                        tipoButton.text = tiposSelectedList.joinToString(", ")
                    }
                    dialog.dismiss()
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }

        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        container.addView(dialogView)
        container.addView(tipoButton)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Agregar producto")
            .setView(container)
            .setPositiveButton("Guardar", null)
            .setNegativeButton("Cancelar", null)
            .create()

        dialog.setOnShowListener {
            val button = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            button.setOnClickListener {
                val nombreComercial = nombreComercialEditText.text.toString().trim()
                val principioActivo = principioActivoAutoComplete.text.toString().trim()
                val formulacion = formulacionSpinner.selectedItem.toString()
                val tipo = tiposSelectedList.joinToString(", ")

                if (nombreComercial.isEmpty() || principioActivo.isEmpty() || tipo.isEmpty()) {
                    Toast.makeText(this, "Por favor complete los campos obligatorios", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                if (formulacion == "Otros") {
                    showInputDialog("Ingrese nueva formulación") { inputFormulacion ->
                        if (inputFormulacion.isNotBlank()) {
                            saveProduct(nombreComercial, principioActivo, tipo, inputFormulacion)
                            dialog.dismiss()
                        } else {
                            Toast.makeText(this, "Formulación no puede estar vacía", Toast.LENGTH_SHORT).show()
                        }
                    }
                    return@setOnClickListener
                }

                saveProduct(nombreComercial, principioActivo, tipo, formulacion)
                dialog.dismiss()
            }
        }

        dialog.show()
    }

    private fun saveProduct(nombreComercial: String, principioActivo: String, tipo: String, formulacion: String) {
        lifecycleScope.launch {
            val nuevoProducto = Product(0, nombreComercial, principioActivo, tipo, formulacion)
            db.productDao().insert(nuevoProducto)
            loadProducts()
        }
    }

    private fun showInputDialog(title: String, callback: (String) -> Unit) {
        val input = EditText(this)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(input)
            .setPositiveButton("Aceptar") { _, _ ->
                callback(input.text.toString().trim())
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showEditDeleteDialog(product: Product) {
        val options = arrayOf("Editar", "Eliminar")
        AlertDialog.Builder(this)
            .setTitle("Seleccione acción")
            .setItems(options) { dialog, which ->
                when (which) {
                    0 -> showAddProductDialog() // Se puede cambiar luego por showEditProductDialog(product)
                    1 -> {
                        lifecycleScope.launch {
                            db.productDao().delete(product)
                            loadProducts()
                        }
                    }
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        loadProducts() // Esto actualiza la lista cada vez que volvés a esta pantalla
    }

}
