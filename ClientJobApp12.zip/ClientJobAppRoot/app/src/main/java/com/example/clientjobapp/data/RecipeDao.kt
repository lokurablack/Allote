package com.example.clientjobapp.data

import androidx.room.*

@Dao
interface RecipeDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecipe(recipe: Recipe): Long

    @Update
    suspend fun updateRecipe(recipe: Recipe)

    @Delete
    suspend fun deleteRecipe(recipe: Recipe)

    @Query("SELECT * FROM recipes WHERE jobId = :jobId LIMIT 1")
    suspend fun getRecipeByJobId(jobId: Int): Recipe?

    // RecipeProduct methods

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecipeProduct(recipeProduct: RecipeProduct): Long

    @Update
    suspend fun updateRecipeProduct(recipeProduct: RecipeProduct)

    @Delete
    suspend fun deleteRecipeProduct(recipeProduct: RecipeProduct)

    @Query("SELECT * FROM recipe_products WHERE recipeId = :recipeId ORDER BY ordenMezclado ASC")
    suspend fun getRecipeProductsByRecipeId(recipeId: Int): List<RecipeProduct>

    @Query("DELETE FROM recipe_products WHERE recipeId = :recipeId")
    suspend fun deleteRecipeProductsByRecipeId(recipeId: Int)
}
