package com.example.clientjobapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import android.widget.Spinner
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.clientjobapp.data.AppDatabase
import com.example.clientjobapp.data.JobParametros
import kotlinx.coroutines.launch

class ParametrosActivity : AppCompatActivity() {
    private lateinit var db: AppDatabase
    private var jobId: Int = -1
    private var tipoAplicacion: String = ""

    private lateinit var textViewDosisLabel: TextView
    private lateinit var editTextDosis: EditText
    private lateinit var editTextTamanoGota: EditText
    private lateinit var editTextInterlineado: EditText
    private lateinit var editTextVelocidad: EditText
    private lateinit var editTextAltura: EditText
    private lateinit var buttonGuardar: Button
    private lateinit var spinnerDiscoUtilizado: Spinner
    private lateinit var textViewDiscoUtilizadoLabel: TextView

    private lateinit var textViewRevolucionesLabel: TextView
    private lateinit var editTextRevoluciones: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_parametros)

        db = AppDatabase.getDatabase(this)
        jobId = intent.getIntExtra("JOB_ID", -1)

        textViewDosisLabel = findViewById(R.id.textViewDosisLabel)
        editTextDosis = findViewById(R.id.editTextDosis)
        editTextTamanoGota = findViewById(R.id.editTextTamanoGota)
        editTextInterlineado = findViewById(R.id.editTextInterlineado)
        editTextVelocidad = findViewById(R.id.editTextVelocidad)
        editTextAltura = findViewById(R.id.editTextAltura)
        buttonGuardar = findViewById(R.id.buttonGuardarParametros)
        spinnerDiscoUtilizado = findViewById(R.id.spinnerDiscoUtilizado)
        textViewDiscoUtilizadoLabel = findViewById(R.id.textViewDiscoUtilizadoLabel)
        textViewRevolucionesLabel = findViewById(R.id.textViewRevolucionesLabel)
        editTextRevoluciones = findViewById(R.id.editTextRevoluciones)

        if (jobId == -1) {
            Toast.makeText(this, "ID de trabajo inválido", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        lifecycleScope.launch {
            val job = db.jobDao().getById(jobId)
            if (job == null) {
                Toast.makeText(this@ParametrosActivity, "Trabajo no encontrado", Toast.LENGTH_SHORT).show()
                finish()
                return@launch
            }
            tipoAplicacion = job.tipoAplicacion ?: ""

            // Set dosis label unit based on tipoAplicacion
            val dosisUnit = when (tipoAplicacion.lowercase()) {
                "aplicacion liquida" -> "l/ha"
                "aplicacion solida" -> "kg/ha"
                else -> "unidad"
            }
            textViewDosisLabel.text = "Dosis ($dosisUnit)"

            // Show or hide tamaño de gota input based on tipoAplicacion
            if (tipoAplicacion.lowercase() == "aplicacion liquida") {
                editTextTamanoGota.visibility = android.view.View.VISIBLE
                findViewById<TextView>(R.id.textViewTamanoGotaLabel).visibility = android.view.View.VISIBLE
            } else {
                editTextTamanoGota.visibility = android.view.View.GONE
                findViewById<TextView>(R.id.textViewTamanoGotaLabel).visibility = android.view.View.GONE
            }

            // Show or hide revoluciones input based on tipoAplicacion
            if (tipoAplicacion.lowercase() == "aplicacion solida") {
                editTextRevoluciones.visibility = android.view.View.VISIBLE
                textViewRevolucionesLabel.visibility = android.view.View.VISIBLE
            } else {
                editTextRevoluciones.visibility = android.view.View.GONE
                textViewRevolucionesLabel.visibility = android.view.View.GONE
            }

            // Mostrar u ocultar spinner de disco según el tipo de aplicación
            val discoOptions = listOf("Disco grande", "Disco chico")
            val adapter = ArrayAdapter(
                this@ParametrosActivity,
                android.R.layout.simple_spinner_item,
                discoOptions
            )
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinnerDiscoUtilizado.adapter = adapter

            if (tipoAplicacion.lowercase() == "aplicacion solida") {
                spinnerDiscoUtilizado.visibility = android.view.View.VISIBLE
                textViewDiscoUtilizadoLabel.visibility = android.view.View.VISIBLE
            } else {
                spinnerDiscoUtilizado.visibility = android.view.View.GONE
                textViewDiscoUtilizadoLabel.visibility = android.view.View.GONE
            }

            // Load existing parametros if any
            val parametros = db.jobParametrosDao().getByJobId(jobId)
            parametros?.let {
                editTextDosis.setText(it.dosis?.toString() ?: "")
                editTextTamanoGota.setText(it.tamanoGota?.toString() ?: "")
                editTextInterlineado.setText(it.interlineado?.toString() ?: "")
                editTextVelocidad.setText(it.velocidad?.toString() ?: "")
                editTextAltura.setText(it.altura?.toString() ?: "")
                editTextRevoluciones.setText(it.revoluciones?.toString() ?: "")

                // Set spinner selection for discoUtilizado
                val discoIndex = discoOptions.indexOf(it.discoUtilizado)
                if (discoIndex >= 0) {
                    spinnerDiscoUtilizado.setSelection(discoIndex)
                }
            }

            buttonGuardar.setOnClickListener {
                val dosis = editTextDosis.text.toString().toDoubleOrNull()
                val tamanoGota = editTextTamanoGota.text.toString().toDoubleOrNull()
                val interlineado = editTextInterlineado.text.toString().toDoubleOrNull()
                val velocidad = editTextVelocidad.text.toString().toDoubleOrNull()
                val altura = editTextAltura.text.toString().toDoubleOrNull()
                val revoluciones = editTextRevoluciones.text.toString().toDoubleOrNull()
                val discoUtilizado = if (tipoAplicacion.lowercase() == "aplicacion solida") {
                    spinnerDiscoUtilizado.selectedItem as? String
                } else {
                    null
                }

                lifecycleScope.launch {
                    val existingParametros = db.jobParametrosDao().getByJobId(jobId)
                    val parametrosToSave = JobParametros(
                        id = existingParametros?.id ?: 0,
                        jobId = jobId,
                        dosis = dosis,
                        tamanoGota = tamanoGota,
                        interlineado = interlineado,
                        velocidad = velocidad,
                        altura = altura,
                        discoUtilizado = discoUtilizado,
                        revoluciones = revoluciones
                    )
                    db.jobParametrosDao().insert(parametrosToSave)
                    runOnUiThread {
                        Toast.makeText(this@ParametrosActivity, "Parámetros guardados", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                }
            }
        }

        buttonGuardar.setOnClickListener {
            val dosis = editTextDosis.text.toString().toDoubleOrNull()
            val tamanoGota = editTextTamanoGota.text.toString().toDoubleOrNull()
            val interlineado = editTextInterlineado.text.toString().toDoubleOrNull()
            val velocidad = editTextVelocidad.text.toString().toDoubleOrNull()
            val altura = editTextAltura.text.toString().toDoubleOrNull()
            val discoUtilizado = if (tipoAplicacion.lowercase() == "aplicacion solida") {
                spinnerDiscoUtilizado.selectedItem as? String
            } else {
                null
            }

            lifecycleScope.launch {
                val existingParametros = db.jobParametrosDao().getByJobId(jobId)
                val parametrosToSave = JobParametros(
                    id = existingParametros?.id ?: 0,
                    jobId = jobId,
                    dosis = dosis,
                    tamanoGota = tamanoGota,
                    interlineado = interlineado,
                    velocidad = velocidad,
                    altura = altura,
                    discoUtilizado = discoUtilizado
                )
                db.jobParametrosDao().insert(parametrosToSave)
                runOnUiThread {
                    Toast.makeText(this@ParametrosActivity, "Parámetros guardados", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        }
    }
}
