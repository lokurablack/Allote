package com.example.clientjobapp

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions

class MapLocationPickerActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var map: GoogleMap
    private var selectedMarker: Marker? = null
    private var jobId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map_location_picker)

        jobId = intent.getIntExtra("JOB_ID", -1)

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        val btnConfirm = findViewById<Button>(R.id.buttonConfirmLocation)
        btnConfirm.setOnClickListener {
            if (selectedMarker != null) {
                val lat = selectedMarker!!.position.latitude
                val lng = selectedMarker!!.position.longitude

                val resultIntent = Intent()
                resultIntent.putExtra("JOB_ID", jobId)
                resultIntent.putExtra("LATITUDE", lat)
                resultIntent.putExtra("LONGITUDE", lng)
                setResult(Activity.RESULT_OK, resultIntent)
                finish()
            } else {
                Toast.makeText(this, "Seleccioná una ubicación", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap

        map.mapType = GoogleMap.MAP_TYPE_SATELLITE

        // Opcional: poner posición inicial en un punto default o el trabajo si tiene ubicación previa
        val defaultLocation = LatLng(-32.364954, -62.312972)
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, 10f))

        map.setOnMapClickListener { latLng ->
            selectedMarker?.remove()
            selectedMarker = map.addMarker(MarkerOptions().position(latLng).title("Ubicación seleccionada"))
        }
    }
}
