package com.example.clientjobapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.clientjobapp.data.Client

class ClientAdapter(
    private val onClick: (Client) -> Unit,
    private val onLongClick: ((Client) -> Boolean)? = null
) : ListAdapter<Client, ClientAdapter.ClientViewHolder>(ClientDiffCallback()) {

    inner class ClientViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val textViewName: TextView = itemView.findViewById(R.id.textViewClientName)
        private val textViewCUIT: TextView = itemView.findViewById(R.id.textViewClientCUIT)

        fun bind(client: Client) {
            textViewName.text = "${client.name} ${client.lastname}"

            if (client.cuit != null && client.cuit.isNotEmpty()) {
                textViewCUIT.text = client.cuit
                textViewCUIT.visibility = View.VISIBLE
            } else {
                textViewCUIT.visibility = View.GONE
            }

            itemView.setOnClickListener {
                if (adapterPosition != RecyclerView.NO_POSITION) {
                    onClick(getItem(adapterPosition))
                }
            }

            onLongClick?.let { callback ->
                itemView.setOnLongClickListener {
                    if (adapterPosition != RecyclerView.NO_POSITION) {
                        callback(getItem(adapterPosition))
                    } else {
                        false
                    }
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ClientViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_client, parent, false)
        return ClientViewHolder(view)
    }

    override fun onBindViewHolder(holder: ClientViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    // Función opcional para mantener compatibilidad
    fun updateData(newData: List<Client>) {
        submitList(newData)
    }
}

/*
class ClientDiffCallback : DiffUtil.ItemCallback<Client>() {
    override fun areItemsTheSame(oldItem: Client, newItem: Client): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: Client, newItem: Client): Boolean {
        return oldItem == newItem
    }
 */
