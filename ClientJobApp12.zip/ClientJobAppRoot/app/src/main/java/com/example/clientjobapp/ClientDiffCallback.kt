// ClientDiffCallback.kt
package com.example.clientjobapp

import androidx.recyclerview.widget.DiffUtil
import com.example.clientjobapp.data.Client

class ClientDiffCallback : DiffUtil.ItemCallback<Client>() {
    // Compara si los items representan el mismo objeto (usando ID)
    override fun areItemsTheSame(oldItem: Client, newItem: Client): Boolean {
        return oldItem.id == newItem.id
    }

    // Compara si el contenido de los items es igual
    override fun areContentsTheSame(oldItem: Client, newItem: Client): Boolean {
        return oldItem == newItem
    }
}