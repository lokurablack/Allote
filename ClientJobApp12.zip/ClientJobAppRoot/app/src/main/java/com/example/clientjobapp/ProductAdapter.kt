package com.example.clientjobapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.clientjobapp.data.Product

class ProductAdapter(
    private var products: List<Product>,
    private val onItemClick: (Product) -> Unit,
    private val onItemLongClick: (Product) -> Unit
) : RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {

    private val bandaColorMap = mapOf(
        "la" to 0x8B0000.toInt(), // Dark Red
        "lb" to 0x8B0000.toInt(), // Dark Red
        "II" to 0xB8860B.toInt(), // Dark Goldenrod (Dark Yellow)
        "III" to 0x00008B.toInt(), // Dark Blue
        "IV" to 0x006400.toInt()  // Dark Green
    )

    inner class ProductViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nombreComercialTextView: TextView = itemView.findViewById(R.id.textViewNombreComercial)
        val principioActivoTextView: TextView = itemView.findViewById(R.id.textViewPrincipioActivo)
        val tipoTextView: TextView = itemView.findViewById(R.id.textViewTipo)
        val formulacionTextView: TextView = itemView.findViewById(R.id.textViewFormulacion)
        val bandaColorView: View = itemView.findViewById(R.id.viewBandaColor)


        init {
            itemView.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onItemClick(products[position])
                }
            }
            itemView.setOnLongClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onItemLongClick(products[position])
                    true
                } else {
                    false
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_product, parent, false)
        return ProductViewHolder(view)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val product = products[position]
        holder.nombreComercialTextView.text = product.nombreComercial
        val colorKey = product.bandaToxicologica?.trim()?.uppercase() ?: ""
        val color = when (colorKey) {
            "LA", "IA", "LB", "IB" -> 0xFFFF0000.toInt() // Rojo
            "II" -> 0xFFFFFF00.toInt()                  // Amarillo
            "III" -> 0xFF0000FF.toInt()                 // Azul
            "IV" -> 0xFF00FF00.toInt()                  // Verde
            else -> 0xFFB0B0B0.toInt()                  // Gris claro
        }
        android.util.Log.d("ProductAdapter", "bandaToxicologica='$colorKey', color=$color, productId=${product.id}")
        holder.bandaColorView.setBackgroundColor(color)
        holder.principioActivoTextView.text = "Principio Activo: ${product.principioActivo}"
        holder.tipoTextView.text = "Tipo: ${product.tipo}"
        holder.formulacionTextView.text = "Formulación: ${product.formulacion}"
    }

    override fun getItemCount(): Int = products.size

    fun updateProductos(newList: List<Product>) {
        products = newList
        notifyDataSetChanged()
    }
}
