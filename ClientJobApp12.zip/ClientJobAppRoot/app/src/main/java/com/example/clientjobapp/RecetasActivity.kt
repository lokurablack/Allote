package com.example.clientjobapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.clientjobapp.data.*
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.launch

class RecetasActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private var jobId: Int = -1

    private lateinit var etHectareas: TextInputEditText
    private lateinit var etCaudal: TextInputEditText
    private lateinit var btnCalcular: Button
    private lateinit var rvProductos: RecyclerView
    private lateinit var fabAgregarProducto: FloatingActionButton
    private lateinit var tvResumen: TextView

    private var receta: Recipe? = null
    private val productosReceta = mutableListOf<ProductoRecetaItem>()

    private lateinit var adapter: ProductoRecetaAdapter

    private val formulacionOrdenMap = mapOf(
        "Agua" to 1,
        "Compatibilizador de mezcla" to 2,
        "Corrector/Secuestrante" to 3,
        "Antiespumante" to 4,
        "Adyuvante" to 5,
        "Polvos Mojables/WP" to 6,
        "Granulos Dispersables/WG" to 7,
        "Suspensiones Concentradas/SC" to 8,
        "Concentrados Solubles/SL" to 9,
        "Liquidos Solubles/SL" to 10,
        "Aceites" to 11,
        "Foliares" to 12
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recetas)

        db = AppDatabase.getDatabase(this)
        jobId = intent.getIntExtra("JOB_ID", -1)
        if (jobId == -1) {
            Toast.makeText(this, "Error: Trabajo no especificado", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        etHectareas = findViewById(R.id.etHectareas)
        etCaudal = findViewById(R.id.etCaudal)
        btnCalcular = findViewById(R.id.btnCalcular)
        rvProductos = findViewById(R.id.rvProductosReceta)
        fabAgregarProducto = findViewById(R.id.fabAgregarProducto)
        tvResumen = findViewById(R.id.tvResumen)

        adapter = ProductoRecetaAdapter(productosReceta)
        rvProductos.layoutManager = LinearLayoutManager(this)
        rvProductos.adapter = adapter

        fabAgregarProducto.setOnClickListener {
            mostrarDialogoAgregarProducto()
        }

        btnCalcular.setOnClickListener {
            calcularReceta()
        }

        cargarReceta()
    }

    private fun cargarReceta() {
        lifecycleScope.launch {
            val job = db.jobDao().getById(jobId)
            if (job != null && receta == null) {
                etHectareas.setText(job.surface.toString())
            }

            receta = db.recipeDao().getRecipeByJobId(jobId)
            receta?.let {
                etHectareas.setText(it.hectareas.toString())
                etCaudal.setText(it.caudal.toString())

                val productos = db.recipeDao().getRecipeProductsByRecipeId(it.id)
                productosReceta.clear()
                productosReceta.addAll(productos.map { rp ->
                    ProductoRecetaItem(
                        rp.id,
                        rp.productId,
                        "", // nombre se asigna después
                        rp.dosis,
                        rp.cantidadTotal,
                        rp.ordenMezclado,
                        null
                    )
                })

                cargarNombresProductos()
                calcularReceta()
            }
        }
    }

    private suspend fun cargarNombresProductos() {
        val allProducts = db.productDao().getAll()
        productosReceta.forEachIndexed { index, item ->
            val product = allProducts.find { it.id == item.productId }
            if (product != null) {
                productosReceta[index] = item.copy(
                    nombreComercial = product.nombreComercial,
                    bandaToxicologica = product.bandaToxicologica
                )
            }
        }
        adapter.notifyDataSetChanged()
    }

    private fun calcularReceta() {
        val hectareas = etHectareas.text.toString().toDoubleOrNull()
        val caudal = etCaudal.text.toString().toDoubleOrNull()

        if (hectareas == null || hectareas <= 0) {
            Toast.makeText(this, "Ingrese un valor válido para hectáreas", Toast.LENGTH_SHORT).show()
            return
        }
        if (caudal == null || caudal <= 0) {
            Toast.makeText(this, "Ingrese un valor válido para caudal", Toast.LENGTH_SHORT).show()
            return
        }

        val sharedPrefs = androidx.preference.PreferenceManager.getDefaultSharedPreferences(this)
        val tankCapacityStr = sharedPrefs.getString("tank_capacity", null)
        val tankCapacity = tankCapacityStr?.toDoubleOrNull()

        var totalProductos = 0.0
        productosReceta.forEachIndexed { index, item ->
            val cantidadTotal: Double = when (item.ordenMezclado) {
                6, 7 -> (item.dosis * hectareas) / 1000
                else -> item.dosis * hectareas
            }
            productosReceta[index] = item.copy(cantidadTotal = cantidadTotal)
            totalProductos += cantidadTotal
        }

        val totalCaldo = caudal * hectareas
        val agua = totalCaldo - totalProductos

        productosReceta.sortBy { it.ordenMezclado }
        adapter.notifyDataSetChanged()

        val resumenBuilder = StringBuilder()
        resumenBuilder.append("🔍 RESUMEN DE LA RECETA\n")
        resumenBuilder.append("Total Caldo: %.2f L\n".format(totalCaldo))
        resumenBuilder.append("Total Agua: %.2f L\n".format(agua))
        resumenBuilder.append("Total Productos: %.2f L\n".format(totalProductos))

        if (tankCapacity == null || tankCapacity <= 0 || totalCaldo <= tankCapacity) {
            resumenBuilder.append("🧪 Carga única\n")
            resumenBuilder.append("💧 Agua: %.2f L\n".format(agua))
            productosReceta.forEach {
                val unidad = if (it.ordenMezclado == 6 || it.ordenMezclado == 7) "kg" else "litros"
                resumenBuilder.append("• %s: %.2f %s\n".format(it.nombreComercial.ifBlank { "-" }, it.cantidadTotal, unidad))
            }
        } else {
            var remainingCaldo = totalCaldo
            var cargaNum = 1
            while (remainingCaldo > 0) {
                val cargaVolumen = if (remainingCaldo > tankCapacity) tankCapacity else remainingCaldo
                val proporcionCarga = cargaVolumen / totalCaldo
                resumenBuilder.append("\n🧪 Carga %d (%.2f L)\n".format(cargaNum, cargaVolumen))

                var sumaProductos = 0.0
                productosReceta.forEach {
                    val dosisCarga = it.dosis * hectareas * proporcionCarga
                    val dosisFinal = if (it.ordenMezclado == 6 || it.ordenMezclado == 7) dosisCarga / 1000 else dosisCarga
                    sumaProductos += dosisFinal
                }

                val aguaCarga = cargaVolumen - sumaProductos
                resumenBuilder.append("💧 Agua: %.2f L\n".format(aguaCarga))

                productosReceta.forEach {
                    val dosisCarga = it.dosis * hectareas * proporcionCarga
                    val dosisFinal = if (it.ordenMezclado == 6 || it.ordenMezclado == 7) dosisCarga / 1000 else dosisCarga
                    val unidad = if (it.ordenMezclado == 6 || it.ordenMezclado == 7) "kg" else "litros"
                    resumenBuilder.append("• %s: %.2f %s\n".format(it.nombreComercial.ifBlank { "-" }, dosisFinal, unidad))
                }

                remainingCaldo -= cargaVolumen
                cargaNum++
            }
        }

        tvResumen.text = resumenBuilder.toString()

        lifecycleScope.launch {
            if (receta == null) {
                val nuevaReceta = Recipe(
                    jobId = jobId,
                    hectareas = hectareas,
                    caudal = caudal,
                    totalCaldo = totalCaldo,
                    fechaCreacion = System.currentTimeMillis()
                )
                val idReceta = db.recipeDao().insertRecipe(nuevaReceta)
                receta = nuevaReceta.copy(id = idReceta.toInt())
            } else {
                receta = receta!!.copy(
                    hectareas = hectareas,
                    caudal = caudal,
                    totalCaldo = totalCaldo,
                    fechaCreacion = System.currentTimeMillis()
                )
                db.recipeDao().updateRecipe(receta!!)
                db.recipeDao().deleteRecipeProductsByRecipeId(receta!!.id)
            }

            receta?.let { rec ->
                productosReceta.forEach { item ->
                    val rp = RecipeProduct(
                        recipeId = rec.id,
                        productId = item.productId,
                        dosis = item.dosis,
                        cantidadTotal = item.cantidadTotal,
                        ordenMezclado = item.ordenMezclado
                    )
                    db.recipeDao().insertRecipeProduct(rp)
                }
            }
        }
    }

    private fun mostrarDialogoAgregarProducto() {
        val inflater = LayoutInflater.from(this)
        val dialogView = inflater.inflate(R.layout.dialog_add_producto_receta, null)

        val etBusqueda = dialogView.findViewById<AutoCompleteTextView>(R.id.etBusquedaProducto)
        val tilDosis = dialogView.findViewById<TextInputLayout>(R.id.tilDosis)
        val etDosis = dialogView.findViewById<TextInputEditText>(R.id.etDosis)

        lifecycleScope.launch {
            val productos = db.productDao().getAll()
            val nombres = productos.map { it.nombreComercial } + productos.map { it.principioActivo }
            val searchAdapter = ArrayAdapter(this@RecetasActivity, android.R.layout.simple_dropdown_item_1line, nombres.distinct())
            etBusqueda.setAdapter(searchAdapter)
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("Agregar Producto")
            .setView(dialogView)
            .setPositiveButton("Agregar") { _, _ ->
                val busqueda = etBusqueda.text.toString()
                val dosisStr = etDosis.text.toString()
                if (busqueda.isBlank() || dosisStr.isBlank()) {
                    Toast.makeText(this, "Debe ingresar producto y dosis", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val dosis = dosisStr.toDoubleOrNull()
                if (dosis == null || dosis <= 0) {
                    Toast.makeText(this, "Dosis inválida", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                lifecycleScope.launch {
                    val producto = db.productDao().getAll().find {
                        it.nombreComercial.equals(busqueda, true) || it.principioActivo.equals(busqueda, true)
                    }

                    if (producto == null) {
                        Toast.makeText(this@RecetasActivity, "Producto no encontrado", Toast.LENGTH_SHORT).show()
                        return@launch
                    }

                    val orden = when (producto.formulacion) {
                        "Concentrados Solubles/SL" -> 9
                        else -> formulacionOrdenMap[producto.formulacion] ?: 99
                    }
                    val item = ProductoRecetaItem(
                        id = 0,
                        productId = producto.id,
                        nombreComercial = producto.nombreComercial,
                        dosis = dosis,
                        cantidadTotal = 0.0,
                        ordenMezclado = orden
                    )
                    productosReceta.add(item)
                    adapter.notifyDataSetChanged()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
        }
    }

    data class ProductoRecetaItem(
        val id: Int,
        val productId: Int,
        val nombreComercial: String,
        val dosis: Double,
        val cantidadTotal: Double,
        val ordenMezclado: Int,
        val bandaToxicologica: String? = null
    )

class ProductoRecetaAdapter(private val items: List<ProductoRecetaItem>) :
    RecyclerView.Adapter<ProductoRecetaAdapter.ViewHolder>() {

    private val bandaColorMap = mapOf(
        "la" to 0xFFFF0000.toInt(),
        "lb" to 0xFFFF0000.toInt(),
        "ii" to 0xFFFFC107.toInt(),
        "iii" to 0xFF00008B.toInt(),
        "iv" to 0xFF388E3C.toInt()
    )

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvNombre: TextView = view.findViewById(R.id.tvNombreProducto)
        val tvDosis: TextView = view.findViewById(R.id.tvDosisProducto)
        val tvCantidadTotal: TextView = view.findViewById(R.id.tvCantidadTotalProducto)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_producto_receta, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        val unidad = if (item.ordenMezclado == 6 || item.ordenMezclado == 7) "kg" else "litros"
        holder.tvNombre.text = item.nombreComercial

        val bandaKey = item.bandaToxicologica?.trim()?.lowercase() ?: ""
        val color = bandaColorMap[bandaKey] ?: 0xFF000000.toInt() // Negro por defecto
        holder.tvNombre.setTextColor(color)

        holder.tvDosis.text = "Dosis: %.2f".format(item.dosis)
        holder.tvCantidadTotal.text = "Cantidad total: %.2f %s".format(item.cantidadTotal, unidad)
    }

    override fun getItemCount(): Int = items.size
}

