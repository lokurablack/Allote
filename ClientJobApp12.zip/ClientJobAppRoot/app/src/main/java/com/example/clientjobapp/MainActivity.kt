package com.example.clientjobapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.clientjobapp.data.AppDatabase
import com.example.clientjobapp.databinding.ActivityMainBinding

import android.view.Menu
import android.view.MenuItem
import com.example.clientjobapp.R

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val db by lazy { AppDatabase.getDatabase(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnGoToClients.setOnClickListener {
            startActivity(Intent(this, ClientsActivity::class.java))
        }

        binding.btnGoToJobs.setOnClickListener {
            startActivity(Intent(this, JobsActivity::class.java))
        }

        binding.btnGoToAdministracion.setOnClickListener {
            startActivity(Intent(this, AdministracionGeneralActivity::class.java))
        }

        binding.btnGoToProductos.setOnClickListener {
            startActivity(Intent(this, ProductosActivity::class.java))
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when(item.itemId) {
            R.id.action_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
