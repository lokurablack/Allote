package com.example.clientjobapp

import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.FileDescriptor

class PdfViewerActivity : AppCompatActivity() {

    private lateinit var pdfRenderer: PdfRenderer
    private var currentPage: PdfRenderer.Page? = null
    private var fileDescriptor: ParcelFileDescriptor? = null

    private lateinit var imageView: ImageView
    private lateinit var btnAnterior: Button
    private lateinit var btnSiguiente: Button

    private var currentPageIndex = 0
    private var totalPages = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pdf_viewer)

        imageView = findViewById(R.id.imageViewPdf)
        btnAnterior = findViewById(R.id.btnAnterior)
        btnSiguiente = findViewById(R.id.btnSiguiente)

        val uriString = intent.getStringExtra("pdf_uri")

        if (uriString != null) {
            val uri = Uri.parse(uriString)
            abrirPdfDesdeUri(uri)
        } else {
            Toast.makeText(this, "No se proporcionó la URI del PDF", Toast.LENGTH_SHORT).show()
            finish()
        }

        btnAnterior.setOnClickListener {
            if (currentPageIndex > 0) {
                currentPageIndex--
                mostrarPagina(currentPageIndex)
            }
        }

        btnSiguiente.setOnClickListener {
            if (currentPageIndex < totalPages - 1) {
                currentPageIndex++
                mostrarPagina(currentPageIndex)
            }
        }
    }

    private fun abrirPdfDesdeUri(uri: Uri) {
        try {
            val pfd = contentResolver.openFileDescriptor(uri, "r")
            if (pfd != null) {
                fileDescriptor = pfd
                pdfRenderer = PdfRenderer(pfd)
                totalPages = pdfRenderer.pageCount
                mostrarPagina(currentPageIndex)
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Error al abrir el PDF", Toast.LENGTH_LONG).show()
            e.printStackTrace()
            finish()
        }
    }

    private fun mostrarPagina(index: Int) {
        currentPage?.close()
        currentPage = pdfRenderer.openPage(index)

        val bitmap = android.graphics.Bitmap.createBitmap(
            currentPage!!.width,
            currentPage!!.height,
            android.graphics.Bitmap.Config.ARGB_8888
        )

        currentPage!!.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        imageView.setImageBitmap(bitmap)
    }

    override fun onDestroy() {
        super.onDestroy()
        currentPage?.close()
        pdfRenderer.close()
        fileDescriptor?.close()
    }
}
