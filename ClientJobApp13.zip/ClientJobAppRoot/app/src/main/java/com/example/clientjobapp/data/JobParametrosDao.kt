package com.example.clientjobapp.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface JobParametrosDao {
    @Query("SELECT * FROM job_parametros WHERE jobId = :jobId LIMIT 1")
    suspend fun getByJobId(jobId: Int): JobParametros?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(parametros: JobParametros)

    @Update
    suspend fun update(parametros: JobParametros)
}
