// ViewModelFactory.kt
package com.example.clientjobapp

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.clientjobapp.MainViewModel
import com.example.clientjobapp.data.AppDatabase
import com.example.clientjobapp.data.ClientRepository
import com.example.clientjobapp.data.JobRepository

class ViewModelFactory(
    private val clientRepository: ClientRepository,
    private val jobRepository: JobRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            return MainViewModel(clientRepository, jobRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}