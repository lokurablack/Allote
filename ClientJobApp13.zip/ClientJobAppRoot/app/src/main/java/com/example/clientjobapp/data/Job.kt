package com.example.clientjobapp.data

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(tableName = "jobs")
data class Job(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val clientId: Int,
    val clientName: String,
    val description: String,
    val date: String,                      // Fecha de creación legible (yyyy-MM-dd)
    val createdAt: Long = System.currentTimeMillis(), // Fecha de creación en millis
    val status: String,
    val startDate: Long = 0L,
    val endDate: Long = 0L,
    val surface: Double,
    val valuePerHectare: Double = 0.0,
    val billingStatus: String = "No Facturado",
    val notes: String? = null,
    val tipoAplicacion: String? = null,
    val latitude: Double?,
    val longitude: Double?
) : Parcelable
