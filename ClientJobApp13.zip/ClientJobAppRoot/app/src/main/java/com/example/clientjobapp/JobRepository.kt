package com.example.clientjobapp.data

import androidx.lifecycle.LiveData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class JobRepository(private val jobDao: JobDao) {
    suspend fun getAllJobs(): List<Job> = withContext(Dispatchers.IO) {
        jobDao.getAll()
    }

    // Añade otras funciones relacionadas con jobs según necesites
}