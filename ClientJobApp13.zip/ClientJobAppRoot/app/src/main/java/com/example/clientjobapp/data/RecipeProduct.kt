package com.example.clientjobapp.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recipe_products")
data class RecipeProduct(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val recipeId: Int,
    val productId: Int,
    val dosis: Double,
    val cantidadTotal: Double,
    val ordenMezclado: Int
)
