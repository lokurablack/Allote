package com.example.clientjobapp.data

import androidx.room.*

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY nombreComercial ASC")
    suspend fun getAll(): List<Product>

    @Query("SELECT * FROM products WHERE nombreComercial LIKE :searchQuery ORDER BY nombreComercial ASC")
    suspend fun searchByName(searchQuery: String): List<Product>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(product: Product): Long

    @Update
    suspend fun update(product: Product)

    @Delete
    suspend fun delete(product: Product)
}
