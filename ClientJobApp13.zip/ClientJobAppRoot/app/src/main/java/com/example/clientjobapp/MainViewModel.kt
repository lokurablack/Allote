package com.example.clientjobapp

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.clientjobapp.data.Client
import com.example.clientjobapp.data.ClientRepository
import com.example.clientjobapp.data.Job
import com.example.clientjobapp.data.JobRepository
import kotlinx.coroutines.launch

class MainViewModel(
    private val clientRepository: ClientRepository,
    private val jobRepository: JobRepository  // Añade esto
) : ViewModel() {

    fun loadClients(onSuccess: (List<Client>) -> Unit) {
        viewModelScope.launch {
            val clients = clientRepository.getAllClients()
            onSuccess(clients)
        }
    }

    fun loadJobs(onSuccess: (List<Job>) -> Unit) {
        viewModelScope.launch {
            val jobs = jobRepository.getAllJobs()  // Usa el repository en lugar de db
            onSuccess(jobs)
        }
    }
}