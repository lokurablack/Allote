package com.example.clientjobapp.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [Client::class, Job::class, AdministracionTrabajo::class, JobParametros::class, Product::class, Recipe::class, RecipeProduct::class], version = 8)
abstract class AppDatabase : RoomDatabase() {
    abstract fun clientDao(): ClientDao
    abstract fun jobDao(): JobDao
    abstract fun administracionDao(): AdministracionDao
    abstract fun jobParametrosDao(): JobParametrosDao
    abstract fun productDao(): ProductDao
    abstract fun recipeDao(): RecipeDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // Añade columnas startDate y endDate a la tabla 'jobs'
                database.execSQL("ALTER TABLE jobs ADD COLUMN startDate INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE jobs ADD COLUMN endDate INTEGER NOT NULL DEFAULT 0")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // En caso de que billingStatus no existiera previamente
                database.execSQL("ALTER TABLE jobs ADD COLUMN billingStatus TEXT NOT NULL DEFAULT 'No Facturado'")
            }
        }

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE jobs ADD COLUMN valuePerHectare REAL NOT NULL DEFAULT 0")
            }
        }

        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    "CREATE TABLE IF NOT EXISTS job_parametros (" +
                            "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                            "jobId INTEGER NOT NULL, " +
                            "dosis REAL, " +
                            "tamanoGota REAL, " +
                            "interlineado REAL, " +
                            "velocidad REAL, " +
                            "altura REAL, " +
                            "discoUtilizado TEXT)"
                )
            }
        }

        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE job_parametros ADD COLUMN revoluciones REAL")
            }
        }

        private val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    "CREATE TABLE IF NOT EXISTS products (" +
                            "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                            "nombreComercial TEXT NOT NULL, " +
                            "principioActivo TEXT NOT NULL, " +
                            "tipo TEXT NOT NULL, " +
                            "formulacion TEXT NOT NULL)"
                )
            }
        }

        private val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    "CREATE TABLE IF NOT EXISTS recipes (" +
                            "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                            "jobId INTEGER NOT NULL, " +
                            "hectareas REAL NOT NULL, " +
                            "caudal REAL NOT NULL, " +
                            "totalCaldo REAL NOT NULL, " +
                            "fechaCreacion INTEGER NOT NULL)"
                )
                database.execSQL(
                    "CREATE TABLE IF NOT EXISTS recipe_products (" +
                            "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                            "recipeId INTEGER NOT NULL, " +
                            "productId INTEGER NOT NULL, " +
                            "dosis REAL NOT NULL, " +
                            "cantidadTotal REAL NOT NULL, " +
                            "ordenMezclado INTEGER NOT NULL)"
                )
            }
        }

        private val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE products ADD COLUMN numeroRegistroSenasa TEXT")
                database.execSQL("ALTER TABLE products ADD COLUMN concentracion TEXT")
                database.execSQL("ALTER TABLE products ADD COLUMN fabricante TEXT")
                database.execSQL("ALTER TABLE products ADD COLUMN bandaToxicologica TEXT")
                database.execSQL("ALTER TABLE products ADD COLUMN modoAccion TEXT")
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "client_job_database"
                )
                    .fallbackToDestructiveMigration()
                    //.addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
