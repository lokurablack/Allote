package com.example.clientjobapp

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.clientjobapp.data.AppDatabase
import com.example.clientjobapp.data.Job
import kotlinx.coroutines.launch

class JobDetailActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private var jobId: Int = -1  // Almacena el ID del trabajo
    private var currentJob: Job? = null

    companion object {
        private const val REQUEST_CODE_PICK_LOCATION = 1001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_job_detail)

        db = AppDatabase.getDatabase(this)

        val btnAdministracion = findViewById<Button>(R.id.buttonAdministracion)
        val btnParametrosUtilizados = findViewById<Button>(R.id.buttonParametrosUtilizados)
        val btnPickLocation = findViewById<Button>(R.id.buttonPickLocation)
        val btnVerUbicacion = findViewById<Button>(R.id.buttonVerUbicacion)
        val btnRecetas = findViewById<Button>(R.id.buttonRecetas)
        val btnImagenes = findViewById<Button>(R.id.buttonImagenes)

        btnRecetas.setOnClickListener {
            val intent = Intent(this, RecetasActivity::class.java)
            intent.putExtra("JOB_ID", jobId)
            startActivity(intent)
        }

        // Obtener extras
        val jobFromIntent = intent.getParcelableExtra<Job>("JOB_EXTRA")
        jobId = intent.getIntExtra("JOB_ID", -1)

        btnAdministracion.setOnClickListener {
            val intent = Intent(this, AdministracionActivity::class.java)
            intent.putExtra("JOB_ID", jobId)
            startActivity(intent)
        }

        btnParametrosUtilizados.setOnClickListener {
            val intent = Intent(this, ParametrosActivity::class.java)
            intent.putExtra("JOB_ID", jobId)
            startActivity(intent)
        }

        btnPickLocation.setOnClickListener {
            // Abrir la actividad para seleccionar ubicación
            val intent = Intent(this, MapLocationPickerActivity::class.java)

            // Pasar ubicación actual para centrar el mapa
            val lat = currentJob?.latitude ?: 0.0
            val lng = currentJob?.longitude ?: 0.0
            intent.putExtra("CURRENT_LATITUDE", lat)
            intent.putExtra("CURRENT_LONGITUDE", lng)

            startActivityForResult(intent, REQUEST_CODE_PICK_LOCATION)
        }

        btnVerUbicacion.setOnClickListener {
            currentJob?.let { job ->
                if (job.latitude != null && job.longitude != null &&
                    (job.latitude != 0.0 || job.longitude != 0.0)
                ) {
                    val intent = Intent(this, JobLocationActivity::class.java)
                    intent.putExtra("JOB_LATITUDE", job.latitude)
                    intent.putExtra("JOB_LONGITUDE", job.longitude)
                    intent.putExtra("JOB_DESCRIPTION", job.description)
                    startActivity(intent)
                } else {
                    Toast.makeText(this, "No hay ubicación asignada para este trabajo.", Toast.LENGTH_SHORT).show()
                }
            }
        }

        btnImagenes.setOnClickListener {
            val intent = Intent(this, ImagesJobActivity::class.java)
            intent.putExtra("JOB_ID", jobId)
            startActivity(intent)
        }

        // Cargar los datos del trabajo
        when {
            jobFromIntent != null -> {
                currentJob = jobFromIntent
                bind(jobFromIntent)
            }
            jobId != -1 -> lifecycleScope.launch {
                val job = db.jobDao().getById(jobId)
                if (job != null) {
                    currentJob = job
                    bind(job)
                } else {
                    Toast.makeText(
                        this@JobDetailActivity,
                        "Error: trabajo no encontrado",
                        Toast.LENGTH_SHORT
                    ).show()
                    finish()
                }
            }
            else -> {
                Toast.makeText(
                    this,
                    "Error: trabajo no encontrado",
                    Toast.LENGTH_SHORT
                ).show()
                finish()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_PICK_LOCATION && resultCode == Activity.RESULT_OK) {
            data?.let {
                val lat = it.getDoubleExtra("LATITUDE", 0.0)
                val lng = it.getDoubleExtra("LONGITUDE", 0.0)

                if (lat != 0.0 && lng != 0.0 && currentJob != null) {
                    lifecycleScope.launch {
                        val updatedJob = currentJob!!.copy(latitude = lat, longitude = lng)
                        db.jobDao().update(updatedJob)
                        currentJob = updatedJob
                        bind(updatedJob)
                        Toast.makeText(
                            this@JobDetailActivity,
                            "Ubicación guardada correctamente",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    Toast.makeText(this, "Ubicación no válida seleccionada", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun bind(job: Job) {
        findViewById<TextView>(R.id.textViewDetailDescription).text = job.description
        findViewById<TextView>(R.id.textViewDetailClient).text = "Cliente: ${job.clientName}"
        findViewById<TextView>(R.id.textViewDetailHectares).text = "Hectáreas: ${job.surface}"
        findViewById<TextView>(R.id.textViewDetailStatus).text = "Estado: ${job.status}"
        findViewById<TextView>(R.id.textViewDetailNotes).text =
            "Notas: ${job.notes?.takeIf { it.isNotBlank() } ?: "N/A"}"
        findViewById<TextView>(R.id.textViewDetailBilling).text = "Facturación: ${job.billingStatus}"
        findViewById<TextView>(R.id.textViewDetailCreatedDate).text =
            "Creado: ${DateFormatter.formatDate(job.date)}"
        findViewById<TextView>(R.id.textViewDetailRealStartDate).text =
            job.startDate.takeIf { it > 0L }?.let { "Inicio real: ${DateFormatter.formatMillis(it)}" }
                ?: "Inicio real: Fecha no establecida"
        findViewById<TextView>(R.id.textViewDetailFinishDate).text =
            job.endDate.takeIf { it > 0L }?.let { "Finalizado: ${DateFormatter.formatMillis(it)}" }
                ?: "Finalizado: Fecha no establecida"

        val btnVerUbicacion = findViewById<Button>(R.id.buttonVerUbicacion)
        val btnPickLocation = findViewById<Button>(R.id.buttonPickLocation)

        // Mostrar o esconder botón de ver ubicación si hay ubicación válida
        if (job.latitude == null || job.longitude == null || (job.latitude == 0.0 && job.longitude == 0.0)) {
            btnVerUbicacion.visibility = View.GONE
        } else {
            btnVerUbicacion.visibility = View.VISIBLE
        }

        // El botón para seleccionar ubicación siempre visible
        btnPickLocation.visibility = View.VISIBLE

        // ... resto del bind para parámetros, igual que antes ...
        val layoutParametros = findViewById<android.widget.LinearLayout>(R.id.layoutParametrosUtilizados)
        val textViewDosis = findViewById<TextView>(R.id.textViewDosisValue)
        val textViewTamanoGota = findViewById<TextView>(R.id.textViewTamanoGotaValue)
        val textViewInterlineado = findViewById<TextView>(R.id.textViewInterlineadoValue)
        val textViewVelocidad = findViewById<TextView>(R.id.textViewVelocidadValue)
        val textViewAltura = findViewById<TextView>(R.id.textViewAlturaValue)
        val textViewDiscoUtilizado = findViewById<TextView>(R.id.textViewDiscoUtilizadoValue)

        layoutParametros.visibility = View.GONE
        textViewTamanoGota.visibility = View.GONE
        textViewDiscoUtilizado.visibility = View.GONE

        lifecycleScope.launch {
            val parametros = db.jobParametrosDao().getByJobId(job.id)
            if (parametros != null) {
                layoutParametros.visibility = View.VISIBLE

                val tipoAplicacion = job.tipoAplicacion?.lowercase()
                val dosisUnit = when (tipoAplicacion) {
                    "aplicacion liquida" -> "l/ha"
                    "aplicacion solida" -> "kg/ha"
                    else -> ""
                }

                textViewDosis.text = "Dosis: ${parametros.dosis ?: "N/A"} $dosisUnit"
                textViewInterlineado.text = "Interlineado: ${parametros.interlineado ?: "N/A"} metros"
                textViewVelocidad.text = "Velocidad: ${parametros.velocidad ?: "N/A"} km/h"
                textViewAltura.text = "Altura: ${parametros.altura ?: "N/A"} metros"

                if (tipoAplicacion == "aplicacion liquida") {
                    textViewTamanoGota.text = "Tamaño de gota: ${parametros.tamanoGota ?: "N/A"} micrones"
                    textViewTamanoGota.visibility = View.VISIBLE
                }

                if (tipoAplicacion == "aplicacion solida") {
                    textViewDiscoUtilizado.text = "Disco utilizado: ${parametros.discoUtilizado ?: "N/A"}"
                    textViewDiscoUtilizado.visibility = View.VISIBLE

                    val textViewRevoluciones = findViewById<TextView>(R.id.textViewRevolucionesValue)
                    textViewRevoluciones.text = "Revoluciones: ${parametros.revoluciones ?: "N/A"}"
                    textViewRevoluciones.visibility = View.VISIBLE
                } else {
                    val textViewRevoluciones = findViewById<TextView>(R.id.textViewRevolucionesValue)
                    textViewRevoluciones.visibility = View.GONE
                }
            }
        }
    }
}
