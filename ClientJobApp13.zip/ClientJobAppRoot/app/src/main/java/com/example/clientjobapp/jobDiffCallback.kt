// JobDiffCallback.kt
package com.example.clientjobapp

import androidx.recyclerview.widget.DiffUtil
import com.example.clientjobapp.data.Job

class JobDiffCallback : DiffUtil.ItemCallback<Job>() {
    override fun areItemsTheSame(oldItem: Job, newItem: Job): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: Job, newItem: Job): Boolean {
        return oldItem == newItem
    }
}