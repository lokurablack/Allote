package com.example.clientjobapp.data

import androidx.room.*

@Dao
interface AdministracionDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(adm: AdministracionTrabajo)

    @Query("SELECT * FROM AdministracionTrabajo WHERE jobId = :jobId LIMIT 1")
    suspend fun getByJobId(jobId: Int): AdministracionTrabajo?

    @Query("SELECT * FROM AdministracionTrabajo")
    suspend fun getAllAdministracionTrabajos(): List<AdministracionTrabajo>
}
