package com.example.clientjobapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.clientjobapp.data.AppDatabase
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch
import com.example.clientjobapp.data.Client
import androidx.appcompat.app.AppCompatActivity

class ClientsActivity : AppCompatActivity() {

    private lateinit var clientAdapter: ClientAdapter
    private lateinit var db: AppDatabase
    private lateinit var clientsList: List<Client>
    private lateinit var swipeRefreshLayout: SwipeRefreshLayout
    private lateinit var progressBar: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_clients)

        db = AppDatabase.getDatabase(this)

        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayoutClients)
        progressBar = findViewById(R.id.progressBarClients)

        val clientRecyclerView = findViewById<RecyclerView>(R.id.clientsRecyclerView)
        clientRecyclerView.layoutManager = LinearLayoutManager(this)

        clientAdapter = ClientAdapter(
            onClick = { client ->
                val intent = Intent(this, ClientJobsActivity::class.java)
                intent.putExtra("CLIENT_ID", client.id)
                startActivity(intent)
            },
            onLongClick = { client ->
                val options = arrayOf("Editar", "Eliminar")
                MaterialAlertDialogBuilder(this)
                    .setTitle("Selecciona una opción")
                    .setItems(options) { _, which ->
                        when (which) {
                            0 -> {
                                // Editar cliente
                                ClientDialog(this, onClientSaved = { updatedClient ->
                                    lifecycleScope.launch {
                                        try {
                                            db.clientDao().update(updatedClient)
                                            loadClients()
                                            Snackbar.make(findViewById(android.R.id.content), "Cliente actualizado", Snackbar.LENGTH_SHORT).show()
                                            val intent = Intent("com.example.clientjobapp.CLIENT_ADDED")
                                            sendBroadcast(intent)
                                        } catch (e: Exception) {
                                            Snackbar.make(findViewById(android.R.id.content), "Error al actualizar cliente", Snackbar.LENGTH_SHORT).show()
                                        }
                                    }
                                }, client = client).show()
                            }
                            1 -> {
                                // Eliminar cliente con confirmación
                                MaterialAlertDialogBuilder(this)
                                    .setTitle("Eliminar cliente")
                                    .setMessage("¿Estás seguro de eliminar a ${client.name}?")
                                    .setPositiveButton("Eliminar") { _, _ ->
                                        lifecycleScope.launch {
                                            try {
                                                db.clientDao().delete(client)
                                                loadClients()
                                                Snackbar.make(findViewById(android.R.id.content), "Cliente eliminado", Snackbar.LENGTH_SHORT).show()
                                            } catch (e: Exception) {
                                                Snackbar.make(findViewById(android.R.id.content), "Error al eliminar cliente", Snackbar.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                                    .setNegativeButton("Cancelar", null)
                                    .show()
                            }
                        }
                    }
                    .show()
                true
            }
        )

        clientRecyclerView.adapter = clientAdapter

        swipeRefreshLayout.setOnRefreshListener {
            loadClients()
        }

        val fabAddClient = findViewById<FloatingActionButton>(R.id.fabAddClient)
        fabAddClient.setOnClickListener {
            ClientDialog(this, onClientSaved = { client ->
                lifecycleScope.launch {
                    try {
                        db.clientDao().insert(client)
                        loadClients()
                        Snackbar.make(findViewById(android.R.id.content), "Cliente añadido", Snackbar.LENGTH_SHORT).show()
                        val intent = Intent("com.example.clientjobapp.CLIENT_ADDED")
                        sendBroadcast(intent)
                    } catch (e: Exception) {
                        Snackbar.make(findViewById(android.R.id.content), "Error al añadir cliente", Snackbar.LENGTH_SHORT).show()
                    }
                }
            }).show()
        }

        val searchView = findViewById<androidx.appcompat.widget.SearchView>(R.id.searchViewClients)
        searchView.setOnQueryTextListener(object : androidx.appcompat.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                filterClients(newText)
                return true
            }
        })

        val itemTouchHelperCallback = object : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                return false
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.adapterPosition
                val clientToDelete = clientsList[position]
                MaterialAlertDialogBuilder(this@ClientsActivity)
                    .setTitle("Confirmar eliminación")
                    .setMessage("¿Desea eliminar a ${clientToDelete.name}?")
                    .setPositiveButton("Sí") { _, _ ->
                        lifecycleScope.launch {
                            try {
                                db.clientDao().delete(clientToDelete)
                                loadClients()
                                Snackbar.make(findViewById(android.R.id.content), "Cliente eliminado", Snackbar.LENGTH_SHORT).show()
                            } catch (e: Exception) {
                                Snackbar.make(findViewById(android.R.id.content), "Error al eliminar cliente", Snackbar.LENGTH_SHORT).show()
                            }
                        }
                    }
                    .setNegativeButton("No") { _, _ ->
                        clientAdapter.notifyItemChanged(position)
                    }
                    .show()
            }
        }
        ItemTouchHelper(itemTouchHelperCallback).attachToRecyclerView(clientRecyclerView)

        loadClients()
    }

    private fun loadClients() {
        progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            try {
                val clients = db.clientDao().getAll()
                val sortedClients = clients.sortedBy { it.name.lowercase() }
                clientsList = sortedClients
                clientAdapter.submitList(sortedClients)
            } catch (e: Exception) {
                Snackbar.make(findViewById(android.R.id.content), "Error al cargar clientes", Snackbar.LENGTH_SHORT).show()
            } finally {
                progressBar.visibility = View.GONE
                swipeRefreshLayout.isRefreshing = false
            }
        }
    }

    private fun filterClients(query: String?) {
        val filteredList = if (query.isNullOrEmpty()) {
            clientsList
        } else {
            clientsList.filter { client ->
                client.name.contains(query, ignoreCase = true)
            }
        }
        clientAdapter.updateData(filteredList)
    }
}
