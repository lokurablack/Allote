package com.example.clientjobapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.clientjobapp.R
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class JobLocationActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var map: GoogleMap
    private var jobLatitude: Double = 0.0
    private var jobLongitude: Double = 0.0
    private var jobDescription: String = "Trabajo"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_job_location)

        jobLatitude = intent.getDoubleExtra("JOB_LATITUDE", 0.0)
        jobLongitude = intent.getDoubleExtra("JOB_LONGITUDE", 0.0)
        jobDescription = intent.getStringExtra("JOB_DESCRIPTION") ?: "Trabajo"

        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap

        map.mapType = GoogleMap.MAP_TYPE_SATELLITE

        val jobLocation = LatLng(jobLatitude, jobLongitude)
        map.addMarker(MarkerOptions().position(jobLocation).title(jobDescription))
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(jobLocation, 16f))
    }
}
