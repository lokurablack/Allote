package com.example.clientjobapp

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.clientjobapp.data.AppDatabase
import kotlinx.coroutines.launch

class AdministracionResumenActivity : AppCompatActivity() {

    private var jobId: Int = -1
    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_administracion_resumen)

        db = AppDatabase.getDatabase(this)
        jobId = intent.getIntExtra("JOB_ID", -1)

        val textViewHectareas = findViewById<TextView>(R.id.textViewResumenHectareas)
        val textViewCosto = findViewById<TextView>(R.id.textViewResumenCostoPorHectarea)
        val textViewSinIVA = findViewById<TextView>(R.id.textViewResumenTotalSinIVA)
        val textViewConIVA = findViewById<TextView>(R.id.textViewResumenTotalConIVA)
        val textViewIVA = findViewById<TextView>(R.id.textViewResumenIVA)

        if (jobId != -1) {
            lifecycleScope.launch {
                val job = db.jobDao().getById(jobId)
                val adm = db.administracionDao().getByJobId(jobId)

                if (job != null && adm != null) {
                    val superficie = job.surface
                    textViewHectareas.text = "Hectáreas: %.2f".format(superficie)
                    textViewCosto.text = "Costo por hectárea: UsD %.2f".format(adm.costoPorHectarea)
                    textViewSinIVA.text = "Total sin IVA: UsD %.2f".format(adm.totalSinIVA)
                    textViewConIVA.text = "Total con IVA: UsD %.2f".format(adm.totalConIVA)
                    textViewIVA.text = "IVA aplicado: ${if (adm.aplicaIVA) "Sí (10.5%)" else "No"}"
                } else {
                    Toast.makeText(this@AdministracionResumenActivity, "Datos no encontrados", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        } else {
            Toast.makeText(this, "ID inválido", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
