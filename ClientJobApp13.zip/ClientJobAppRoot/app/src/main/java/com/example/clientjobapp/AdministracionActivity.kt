package com.example.clientjobapp

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.clientjobapp.data.AdministracionTrabajo
import com.example.clientjobapp.data.AppDatabase
import kotlinx.coroutines.launch

class AdministracionActivity : AppCompatActivity() {
    private lateinit var db: AppDatabase
    private var jobId: Int = -1
    private var facturaUri: Uri? = null
    private var hectareas: Double = 0.0

    companion object {
        private const val PDF_REQUEST_CODE = 1
        private const val IVA_PORCENTAJE = 0.105
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_administracion)

        db = AppDatabase.getDatabase(this)
        jobId = intent.getIntExtra("JOB_ID", -1)

        val textViewHectareas = findViewById<TextView>(R.id.textViewHectares)
        val editTextCostoPorHectarea = findViewById<EditText>(R.id.editTextCostoPorHectarea)
        val checkBoxAplicarIVA = findViewById<CheckBox>(R.id.checkBoxAplicarIVA)
        val textViewTotalSinIVA = findViewById<TextView>(R.id.textViewTotalSinIVA)
        val textViewTotalConIVA = findViewById<TextView>(R.id.textViewTotalConIVA)
        val buttonCalcular = findViewById<Button>(R.id.buttonCalcular)
        val buttonGuardar = findViewById<Button>(R.id.buttonGuardarAdministracion)
        val buttonCargarFactura = findViewById<Button>(R.id.buttonCargarFactura)
        val buttonVerFactura = findViewById<Button>(R.id.buttonVerFactura)
        val buttonVerResumen = findViewById<Button>(R.id.buttonVerResumen)

        // Obtener valor guardado de "valor ha" desde SharedPreferences
        val sharedPrefs = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val valorHaGuardado = sharedPrefs.getFloat("value_per_ha", 0.0f)

        // Cargar datos del trabajo
        lifecycleScope.launch {
            val job = db.jobDao().getById(jobId)
            if (job != null) {
                hectareas = job.surface
                textViewHectareas.text = "Hectáreas: $hectareas"
            } else {
                Toast.makeText(this@AdministracionActivity, "Trabajo no encontrado", Toast.LENGTH_SHORT).show()
                finish()
                return@launch
            }

            val registroExistente = db.administracionDao().getByJobId(jobId)
            if (registroExistente != null) {
                editTextCostoPorHectarea.setText(registroExistente.costoPorHectarea.toString())
                checkBoxAplicarIVA.isChecked = registroExistente.aplicaIVA
                textViewTotalSinIVA.text = "Total sin IVA: UsD ${registroExistente.totalSinIVA}"
                textViewTotalConIVA.text = "Total con IVA: UsD ${registroExistente.totalConIVA}"
                facturaUri = registroExistente.facturaUri?.let { Uri.parse(it) }
                if (facturaUri != null) buttonCargarFactura.isEnabled = false
            } else {
                // Si no hay registro existente, establecer el valor guardado de "valor ha" según tipoAplicacion
                val tipoAplicacion = job.tipoAplicacion ?: ""
                val costoPorHectareaValor = when (tipoAplicacion.lowercase()) {
                    "aplicacion liquida" -> sharedPrefs.getFloat("value_per_ha_liquida", 0.0f)
                    "aplicacion solida" -> sharedPrefs.getFloat("value_per_ha_solida", 0.0f)
                    "aplicacion mixta" -> sharedPrefs.getFloat("value_per_ha_mixta", 0.0f)
                    "aplicaciones varias" -> sharedPrefs.getFloat("value_per_ha_varias", 0.0f)
                    else -> 0.0f
                }
                if (costoPorHectareaValor > 0) {
                    editTextCostoPorHectarea.setText(costoPorHectareaValor.toString())
                }
            }
        }

        buttonCalcular.setOnClickListener {
            val costoStr = editTextCostoPorHectarea.text.toString()
            if (costoStr.isBlank()) {
                Toast.makeText(this, "Ingrese un costo por hectárea", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val costoPorHectarea = costoStr.toDoubleOrNull()
            if (costoPorHectarea == null) {
                Toast.makeText(this, "Costo inválido", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val totalSinIVA = hectareas * costoPorHectarea
            val aplicaIVA = checkBoxAplicarIVA.isChecked
            val totalConIVA = if (aplicaIVA) totalSinIVA * (1 + IVA_PORCENTAJE) else totalSinIVA

            textViewTotalSinIVA.text = "Total sin IVA: UsD %.2f".format(totalSinIVA)
            textViewTotalConIVA.text = "Total con IVA: UsD %.2f".format(totalConIVA)
        }

        buttonGuardar.setOnClickListener {
            val costoStr = editTextCostoPorHectarea.text.toString()
            val costoPorHectarea = costoStr.toDoubleOrNull()
            if (costoPorHectarea == null) {
                Toast.makeText(this, "Ingrese un costo válido", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val aplicaIVA = checkBoxAplicarIVA.isChecked
            val totalSinIVA = hectareas * costoPorHectarea
            val totalConIVA = if (aplicaIVA) totalSinIVA * (1 + IVA_PORCENTAJE) else totalSinIVA

            lifecycleScope.launch {
                val registroExistente = db.administracionDao().getByJobId(jobId)

                val administracionTrabajo = AdministracionTrabajo(
                    id = registroExistente?.id ?: 0,
                    jobId = jobId,
                    facturaUri = facturaUri?.toString(),
                    costoPorHectarea = costoPorHectarea,
                    totalSinIVA = totalSinIVA,
                    totalConIVA = totalConIVA,
                    aplicaIVA = aplicaIVA
                )

                db.administracionDao().insert(administracionTrabajo)
                Toast.makeText(this@AdministracionActivity, "Guardado exitosamente", Toast.LENGTH_SHORT).show()
            }
        }

        buttonCargarFactura.setOnClickListener { abrirSeleccionArchivo() }

        buttonVerFactura.setOnClickListener {
            facturaUri?.let {
                val intent = Intent(this, PdfViewerActivity::class.java)
                intent.putExtra("pdf_uri", it.toString())
                startActivity(intent)
            } ?: Toast.makeText(this, "No hay factura cargada", Toast.LENGTH_SHORT).show()
        }

        buttonVerResumen.setOnClickListener {
            val intent = Intent(this, AdministracionResumenActivity::class.java)
            intent.putExtra("JOB_ID", jobId)
            startActivity(intent)
        }
    }

    private fun abrirSeleccionArchivo() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "application/pdf"
            addCategory(Intent.CATEGORY_OPENABLE)
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        }
        startActivityForResult(intent, PDF_REQUEST_CODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PDF_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                guardarFacturaUriEnBaseDeDatos(uri)
            }
        }
    }

    private fun guardarFacturaUriEnBaseDeDatos(uri: Uri) {
        facturaUri = uri
        lifecycleScope.launch {
            val registroExistente = db.administracionDao().getByJobId(jobId)
            val administracionTrabajo = AdministracionTrabajo(
                id = registroExistente?.id ?: 0,
                jobId = jobId,
                facturaUri = uri.toString(),
                costoPorHectarea = registroExistente?.costoPorHectarea ?: 0.0,
                totalSinIVA = registroExistente?.totalSinIVA ?: 0.0,
                totalConIVA = registroExistente?.totalConIVA ?: 0.0,
                aplicaIVA = registroExistente?.aplicaIVA ?: false
            )

            db.administracionDao().insert(administracionTrabajo)
            findViewById<Button>(R.id.buttonCargarFactura).isEnabled = false
            Toast.makeText(this@AdministracionActivity, "Factura cargada exitosamente", Toast.LENGTH_SHORT).show()
        }
    }
}
