// ClientRepository.kt
package com.example.clientjobapp.data

import androidx.lifecycle.LiveData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ClientRepository(private val clientDao: ClientDao) {

    // Obtener todos los clientes
    suspend fun getAllClients(): List<Client> = withContext(Dispatchers.IO) {
        clientDao.getAll()
    }

    // Insertar un nuevo cliente
    suspend fun insertClient(client: Client) = withContext(Dispatchers.IO) {
        clientDao.insert(client)
    }

    // Eliminar un cliente
    suspend fun deleteClient(client: Client) = withContext(Dispatchers.IO) {
        clientDao.delete(client)
    }

    // Eliminar todos los clientes
    suspend fun deleteAllClients() = withContext(Dispatchers.IO) {
        clientDao.deleteAllClients()
    }

}