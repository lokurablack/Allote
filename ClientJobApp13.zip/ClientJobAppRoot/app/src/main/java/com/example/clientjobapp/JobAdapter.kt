// JobAdapter.kt
package com.example.clientjobapp

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.clientjobapp.data.Job
import java.text.SimpleDateFormat
import java.util.*

class JobAdapter(
    private val context: Context,
    private val onClick: (Job) -> Unit,
    private val onLongClick: (Job) -> Unit
) : ListAdapter<JobStatusGroup, JobAdapter.JobViewHolder>(JobStatusGroupDiffCallback()) {

    inner class JobViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val textViewStatus: TextView = itemView.findViewById(R.id.textViewJobStatus)
        private val jobsRecyclerView: RecyclerView = itemView.findViewById(R.id.recyclerViewJobs)
        private val subAdapter = SubJobAdapter(emptyList(), onClick, onLongClick)

        fun bind(group: JobStatusGroup) {
            val totalHa = group.jobs.sumOf { it.surface}
            textViewStatus.text = "${group.status} (${"%.1f".format(totalHa)} ha)"

            jobsRecyclerView.apply {
                layoutManager = androidx.recyclerview.widget.LinearLayoutManager(context)
                adapter = subAdapter
                setHasFixedSize(true)
            }
            subAdapter.updateList(group.jobs)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JobViewHolder {
        val view = LayoutInflater.from(context)
            .inflate(R.layout.item_job_status, parent, false)
        return JobViewHolder(view)
    }

    override fun onBindViewHolder(holder: JobViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    /** Actualiza la lista agrupada por estado **/
    fun updateData(allJobs: List<Job>) {
        val grouped = allJobs.groupBy { it.status }
            .map { (status, jobs) -> JobStatusGroup(status, jobs) }
        submitList(grouped)
    }
}

data class JobStatusGroup(val status: String, val jobs: List<Job>)

class JobStatusGroupDiffCallback : DiffUtil.ItemCallback<JobStatusGroup>() {
    override fun areItemsTheSame(old: JobStatusGroup, new: JobStatusGroup) =
        old.status == new.status

    override fun areContentsTheSame(old: JobStatusGroup, new: JobStatusGroup) =
        old.jobs == new.jobs
}

class SubJobAdapter(
    private var jobList: List<Job>,
    private val onClick: (Job) -> Unit,
    private val onLongClick: (Job) -> Unit
) : RecyclerView.Adapter<SubJobAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val tvClient: TextView = view.findViewById(R.id.textViewClientName)
        private val tvDesc: TextView = view.findViewById(R.id.textViewJobDescription)
        // private val tvDate: TextView = view.findViewById(R.id.textViewJobDate)
        private val tvStatus: TextView = view.findViewById(R.id.textViewJobStatus)
        private val tvHa: TextView = view.findViewById(R.id.textViewHectares)
        private val tvTipoAplicacion: TextView = view.findViewById(R.id.textViewTipoAplicacion)

        fun bind(job: Job) {
            tvClient.text = job.clientName
            tvDesc.text = job.description
            tvHa.text = "${job.surface} ha"
            // tvDate.text = formatDate(job.date)
            tvStatus.text = job.status
            tvStatus.setTextColor(
                when (job.status) {
                    "Finalizado" -> Color.GREEN
                    "Pendiente" -> Color.YELLOW
                    else -> Color.GRAY
                }
            )
            tvTipoAplicacion.text = "${job.tipoAplicacion ?: "N/A"}"
            itemView.setOnClickListener { onClick(job) }
            itemView.setOnLongClickListener {
                onLongClick(job); true
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_job, parent, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) =
        holder.bind(jobList[position])

    override fun getItemCount() = jobList.size

    fun updateList(newList: List<Job>) {
        jobList = newList
        notifyDataSetChanged()
    }

    private fun formatDate(dateStr: String): String {
        val inFmt = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val outFmt = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        return try { outFmt.format(inFmt.parse(dateStr)!!) } catch (_: Exception) { dateStr }
    }
}
