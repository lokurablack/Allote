package com.example.clientjobapp.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.clientjobapp.data.Job
import com.example.clientjobapp.data.JobDao
import com.example.clientjobapp.data.AppDatabase
import kotlinx.coroutines.launch

class JobViewModel(application: Application) : AndroidViewModel(application) {

    private val jobDao: JobDao = AppDatabase.getDatabase(application).jobDao()
    private val _jobs = MutableLiveData<List<Job>>()
    val jobs: LiveData<List<Job>> get() = _jobs

    fun getJobsByStatus(status: String) {
        viewModelScope.launch {
            _jobs.value = jobDao.getJobsByStatus(status)
        }
    }

    fun getJobsByClientId(clientId: Int) {
        viewModelScope.launch {
            _jobs.value = jobDao.getJobsByClientId(clientId)
        }
    }

    fun getAllJobs() {
        viewModelScope.launch {
            _jobs.value = jobDao.getAll()
        }
    }
}
