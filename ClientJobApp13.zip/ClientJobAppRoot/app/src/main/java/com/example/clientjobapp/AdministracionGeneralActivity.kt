package com.example.clientjobapp

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.clientjobapp.data.AdministracionTrabajo
import com.example.clientjobapp.data.AppDatabase
import com.example.clientjobapp.data.Job
import kotlinx.coroutines.launch

class AdministracionGeneralActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase

    private lateinit var tvTotalFinalizados: TextView
    private lateinit var tvTotalPendientes: TextView
    private lateinit var tvTotalNoFacturados: TextView
    private lateinit var tvTotalFacturados: TextView
    private lateinit var tvTotalPagados: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_administracion_general)

        db = AppDatabase.getDatabase(this)

        tvTotalFinalizados = findViewById(R.id.tvTotalFinalizados)
        tvTotalPendientes = findViewById(R.id.tvTotalPendientes)
        tvTotalNoFacturados = findViewById(R.id.tvTotalNoFacturados)
        tvTotalFacturados = findViewById(R.id.tvTotalFacturados)
        tvTotalPagados = findViewById(R.id.tvTotalPagados)

        loadTotals()
    }

    private fun loadTotals() {
        lifecycleScope.launch {
            try {
                val jobs: List<Job> = db.jobDao().getAll()
                val administracionList: List<AdministracionTrabajo> = db.administracionDao().getAllAdministracionTrabajos()
                val administracionMap: Map<Int, AdministracionTrabajo> = administracionList.associateBy { it.jobId }

                var totalFinalizados = 0.0
                var totalPendientes = 0.0
                var totalNoFacturados = 0.0
                var totalFacturados = 0.0
                var totalPagados = 0.0

                for (job in jobs) {
                    val adm = administracionMap[job.id]
                    val costoPorHectarea = adm?.costoPorHectarea ?: 0.0
                    val surface = job.surface

                    val totalJob = costoPorHectarea * surface

                    when (job.status.lowercase()) {
                        "finalizado", "finalizados" -> totalFinalizados += totalJob
                        "pendiente", "pendientes" -> totalPendientes += totalJob
                    }

                    when (job.billingStatus.lowercase()) {
                        "no facturado" -> totalNoFacturados += totalJob
                        "facturado" -> totalFacturados += totalJob
                        "pagado" -> totalPagados += totalJob
                    }
                }

                tvTotalFinalizados.text = "Total trabajos finalizados: UsD %.2f".format(totalFinalizados)
                tvTotalPendientes.text = "Total trabajos pendientes: UsD %.2f".format(totalPendientes)
                tvTotalNoFacturados.text = "Total trabajos no facturados: UsD %.2f".format(totalNoFacturados)
                tvTotalFacturados.text = "Total trabajos facturados: UsD %.2f".format(totalFacturados)
                tvTotalPagados.text = "Total trabajos pagados: UsD %.2f".format(totalPagados)

            } catch (e: Exception) {
                Toast.makeText(this@AdministracionGeneralActivity, "Error al cargar datos administrativos", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
