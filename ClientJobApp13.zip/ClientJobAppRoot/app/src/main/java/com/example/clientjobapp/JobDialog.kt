package com.example.clientjobapp

import android.app.DatePickerDialog
import android.content.Context
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.example.clientjobapp.data.AppDatabase
import com.example.clientjobapp.data.Job
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*
import com.example.clientjobapp.DateFormatter


class JobDialog(
    private val context: Context,
    private val db: AppDatabase,
    private val onJobSaved: (Job) -> Unit,
    private val job: Job? = null,
    private val valuePerHectare: Double = 0.0
) {
    fun show() {
        val builder = AlertDialog.Builder(context)
        val inflater = LayoutInflater.from(context)
        val view = inflater.inflate(R.layout.dialog_job, null)

        val spinnerClient = view.findViewById<Spinner>(R.id.spinnerClient)
        val editTextDescripcion = view.findViewById<EditText>(R.id.editTextDescripcion)
        val editTextHectareas = view.findViewById<EditText>(R.id.editTextHectareas)
        val radioGroupStatus = view.findViewById<android.widget.RadioGroup>(R.id.radioGroupStatus)
        val editTextNotas = view.findViewById<EditText>(R.id.editTextNotas)
        val editTextRealStart = view.findViewById<EditText>(R.id.editTextRealStartDate)
        val spinnerTipoAplicacion = view.findViewById<Spinner>(R.id.spinnerTipoAplicacion)

        // Variable para la fecha real de inicio (millis), opcional
        var realStartMillis = job?.startDate ?: 0L

        // Opciones para tipo de aplicacion
        val tipoAplicacionOptions = listOf(
            "Aplicacion liquida",
            "Aplicacion solida",
            "Aplicacion mixta",
            "Aplicaciones varias"
        )

        // Prellenar campos si editamos
        job?.let {
            editTextDescripcion.setText(it.description)
            editTextHectareas.setText(it.surface.toString())
            editTextNotas.setText(it.notes ?: "")
            if (it.startDate > 0L) {
                editTextRealStart.setText(DateFormatter.formatMillis(it.startDate))
            }
            when (it.status) {
                "Pendiente" -> radioGroupStatus.check(R.id.radioPending)
                "Finalizado" -> radioGroupStatus.check(R.id.radioFinished)
            }
        }

        // Cargar clientes en spinner
        CoroutineScope(Dispatchers.IO).launch {
            val clients = db.clientDao().getAll()
            withContext(Dispatchers.Main) {
                val adapter = android.widget.ArrayAdapter(
                    context,
                    android.R.layout.simple_spinner_item,
                    clients.map { "${it.name} ${it.lastname}" }
                )
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                spinnerClient.adapter = adapter
                job?.let {
                    val index = clients.indexOfFirst { client -> client.id == it.clientId }
                    if (index >= 0) spinnerClient.setSelection(index)
                }

                // Set adapter and selection for tipo de aplicacion spinner
                val tipoAdapter = android.widget.ArrayAdapter(
                    context,
                    android.R.layout.simple_spinner_item,
                    tipoAplicacionOptions
                )
                tipoAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                spinnerTipoAplicacion.adapter = tipoAdapter

                job?.let {
                    val tipoIndex = tipoAplicacionOptions.indexOf(it.tipoAplicacion)
                    if (tipoIndex >= 0) spinnerTipoAplicacion.setSelection(tipoIndex)
                }
            }
        }

        // DatePicker para fecha real de inicio
        editTextRealStart.setOnClickListener {
            val cal = Calendar.getInstance()
            DatePickerDialog(
                context,
                { _, year, month, dayOfMonth ->
                    cal.set(year, month, dayOfMonth, 0, 0, 0)
                    realStartMillis = cal.timeInMillis
                    editTextRealStart.setText(DateFormatter.formatMillis(realStartMillis))
                },
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        builder.setView(view)
            .setTitle(if (job == null) "Agregar Trabajo" else "Editar Trabajo")
            .setPositiveButton("Guardar") { _, _ ->
                val selectedPosition = spinnerClient.selectedItemPosition
                val descripcion = editTextDescripcion.text.toString().trim()
                val surfaceStr = editTextHectareas.text.toString().trim()
                val hectareas = surfaceStr.toDoubleOrNull()
                val notas = editTextNotas.text.toString().trim().takeIf { it.isNotEmpty() }
                val status = when (radioGroupStatus.checkedRadioButtonId) {
                    R.id.radioFinished -> "Finalizado"
                    else -> "Pendiente"
                }
                val tipoAplicacion = spinnerTipoAplicacion.selectedItem as String

                if (selectedPosition >= 0) {
                    CoroutineScope(Dispatchers.IO).launch {
                        val clients = db.clientDao().getAll()
                        val selectedClient = clients[selectedPosition]
                        val formattedDate = job?.date
                            ?: SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

                        val newJob = job?.copy(
                            clientId = selectedClient.id,
                            clientName = "${selectedClient.name} ${selectedClient.lastname}",
                            description = descripcion,
                            notes = notas,
                            date = formattedDate,
                            status = status,
                            startDate = realStartMillis,
                            endDate = job.endDate, // preserva la fecha de fin si existía
                            surface = hectareas ?: 0.0,
                            valuePerHectare = valuePerHectare,
                            billingStatus = job.billingStatus,
                            tipoAplicacion = tipoAplicacion,
                            latitude = job.latitude,
                            longitude = job.longitude
                        ) ?: Job(
                            clientId = selectedClient.id,
                            clientName = "${selectedClient.name} ${selectedClient.lastname}",
                            description = descripcion,
                            date = formattedDate,
                            status = status,
                            startDate = realStartMillis,
                            endDate = 0L,
                            surface = hectareas ?: 0.0,
                            valuePerHectare = valuePerHectare,
                            billingStatus = "No Facturado",
                            notes = notas,
                            tipoAplicacion = tipoAplicacion,
                            latitude = null,
                            longitude = null
                        )

                        withContext(Dispatchers.Main) {
                            onJobSaved(newJob)
                        }
                    }
                } else {
                    Toast.makeText(context, "Selecciona un cliente", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
